# Reto AgroCebada 2026 — Pipeline de exploración y modelado

Este proyecto es un punto de partida **para correr en tu propia computadora** (no en la nube).
Ya revisé a fondo el dataset oficial (`DataSet_RETO_AGRO_2026`) y construí un pipeline completo
de 5 pasos: exploración → extracción geoespacial (clima + topografía) → construcción de features
satelitales → modelado/validación → predicción final para el 30% oculto.

## 0. Qué hay realmente en el dataset (ya lo revisé por ti)

| Archivo | Contenido | Detalle clave |
|---|---|---|
| `Conjunto_datos_BASICO_AgroCebada2026.csv` | 107,666 filas · Sentinel-2 + Landsat, 2022-2025 | 22 índices espectrales (promedio/std/max/min) + nubosidad, por parcela y fecha. **Muchos NaN** (cada sensor solo llena las columnas que le corresponden). |
| `Conjunto_datos_PRO_AgroCebada.csv` | 47,804 filas · Planet, **solo 2025** | NDVI, EVI, LAI, MSAVI (promedio/std/max/min) + nubosidad. Mayor frecuencia temporal que Básico. |
| `ID_area_rendimiento_70_30_Reto_AgroCebada.csv` | 197 parcelas | `ID_POLIGONO`, `AREA_HA`, `RENDIMIENTO_T_HA` (solo 138 = ENTRENAMIENTO), `CONJUNTO`. El rendimiento corresponde al **ciclo abril–octubre 2025**. |
| `Parcelas_Reto_AGC_CONJUNTO_70_30.shp` (+ .dbf/.shx/.prj/.cpg) | 197 polígonos, EPSG:4326 (WGS84 lon/lat) | Campos: `Cultivo`, `ID_POLIGON` (ojo: sin la "O" final, truncado a 10 caracteres por el formato .dbf), `área_ha`, `Municipio`, `Estado`, `CONJUNTO`. |
| `Reto_AgroCebada_CHIRPS_Precipitacion_2022_2025.zip` | 48 GeoTIFF mensuales (`PREC_AAAA_MM.tif`) | Precipitación acumulada mensual, mm/mes, ~5 km de resolución (0.05°), EPSG:4326. Incluye `inventario_..._.csv` con estadísticos por mes. |
| `Reto_AgroCebada_Temperatura_2022_2025_RECORTADA_CHIRPS.zip` | 96 GeoTIFF mensuales (`Tmax/`, `Tmin/` × 48 c/u) | Temperatura mín/máx promedio mensual (CHIRTS-ERA5), mismo grid ~5km, EPSG:4326. |
| `Reto_AgroCebada_Topografia_INEGI_CEM4.zip` | 2 GeoTIFF estáticos | Elevación (m) y pendiente (grados), 120 m de resolución, **EPSG:6372** (¡proyección distinta a todo lo demás, hay que reproyectar!). |
| `Descripcion_general_variables_DataSet.docx` / `Diccionario_de_indices_satelitales.docx` | Documentación oficial | Ya extraje todo el contenido relevante en los comentarios de los scripts. |

**Conclusión clave:** el 30% a predecir son 59 parcelas (`CONJUNTO == "PREDICCION"`), ya georreferenciadas y con área, pero sin rendimiento. Todo lo demás (satélite, clima, topografía) sí está disponible para esas 59 parcelas — el reto es puramente de **transferencia**: entrenar con 138 parcelas etiquetadas y predecir 59.

## 1. Qué necesitas conseguir / instalar

```bash
pip install -r requirements.txt
```

Incluye: pandas, numpy, geopandas, rasterio, rasterstats, scikit-learn, xgboost, lightgbm (opcional),
shap (opcional para explicabilidad), matplotlib, seaborn. `geopandas`/`rasterio` requieren GDAL —
en Windows lo más fácil es `conda install -c conda-forge geopandas rasterio rasterstats` en vez de pip,
si te da problemas de compilación.

## 2. Qué te falta que NO viene en el dataset (para mejorar el modelo)

- **Fechas de siembra/cosecha reales por parcela** (el dataset solo dice "ciclo abril-octubre 2025" en general). Si puedes conseguir fechas específicas (SIAP, avisos de siembra estatales) mejora mucho el recorte fenológico.
- **Tipo de suelo** (INEGI — Conjunto de Datos Edafológicos, serie II) — variable estática de acceso público que puedes cruzar por parcela igual que la topografía.
- **Sentinel-1 (radar/SAR)** vía Google Earth Engine — humedad de suelo y estructura del cultivo, no depende de nubes (a diferencia de Sentinel-2/Landsat/Planet, que sí se pierden por nubosidad).
- **Datos de riego** (si son de temporal vs riego, cambia mucho el rendimiento esperado — revisa si el `Municipio`/`Estado` te da pistas, o consulta CONAGUA/DISTRITOS DE RIEGO).
- **Rendimientos históricos por municipio** (SIAP - Servicio de Información Agroalimentaria y Pesquera) como variable de contexto regional/prior.
- **DEM de mayor resolución** — el INEGI CEM 4.0 original es de 15 m; el que te dieron ya viene remuestreado a 120 m. Si tienes tiempo, bajar el CEM 4.0 nativo (15 m) desde el propio INEGI da más detalle topográfico por parcela pequeña.

Nada de esto es obligatorio, pero cualquiera de estos suma para el 70% del puntaje (desempeño predictivo) y para responder mejor las 3 preguntas guía (bonus).

## 3. Enfoque recomendado: ML clásico, no Deep Learning

Con **138 observaciones de entrenamiento** (y apenas 59 a predecir), un modelo de Deep Learning
(redes neuronales, CNN sobre imágenes crudas, LSTM sobre series temporales) va a sobreajustar
casi con certeza — no hay suficientes datos para que aprenda algo generalizable, por más
"impresionante" que suene "DL" en el reporte. **La estrategia ganadora aquí es Machine Learning
clásico con muy buena ingeniería de features geoespaciales:**

1. **Sí usar deep learning solo si es indirecto**: por ejemplo, extraer embeddings de un modelo
   pre-entrenado (no entrenar uno desde cero) no es necesario para este tamaño de dataset — no lo
   recomiendo, complica sin aportar.
2. **Foco real: ingeniería de features a partir de las series de tiempo satelitales** (esto es lo
   que separa un buen resultado de uno mediocre): valores agregados (media, máximo, pendiente de
   crecimiento) del NDVI/EVI/LAI durante el ciclo abril-octubre, día del pico de vigor vegetal,
   área bajo la curva de NDVI (proxy de biomasa acumulada), anomalías respecto al promedio
   histórico 2022-2024 de la misma parcela, etc.
3. **Modelos**: Ridge/Lasso como baseline interpretable, Random Forest y Gradient Boosting
   (XGBoost/LightGBM) como modelos principales — manejan bien datasets pequeños, tabulares, con
   variables correlacionadas (muchos índices espectrales miden cosas parecidas) y dan feature
   importance directa para responder las preguntas guía.
4. **Validación**: con solo 138 filas, usa validación cruzada robusta (K-Fold repetido, o
   Leave-One-Out si K-Fold da mucha varianza) — nunca reportes solo el error en entrenamiento.
5. **GIS es central, no opcional**: la app/dashboard (30% del puntaje) debe apoyarse en el
   componente espacial — mapa de las 197 parcelas coloreado por rendimiento (real y predicho),
   quizás un mapa de calor de NDVI/precipitación por zona. Aquí es donde puedes lucirte con
   trabajo geoespacial (folium/leaflet, kepler.gl, o un dashboard en Streamlit con un mapa).

## 4. Cómo correr el pipeline

Edita `scripts/00_config.py` con la ruta local donde tengas la carpeta `DATASET_RETO_AGRO_2026`
(la que contiene los .csv y los .zip), y luego corre en orden:

```bash
python scripts/01_explore_data.py
python scripts/02_extract_geo_features.py
python scripts/03_build_feature_table.py
python scripts/04_train_and_evaluate.py
python scripts/05_predict_final.py
python scripts/06_paper_lstm_gp.py      # requiere: pip install torch --index-url https://download.pytorch.org/whl/cpu
python scripts/07_ensemble.py           # combina 04 + 06, y diagnostica dónde falla el modelo
```

Cada script imprime en consola lo que va encontrando y guarda resultados intermedios en
`outputs/` (csvs y gráficas) para que puedas revisarlos entre paso y paso — no es una caja negra.

### Scripts opcionales (mejoras adicionales, no bloquean el pipeline principal)

- **`06_paper_lstm_gp.py`** implementa una adaptación del paper SOTA para
  "pocos datos + geoespacial" (You et al. 2017, AAAI — LSTM sobre la serie
  temporal de índices + Proceso Gaussiano espacial), con varias mejoras de
  estructura sobre la primera versión: pooling por atención sobre todo el
  ciclo (no solo el último estado del LSTM), bagging de `N_BAGS=3` redes por
  fold para reducir varianza, covariables estáticas (clima/topografía/suelo)
  metidas al GP junto con el embedding y lat/lon, y ya no usa el fold de
  prueba para decidir cuándo detener el entrenamiento (evita una fuga leve
  de información que tenía la primera versión). También corre una
  validación `GroupKFold` por Municipio para confirmar que el modelo
  generaliza a ubicaciones no vistas -- a diferencia del modelo de árboles
  de `04`, que puede depender de memorizar el municipio (ver el diagnóstico
  que imprime `04_train_and_evaluate.py`). Tiene además un flag
  `ALIGN_BY_PHENOLOGY` (por defecto `False`) que, si lo activas, alinea la
  serie de cada parcela por su propio inicio de crecimiento detectado del
  NDVI en vez de por fecha calendario — corre ambas versiones y compara el
  RMSE en `07_ensemble.py` antes de decidir cuál usar en tu entrega final.
- **`07_ensemble.py`** combina las predicciones del mejor modelo de árboles
  (04) y del LSTM+GP (06), y te dice en qué municipios/parcelas se
  concentran los errores más grandes — corre esto después de 04, 05 y 06.
- **`08_soil_features.py`** (opcional, requiere que descargues tú el
  shapefile nacional de edafología de INEGI — Serie II Continuo Nacional,
  un solo archivo de ~175 MB, ya no por estado) — agrega tipo/textura de
  suelo por parcela, variable que el modelo no tiene todavía.
- **`09_sentinel1_gee_features.py`** (opcional, requiere cuenta de Google
  Earth Engine) — agrega radar Sentinel-1, que no se pierde por nubosidad
  a diferencia de todo lo óptico que ya usas (Sentinel-2/Landsat/Planet).
- **`10_nasa_power_features.py`** (opcional, requiere internet + `pip
  install requests`) — agrega radiación solar, humedad relativa, viento y
  VPD (déficit de presión de vapor) desde la API pública de NASA POWER,
  variables climáticas que CHIRPS/CHIRTS no traen. Deduplica por coordenada
  redondeada (la resolución real de NASA POWER es ~50-70 km) y cachea las
  respuestas en disco para no repetir llamadas entre corridas.
- **`11_siap_historical_yield.py`** (opcional, scaffold manual) — agrega el
  rendimiento histórico promedio de cebada por municipio (SIAP) como
  covariable CONTINUA (nunca categórica). A diferencia del suelo, aquí
  tienes que descargar tú el archivo real de SIAP y pegarlo en `SIAP_FILE`
  -- el portal cambia de estructura seguido y no quiero asumir una URL/
  esquema de columnas sin que lo confirmes primero. **Obligatorio**: si la
  agregas, vuelve a correr el diagnóstico `LeaveOneGroupOut` de
  `04_train_and_evaluate.py` para confirmar que no reintroduce el mismo
  riesgo de memorización de ubicación que tenía el one-hot de Municipio.
- **`12_elastic_net.py`** (opcional) — Elastic Net interpretable (imputación
  -> escalado -> SelectKBest(60) -> ElasticNetCV) evaluado con KFold repetido,
  LeaveOneGroupOut y los mismos folds que `07`, más una prueba con bootstrap
  de si le AGREGA algo al ensemble. Con tus datos: RMSE 0.535 (KFold) y 0.838
  (LOGO) contra 0.506 / 0.594 de ExtraTrees, y peso óptimo 0 en el ensemble
  (errores 0.93 correlacionados con los del ensemble). Sirve como modelo
  interpretable para las preguntas guía. Para medir el aporte del modelo de un
  compañero, pon en `EXTERNAL_OOF_CSV` sus predicciones fuera de muestra sobre
  las 138 parcelas de entrenamiento (mismos folds que 07, ver docstring).

### Mejoras del modelo (implementadas a partir del diagnóstico de memorización de Municipio)

- **`04_train_and_evaluate.py`**: valida por `LeaveOneGroupOut` (un fold por
  municipio, más granular que el `GroupKFold(5)` anterior) y prueba una
  variante adicional con Municipio codificado por `ShrunkenTargetEncoder`
  (encogimiento empírico-Bayes hacia la media global -- una aproximación
  frecuentista ligera de un modelo jerárquico/de efectos mixtos), evaluada
  con ambos esquemas de CV para ver si generaliza mejor que quitar
  Municipio por completo.
- **`06_paper_lstm_gp.py`**: también cambia a `LeaveOneGroupOut`, y ahora
  pre-entrena el encoder LSTM (auto-supervisado, por reconstrucción) sobre
  secuencias parcela-año SIN etiqueta de 2022-2025 (`USE_PRETRAINING=True`
  por defecto) antes de afinarlo en la tarea supervisada de 138 filas.
- **`07_ensemble.py`**: ya no combina solo dos modelos con pesos fijos --
  arma una matriz de predicciones OOF de varios modelos base (el ganador de
  04, LSTM+GP, y CatBoost/Stacking/ExtraTrees si están disponibles) y
  entrena un meta-modelo Ridge real (stacking) sobre esa matriz, evaluado
  con su propio K-Fold para que la comparación siga siendo honesta.
