"""
Paso 11 (opcional, scaffold) — Rendimiento histórico municipal de cebada
(SIAP) como covariable CONTINUA de contexto regional.

POR QUÉ: un prior de "cuánto rinde la cebada típicamente en este municipio"
es información agronómica legítima (refleja suelo, clima y prácticas locales
acumuladas por años) -- distinto de darle al modelo el NOMBRE del municipio
como categoría (que fue lo que causó la memorización de ubicación
diagnosticada en 04_train_and_evaluate.py: con Municipio como one-hot, el
modelo podía simplemente "recordar" el rendimiento promedio de cada
municipio en el set de entrenamiento sin aprender nada transferible). Un
rendimiento histórico continuo es distinto: es una variable numérica que
también existe, en principio, para municipios que el modelo nunca vio en
entrenamiento (aunque en este reto los 9 municipios están fijos, así que la
diferencia práctica es menor -- pero sigue siendo más defendible
metodológicamente y hay que RE-VALIDARLA con LeaveOneGroupOut, ver abajo).

IMPORTANTE -- A DIFERENCIA DE 08_soil_features.py, AQUÍ NO TE DOY UNA URL
DE DESCARGA: no tengo forma de verificar en este momento cuál es el enlace
exacto y vigente del portal de SIAP (cambia de estructura seguido, y ya me
equivoqué una vez asumiendo la estructura de un dataset público sin
verificarlo primero -- ver la corrección que tuvimos que hacer con el
shapefile de suelo de INEGI). Es mejor que TÚ descargues el archivo real y
me pegues las primeras filas / columnas si algo no cuadra, en vez de que yo
asuma una URL o un esquema de columnas que podría estar desactualizado.

CÓMO CONSEGUIR EL DATO (manual, una sola vez):
  1. Entra a SIAP (Servicio de Información Agroalimentaria y Pesquera):
     https://www.gob.mx/siap -- busca "Anuario Estadístico de la Producción
     Agrícola" o el buscador de "Cierre de la producción agrícola"
     (actualmente en https://nube.siap.gob.mx/cierreagricola/, pero verifica
     tú la URL vigente por si cambió).
  2. Filtra: Cultivo = "Cebada grano" (o el nombre exacto que use SIAP),
     Estados = Hidalgo, Puebla, Tlaxcala, y varios años recientes/anteriores
     a 2025 (ej. 2019-2024) para promediar y no depender de un solo año
     atípico.
  3. Exporta a CSV/Excel con el desglose por Municipio (no solo por Estado).
  4. Pon la ruta al archivo en SIAP_FILE abajo.
  5. Corre este script UNA VEZ solo para ver las columnas reales que trae tu
     archivo (se imprimen en consola) y ajusta SIAP_COLUMNS más abajo con
     los nombres exactos -- igual que se hizo con 08_soil_features.py.

Salida: outputs/11_siap/rendimiento_historico_municipio.csv
  (Municipio, rendimiento_historico_municipio_t_ha)

RE-VALIDACIÓN OBLIGATORIA: después de fusionar esta columna (ver
03_build_feature_table.py) y agregarla como NUMÉRICA (nunca como
categórica) a 04_train_and_evaluate.py, vuelve a correr el diagnóstico
LeaveOneGroupOut por Municipio -- si el RMSE de LOGO empeora mucho respecto
a no incluirla, es la misma señal de memorización de ubicación que ya se
vio con el one-hot de Municipio/Estado, y no conviene incluirla pese a ser
continua.
"""

import sys
from pathlib import Path
from importlib import import_module

sys.path.insert(0, str(Path(__file__).resolve().parent))
cfg = import_module("00_config")

import pandas as pd

OUT_DIR = cfg.OUTPUT_DIR / "11_siap"
OUT_DIR.mkdir(parents=True, exist_ok=True)

# EDITA ESTO: ruta al archivo que descargaste manualmente de SIAP (ver
# docstring arriba). Puede ser .csv o .xlsx -- el script detecta la
# extensión.
SIAP_FILE = None  # ej. r"C:\ruta\a\siap_cebada_hidalgo_puebla_tlaxcala.csv"

# EDITA ESTO tras la primera corrida (el script te imprime las columnas
# reales si SIAP_COLUMNS no calza). Nombres típicos del formato de
# exportación de SIAP -- NO CONFIRMADOS todavía contra un archivo real,
# ajústalos en cuanto veas las columnas de tu descarga.
SIAP_COLUMNS = {
    "municipio": "Municipio",
    "anio": "Anio",
    "rendimiento": "Rendimiento",  # normalmente en ton/ha
}

# Años a promediar (ANTERIORES al ciclo 2025 que se está evaluando -- nunca
# incluyas 2025 aquí, sería casi fuga de información del propio target).
ANIOS_HISTORICOS = list(range(2019, 2025))


def main():
    if SIAP_FILE is None:
        print(
            "[siap] Aún no configuraste SIAP_FILE en este script.\n"
            "1) Descarga el histórico de rendimiento de cebada por municipio de SIAP "
            "(ver docstring arriba -- verifica tú la URL vigente, no la traigo hardcodeada "
            "a propósito).\n"
            "2) Pon la ruta al archivo en SIAP_FILE.\n"
            "3) Vuelve a correr este script UNA VEZ para ver las columnas reales (se "
            "   imprimen abajo) y ajusta SIAP_COLUMNS con los nombres correctos.\n"
            "4) Corre de nuevo para generar outputs/11_siap/rendimiento_historico_municipio.csv."
        )
        return

    path = Path(SIAP_FILE)
    if not path.exists():
        print(f"[siap] AVISO: no encontré el archivo {path}. Revisa la ruta en SIAP_FILE.")
        return

    print(f"[siap] leyendo {path} ...")
    if path.suffix.lower() in (".xlsx", ".xls"):
        df = pd.read_excel(path)
    else:
        df = pd.read_csv(path)

    print(f"[siap] {len(df)} filas. Columnas disponibles: {df.columns.tolist()}")

    faltantes = [c for c in SIAP_COLUMNS.values() if c not in df.columns]
    if faltantes:
        print(f"[siap] AVISO: estas columnas de SIAP_COLUMNS no existen en el archivo: {faltantes}")
        print(f"[siap] Columnas reales disponibles: {df.columns.tolist()}")
        print("[siap] Ajusta SIAP_COLUMNS arriba con los nombres correctos (y revisa si el archivo "
              "  trae encabezados en otra fila -- algunos exports de SIAP traen 2-3 filas de título "
              "  antes del encabezado real, usa skiprows= en pd.read_csv/read_excel si es el caso) "
              "  y vuelve a correr.")
        return

    col_mun = SIAP_COLUMNS["municipio"]
    col_anio = SIAP_COLUMNS["anio"]
    col_rend = SIAP_COLUMNS["rendimiento"]

    df_hist = df[df[col_anio].isin(ANIOS_HISTORICOS)].copy()
    if df_hist.empty:
        print(f"[siap] AVISO: no quedó ninguna fila tras filtrar por ANIOS_HISTORICOS={ANIOS_HISTORICOS}. "
              f"Revisa qué valores trae realmente la columna '{col_anio}': {sorted(df[col_anio].unique())[:20]}")
        return

    agg = df_hist.groupby(col_mun)[col_rend].mean().reset_index()
    agg = agg.rename(columns={col_mun: "Municipio", col_rend: "rendimiento_historico_municipio_t_ha"})

    print(f"\n[siap] rendimiento histórico promedio ({min(ANIOS_HISTORICOS)}-{max(ANIOS_HISTORICOS)}) por municipio:")
    print(agg.to_string(index=False))

    out_path = OUT_DIR / "rendimiento_historico_municipio.csv"
    agg.to_csv(out_path, index=False)
    print(f"\n[siap] guardado en {out_path}")
    print(
        "\nPara usarlo en el modelo:\n"
        "  1) Fusiona esta tabla a outputs/03_features/features_dataset.csv por 'Municipio'\n"
        "     (el shapefile de parcelas ya trae esa columna, ver municip en 03_build_feature_table.py).\n"
        "  2) Agrega 'rendimiento_historico_municipio_t_ha' a los NUMERIC_COLS de "
        "     04_train_and_evaluate.py -- NUNCA a CATEGORICAL_COLS (el punto de esta variable es "
        "     justo ser continua, no una categoría más que el modelo pueda memorizar).\n"
        "  3) OBLIGATORIO: vuelve a correr el diagnóstico LeaveOneGroupOut por Municipio en 04 -- "
        "     si el RMSE agrupado empeora mucho al incluir esta variable, es la misma señal de "
        "     memorización de ubicación que ya se vio con el one-hot de Municipio/Estado, y no "
        "     conviene incluirla en el modelo final pese a ser numérica."
    )


if __name__ == "__main__":
    main()
