"""
Paso 7 — Ensemble del mejor modelo de árboles (04) + LSTM/GP (06), y
diagnóstico de residuos por municipio/estado/área.

Por qué: en tu corrida real, RandomForest (RMSE_cv 0.519) y LSTM+GP
(RMSE_cv 0.512) quedaron prácticamente empatados. Cuando dos modelos con
error parecido llegan ahí por caminos distintos (uno ve solo estadísticos
agregados de la temporada, el otro ve la serie de tiempo cruda + posición
geográfica), lo normal es que se equivoquen en parcelas distintas -- y
promediar sus predicciones casi siempre baja el error por debajo del mejor
modelo individual, sin necesitar un solo dato nuevo.

Este script:
  1. Recalcula predicciones "out-of-fold" (OOF) de varios modelos usando los
     MISMOS folds, para poder comparar y combinar de forma justa (nada de
     comparar un modelo evaluado en CV contra otro evaluado distinto).
  2. Compara: modelo ganador de 04 solo, LSTM+GP solo, promedio simple,
     promedio ponderado por el inverso del RMSE, y un STACKING REAL (un
     meta-modelo Ridge entrenado sobre las predicciones OOF de varios
     modelos base -- el ganador de 04, LSTM+GP, y CatBoost/Stacking/
     ExtraTrees si están disponibles -- en vez de pesos fijos elegidos a
     mano). El stacking se evalúa con su propio K-Fold para que la
     comparación siga siendo honesta (ver stacking_meta_oof()).
  3. Diagnostica en qué municipios/parcelas se concentran los errores más
     grandes (para saber qué variable te falta, no solo "el modelo falla").
  4. Genera la tabla final de predicción para las 59 parcelas ocultas con el
     esquema que haya ganado el comparativo del paso 2 (stacking real o
     promedio ponderado).

Salidas en outputs/07_ensemble/:
  - comparacion_ensemble.csv       (RMSE/MAE/R2 de cada esquema de combinación)
  - oof_predicciones.csv           (predicción OOF de cada modelo por parcela, para inspección)
  - residuos_por_municipio.csv     (dónde se concentra el error)
  - residuos_top20.csv             (las 20 parcelas peor predichas, para revisar a mano)
  - prediccion_ensemble_final_ton_ha.csv   (la tabla a usar en Anexos si el ensemble gana)
"""

import sys
from pathlib import Path
from importlib import import_module

sys.path.insert(0, str(Path(__file__).resolve().parent))
cfg = import_module("00_config")
mod04 = import_module("04_train_and_evaluate")
mod06 = import_module("06_paper_lstm_gp")

import numpy as np
import pandas as pd
import torch
from sklearn.model_selection import KFold
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.preprocessing import StandardScaler
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.linear_model import Ridge

# Modelos base adicionales (más allá del ganador de 04) que se incluyen como
# columnas extra del stacking real si están disponibles -- ver
# get_ml_oof_predictions_named() y main(). CatBoost y el propio
# StackingRegressor de 04 suelen aportar señal complementaria al ganador
# "puntual" de la comparación de RMSE.
EXTRA_BASE_MODELS = ["CatBoost", "Stacking", "ExtraTrees"]

OUT_DIR = cfg.OUTPUT_DIR / "07_ensemble"
OUT_DIR.mkdir(parents=True, exist_ok=True)


def get_ml_oof_predictions(df, train_ids, n_splits=5):
    """OOF del modelo ganador de 04 (mismo tipo/hiperparámetros, releído de
    features_seleccionadas.json), evaluado con folds fijos por ID."""
    feat_path = cfg.OUTPUT_DIR / "04_modelo" / "features_seleccionadas.json"
    if not feat_path.exists():
        raise SystemExit(f"No encontré {feat_path}. Corre primero 04_train_and_evaluate.py.")
    import json
    with open(feat_path) as f:
        feat_info = json.load(f)
    model_name = feat_info["modelo_ganador"]
    print(f"[ml] usando el modelo ganador de 04: {model_name}")

    train = df[df[cfg.ID_COL].isin(train_ids)].set_index(cfg.ID_COL).loc[train_ids].reset_index()

    exclude = set(mod04.ID_LIKE_COLS + [mod04.TARGET] + mod04.CATEGORICAL_COLS)
    numeric_cols_all = [c for c in df.columns if c not in exclude and pd.api.types.is_numeric_dtype(df[c])]

    kf = KFold(n_splits=n_splits, shuffle=True, random_state=cfg.RANDOM_STATE)
    oof = pd.Series(index=train.index, dtype=float)

    for tr_idx, te_idx in kf.split(train):
        fold_train = train.iloc[tr_idx]
        numeric_cols = mod04.select_features(fold_train, numeric_cols_all)
        categorical_cols = [c for c in mod04.CATEGORICAL_COLS if c in df.columns]

        candidates = mod04.get_candidates()
        model = candidates[model_name]
        pipe = mod04.build_pipeline(model, numeric_cols, categorical_cols)

        Xtr = fold_train[numeric_cols + categorical_cols]
        ytr = fold_train[mod04.TARGET]
        Xte = train.iloc[te_idx][numeric_cols + categorical_cols]

        pipe.fit(Xtr, ytr)
        oof.iloc[te_idx] = pipe.predict(Xte)

    return train[cfg.ID_COL].to_numpy(), oof.to_numpy()


def get_ml_oof_predictions_named(df, train_ids, model_name, n_splits=5):
    """
    Igual que get_ml_oof_predictions, pero para un modelo NOMBRADO específico
    (no necesariamente el ganador de 04) -- se usa para construir la matriz
    de predicciones OOF de varios modelos base para el stacking real (ver
    main()). Devuelve None si ese modelo no está disponible (ej. CatBoost no
    instalado), para que se omita sin romper el script.
    """
    train = df[df[cfg.ID_COL].isin(train_ids)].set_index(cfg.ID_COL).loc[train_ids].reset_index()
    exclude = set(mod04.ID_LIKE_COLS + [mod04.TARGET] + mod04.CATEGORICAL_COLS)
    numeric_cols_all = [c for c in df.columns if c not in exclude and pd.api.types.is_numeric_dtype(df[c])]

    kf = KFold(n_splits=n_splits, shuffle=True, random_state=cfg.RANDOM_STATE)
    oof = pd.Series(index=train.index, dtype=float)

    for tr_idx, te_idx in kf.split(train):
        fold_train = train.iloc[tr_idx]
        numeric_cols = mod04.select_features(fold_train, numeric_cols_all)
        categorical_cols = [c for c in mod04.CATEGORICAL_COLS if c in df.columns]

        candidates = mod04.get_candidates()
        if model_name not in candidates:
            return None
        model = candidates[model_name]
        pipe = mod04.build_pipeline(model, numeric_cols, categorical_cols)

        Xtr = fold_train[numeric_cols + categorical_cols]
        ytr = fold_train[mod04.TARGET]
        Xte = train.iloc[te_idx][numeric_cols + categorical_cols]

        pipe.fit(Xtr, ytr)
        oof.iloc[te_idx] = pipe.predict(Xte)

    return oof.to_numpy()


def get_hidden_predictions_named(df, train_ids, hidden_ids, model_name):
    """
    Reentrena el modelo `model_name` (de 04) con TODAS las filas de
    entrenamiento y predice sobre las parcelas ocultas -- para poder incluir
    ese modelo como columna del stacking también en el 30% oculto, no solo
    en el OOF de entrenamiento.
    """
    train = df[df[cfg.ID_COL].isin(train_ids)].set_index(cfg.ID_COL).loc[train_ids].reset_index()
    hidden = df[df[cfg.ID_COL].isin(hidden_ids)].set_index(cfg.ID_COL).loc[hidden_ids].reset_index()

    exclude = set(mod04.ID_LIKE_COLS + [mod04.TARGET] + mod04.CATEGORICAL_COLS)
    numeric_cols_all = [c for c in df.columns if c not in exclude and pd.api.types.is_numeric_dtype(df[c])]
    numeric_cols = mod04.select_features(train, numeric_cols_all)
    categorical_cols = [c for c in mod04.CATEGORICAL_COLS if c in df.columns]

    candidates = mod04.get_candidates()
    if model_name not in candidates:
        return None
    pipe = mod04.build_pipeline(candidates[model_name], numeric_cols, categorical_cols)
    pipe.fit(train[numeric_cols + categorical_cols], train[mod04.TARGET])
    return pipe.predict(hidden[numeric_cols + categorical_cols])


def stacking_meta_oof(oof_matrix, y_true, n_splits=5):
    """
    Stacking REAL: en vez de un promedio de pesos fijos (simple o por
    inverso del RMSE), entrena un meta-modelo Ridge que aprende cómo
    combinar las predicciones de los modelos base (columnas de oof_matrix).
    Para que la comparación siga siendo honesta (sin fuga de información),
    el meta-modelo también se evalúa con su propio K-Fold: en cada fold se
    entrena Ridge SOLO con las filas de entrenamiento de ESE fold (usando las
    predicciones OOF de los modelos base, que ya son out-of-fold respecto a
    ELLOS) y se predice sobre las filas de prueba de ese fold -- así el
    resultado reportado (meta_oof) es una estimación honesta de cuánto
    generaliza el stacking, no solo un ajuste sobre la misma muestra que lo
    entrenó.
    """
    kf = KFold(n_splits=n_splits, shuffle=True, random_state=cfg.RANDOM_STATE)
    meta_oof = np.full(len(y_true), np.nan)
    for tr_idx, te_idx in kf.split(oof_matrix):
        meta = Ridge(alpha=1.0, random_state=cfg.RANDOM_STATE)
        meta.fit(oof_matrix[tr_idx], y_true[tr_idx])
        meta_oof[te_idx] = meta.predict(oof_matrix[te_idx])
    return meta_oof


def get_lstm_gp_oof_predictions(train_ids, n_splits=5):
    """OOF del LSTM+GP de 06, con los MISMOS folds (mismo orden de IDs)."""
    target, sequences, week_index = mod06.build_dataset()
    n_channels = len(mod06.S2_CHANNELS) + len(mod06.PLANET_CHANNELS)

    target = target.set_index(cfg.ID_COL).loc[train_ids].reset_index()
    X = np.stack([sequences[pid] for pid in train_ids])
    y = target["rendimiento_t_ha"].to_numpy(dtype=float)

    lat_lon = mod06.get_lat_lon()

    kf = KFold(n_splits=n_splits, shuffle=True, random_state=cfg.RANDOM_STATE)
    oof = np.full(len(train_ids), np.nan)

    for tr_idx, te_idx in kf.split(X):
        means = np.nanmean(X[tr_idx], axis=(0, 1))
        stds = np.nanstd(X[tr_idx], axis=(0, 1))
        stds[stds == 0] = 1.0
        Xn = (X - means) / stds
        Xn = np.nan_to_num(Xn, nan=0.0)

        model = mod06.train_lstm(Xn[tr_idx], y[tr_idx], Xn[te_idx], y[te_idx], n_channels=n_channels)
        with torch.no_grad():
            _, emb_tr = model(torch.tensor(Xn[tr_idx], dtype=torch.float32))
            _, emb_te = model(torch.tensor(Xn[te_idx], dtype=torch.float32))
        emb_tr, emb_te = emb_tr.numpy(), emb_te.numpy()

        gp_Xtr, gp_Xte = emb_tr, emb_te
        if lat_lon is not None:
            ll = lat_lon.set_index(cfg.ID_COL).loc[train_ids][["lat", "lon"]].to_numpy()
            scaler = StandardScaler().fit(ll[tr_idx])
            gp_Xtr = np.hstack([emb_tr, scaler.transform(ll[tr_idx])])
            gp_Xte = np.hstack([emb_te, scaler.transform(ll[te_idx])])

        gp = GaussianProcessRegressor(kernel=mod06.make_gp_kernel(), normalize_y=True, n_restarts_optimizer=3, random_state=cfg.RANDOM_STATE)
        gp.fit(gp_Xtr, y[tr_idx])
        oof[te_idx] = gp.predict(gp_Xte)

    return np.array(train_ids), oof


def main():
    import json

    df = pd.read_csv(cfg.OUTPUT_DIR / "03_features" / "features_dataset.csv")
    train_ids = sorted(df.loc[df["CONJUNTO"] == "ENTRENAMIENTO", cfg.ID_COL].tolist())
    hidden_ids = sorted(df.loc[df["CONJUNTO"] != "ENTRENAMIENTO", cfg.ID_COL].tolist())
    print(f"[ensemble] {len(train_ids)} parcelas de entrenamiento, folds fijos y sincronizados entre todos los modelos")

    feat_path = cfg.OUTPUT_DIR / "04_modelo" / "features_seleccionadas.json"
    if not feat_path.exists():
        raise SystemExit(f"No encontré {feat_path}. Corre primero 04_train_and_evaluate.py.")
    with open(feat_path) as f:
        winner_name = json.load(f)["modelo_ganador"]

    ml_ids, ml_oof = get_ml_oof_predictions(df, train_ids)
    lstm_ids, lstm_oof = get_lstm_gp_oof_predictions(train_ids)
    assert list(ml_ids) == list(lstm_ids) == train_ids, "Los IDs no quedaron alineados entre modelos -- revisa el orden"

    y_true = df.set_index(cfg.ID_COL).loc[train_ids, "rendimiento_t_ha"].to_numpy()

    def metrics(pred):
        return (
            mean_squared_error(y_true, pred) ** 0.5,
            mean_absolute_error(y_true, pred),
            r2_score(y_true, pred),
        )

    rmse_ml, mae_ml, r2_ml = metrics(ml_oof)
    rmse_lstm, mae_lstm, r2_lstm = metrics(lstm_oof)

    simple_avg = (ml_oof + lstm_oof) / 2
    rmse_avg, mae_avg, r2_avg = metrics(simple_avg)

    w_ml = (1 / rmse_ml) / (1 / rmse_ml + 1 / rmse_lstm)
    w_lstm = 1 - w_ml
    weighted_avg = w_ml * ml_oof + w_lstm * lstm_oof
    rmse_w, mae_w, r2_w = metrics(weighted_avg)

    # --- Stacking REAL: matriz de OOF de VARIOS modelos base + meta-Ridge ---
    # A diferencia del promedio simple/ponderado de arriba (pesos fijos
    # elegidos a mano), aquí se arma una matriz con las predicciones OOF de
    # varios modelos base (el ganador de 04, LSTM+GP de 06, y los que estén
    # disponibles de EXTRA_BASE_MODELS -- CatBoost/Stacking/ExtraTrees, salvo
    # que ya sean el propio ganador) y se deja que un meta-modelo Ridge
    # aprenda los pesos óptimos de combinación, en vez de fijarlos a mano por
    # inverso del RMSE. stacking_meta_oof() evalúa esto de forma honesta con
    # su propio K-Fold (ver docstring de esa función).
    print(f"\n[ensemble-stack] modelo ganador de 04: {winner_name}. Agregando modelos base extra "
          f"({[m for m in EXTRA_BASE_MODELS if m != winner_name]}) para el stacking real ...")
    base_cols = {winner_name: ml_oof, "LSTM_GP": lstm_oof}
    for extra_name in EXTRA_BASE_MODELS:
        if extra_name == winner_name or extra_name in base_cols:
            continue
        extra_oof = get_ml_oof_predictions_named(df, train_ids, extra_name)
        if extra_oof is None:
            print(f"[ensemble-stack] AVISO: {extra_name} no disponible (¿no instalado?) -- se omite como base learner.")
            continue
        base_cols[extra_name] = extra_oof

    base_names = list(base_cols.keys())
    oof_matrix = np.column_stack([base_cols[n] for n in base_names])
    print(f"[ensemble-stack] {len(base_names)} modelos base en el stacking: {base_names}")

    meta_oof = stacking_meta_oof(oof_matrix, y_true)
    rmse_stack, mae_stack, r2_stack = metrics(meta_oof)

    comparison_rows = [
        {"esquema": f"{winner_name} (04) solo", "rmse_cv": rmse_ml, "mae_cv": mae_ml, "r2_cv": r2_ml},
        {"esquema": "LSTM+GP (06) solo", "rmse_cv": rmse_lstm, "mae_cv": mae_lstm, "r2_cv": r2_lstm},
        {"esquema": "Promedio simple (50/50)", "rmse_cv": rmse_avg, "mae_cv": mae_avg, "r2_cv": r2_avg},
        {"esquema": f"Promedio ponderado ({winner_name}={w_ml:.2f}, LSTM={w_lstm:.2f})", "rmse_cv": rmse_w, "mae_cv": mae_w, "r2_cv": r2_w},
        {"esquema": f"Stacking real (meta-Ridge sobre {len(base_names)} modelos: {', '.join(base_names)})",
         "rmse_cv": rmse_stack, "mae_cv": mae_stack, "r2_cv": r2_stack},
    ]
    comparison = pd.DataFrame(comparison_rows).sort_values("rmse_cv")
    comparison.to_csv(OUT_DIR / "comparacion_ensemble.csv", index=False)
    print("\n[ensemble] comparación de esquemas:")
    print(comparison.to_string(index=False))

    ganador = comparison.iloc[0]["esquema"]
    print(f"\n[ensemble] mejor esquema: {ganador}")
    usar_stacking = ganador.startswith("Stacking real")

    oof_df = pd.DataFrame({
        cfg.ID_COL: train_ids,
        "rendimiento_real": y_true,
        "pred_ml": ml_oof,
        "pred_lstm_gp": lstm_oof,
        "pred_promedio": simple_avg,
        "pred_ponderado": weighted_avg,
        "pred_stacking": meta_oof,
    })
    oof_df["residuo_ponderado"] = oof_df["rendimiento_real"] - oof_df["pred_ponderado"]
    oof_df["residuo_stacking"] = oof_df["rendimiento_real"] - oof_df["pred_stacking"]
    oof_df.to_csv(OUT_DIR / "oof_predicciones.csv", index=False)

    # --- Diagnóstico de residuos: ¿dónde se concentra el error? ---
    meta = df[[cfg.ID_COL, "Municipio", "Estado", "area_ha"]] if "Municipio" in df.columns else df[[cfg.ID_COL, "area_ha"]]
    diag = oof_df.merge(meta, on=cfg.ID_COL, how="left")
    diag["abs_residuo"] = diag["residuo_ponderado"].abs()

    if "Municipio" in diag.columns:
        por_municipio = diag.groupby(["Estado", "Municipio"]).agg(
            n_parcelas=(cfg.ID_COL, "count"),
            mae=("abs_residuo", "mean"),
            rendimiento_promedio=("rendimiento_real", "mean"),
        ).reset_index().sort_values("mae", ascending=False)
        por_municipio.to_csv(OUT_DIR / "residuos_por_municipio.csv", index=False)
        print("\n[ensemble] municipios con mayor error promedio (revisar si les falta alguna variable, ej. tipo de suelo):")
        print(por_municipio.head(10).to_string(index=False))

    top20 = diag.sort_values("abs_residuo", ascending=False).head(20)
    top20.to_csv(OUT_DIR / "residuos_top20.csv", index=False)
    print(f"\n[ensemble] guardadas las 20 parcelas peor predichas en {OUT_DIR / 'residuos_top20.csv'} -- "
          f"revísalas a mano, si comparten municipio/rango de área/elevación ahí está la pista de qué feature falta.")

    # --- Predicción final para las 59 parcelas ocultas ---
    pred_ml_path = cfg.OUTPUT_DIR / "05_prediccion" / "prediccion_final_ton_ha.csv"
    pred_lstm_path = cfg.OUTPUT_DIR / "06_paper_lstm_gp" / "prediccion_paper_ton_ha.csv"
    if pred_ml_path.exists() and pred_lstm_path.exists():
        p_ml = pd.read_csv(pred_ml_path)
        p_lstm = pd.read_csv(pred_lstm_path)
        merged = p_ml.merge(p_lstm, on="ID_parcela", suffixes=("_ml", "_lstm"))

        if usar_stacking:
            # El stacking ganó el comparativo de OOF -> hay que reproducir, en
            # las 59 parcelas ocultas, la MISMA matriz de columnas
            # (base_names) que se usó para entrenar el meta-Ridge, y aplicar
            # ese meta-modelo (ya entrenado sobre TODO el OOF de
            # entrenamiento, así que usa toda la información disponible)
            # para combinar. Reentrena cada modelo extra de 04 con las 138
            # filas completas y predice sobre las 59 ocultas; LSTM+GP ya trae
            # su predicción final (reentrenada con todo train) desde 06.
            print(f"\n[ensemble-stack] reentrenando meta-Ridge final sobre las {len(train_ids)} filas de "
                  f"entrenamiento y generando predicciones de cada modelo base para las {len(hidden_ids)} "
                  f"parcelas ocultas ...")
            meta_final = Ridge(alpha=1.0, random_state=cfg.RANDOM_STATE)
            meta_final.fit(oof_matrix, y_true)

            hidden_cols = {}
            for name in base_names:
                if name == "LSTM_GP":
                    hidden_cols[name] = merged.set_index("ID_parcela")["rendimiento_predicho_ton_ha_lstm"].reindex(hidden_ids).to_numpy()
                elif name == winner_name:
                    hidden_cols[name] = merged.set_index("ID_parcela")["rendimiento_predicho_ton_ha_ml"].reindex(hidden_ids).to_numpy()
                else:
                    pred_h = get_hidden_predictions_named(df, train_ids, hidden_ids, name)
                    hidden_cols[name] = pred_h

            hidden_matrix = np.column_stack([hidden_cols[n] for n in base_names])
            final_pred = meta_final.predict(hidden_matrix)
            merged["rendimiento_predicho_ton_ha"] = final_pred.round(3)
            nota = f"stacking real (meta-Ridge sobre {', '.join(base_names)})"
        else:
            merged["rendimiento_predicho_ton_ha"] = (
                w_ml * merged["rendimiento_predicho_ton_ha_ml"] + w_lstm * merged["rendimiento_predicho_ton_ha_lstm"]
            ).round(3)
            nota = f"promedio ponderado ({winner_name}={w_ml:.2f}/LSTM={w_lstm:.2f})"

        final = merged[["ID_parcela", "rendimiento_predicho_ton_ha"]].sort_values("ID_parcela")
        final.to_csv(OUT_DIR / "prediccion_ensemble_final_ton_ha.csv", index=False)
        print(f"\n[ensemble] tabla final combinada ({nota}) guardada en "
              f"{OUT_DIR / 'prediccion_ensemble_final_ton_ha.csv'} -- usa ESTA en Anexos (esquema ganador del comparativo de arriba).")
    else:
        print(f"\n[ensemble] AVISO: falta {pred_ml_path} o {pred_lstm_path}. Corre 05 y 06 primero para generar la tabla final combinada.")


if __name__ == "__main__":
    main()
