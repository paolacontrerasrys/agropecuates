"""
Paso 13 — Ablación por grupos de variables (responde la pregunta guía 3:
"¿qué combinación de variables funciona mejor?").

Entrena ExtraTrees (mismos hiperparámetros que 04) con distintos grupos de
variables y compara RMSE/MAE/R² con RepeatedKFold(5x3) y con
LeaveOneGroupOut por Municipio (RMSE agrupado sobre todas las predicciones, y promedio de RMSE por municipio como en 04). Salida: outputs/13_ablation/ablacion_grupos.csv
"""
import json, warnings
import numpy as np, pandas as pd
from sklearn.ensemble import ExtraTreesRegressor
from sklearn.impute import SimpleImputer
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import RepeatedKFold, LeaveOneGroupOut, cross_val_predict
import importlib.util, sys, pathlib
warnings.filterwarnings("ignore")
here = pathlib.Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("cfg", here/"00_config.py"); cfg = importlib.util.module_from_spec(spec); spec.loader.exec_module(cfg)
OUT = cfg.OUTPUT_DIR/"13_ablation"; OUT.mkdir(parents=True, exist_ok=True)

df = pd.read_csv(cfg.OUTPUT_DIR/"03_features"/"features_dataset.csv")
tr = df[df.CONJUNTO == "ENTRENAMIENTO"].reset_index(drop=True)
sel = json.load(open(cfg.OUTPUT_DIR/"04_modelo"/"features_seleccionadas.json"))["numeric"]
sel = [c for c in sel if c in tr.columns]
y = tr["rendimiento_t_ha"].values; grp = tr["Municipio"].values

is_nasa = lambda c: c.startswith("nasapower_")
is_clim = lambda c: c.startswith(("precip", "tmax", "tmin", "gdd"))
is_vi = lambda c: c.startswith(("hist_", "ciclo_", "ndvi_anom"))
is_topo = lambda c: c.startswith(("elev", "pend"))
G = {
  "Solo índices espectrales": [c for c in sel if is_vi(c)],
  "Solo clima CHIRPS/temperatura": [c for c in sel if is_clim(c)],
  "Solo NASA POWER (atmósfera)": [c for c in sel if is_nasa(c)],
  "Clima CHIRPS + NASA POWER": [c for c in sel if is_clim(c) or is_nasa(c)],
  "Índices + clima CHIRPS": [c for c in sel if is_vi(c) or is_clim(c)],
  "Índices + NASA POWER": [c for c in sel if is_vi(c) or is_nasa(c)],
  "Índices + clima + NASA POWER": [c for c in sel if is_vi(c) or is_clim(c) or is_nasa(c)],
  "Todas (índices+clima+NASA+topografía+área)": sel,
  "Todas menos índices espectrales": [c for c in sel if not is_vi(c)],
  "Todas menos NASA POWER": [c for c in sel if not is_nasa(c)],
  "Clima CHIRPS + NASA + suelo": [c for c in sel if is_clim(c) or is_nasa(c)] + ["@suelo"],
  "Todas + suelo (configuración de 04)": sel + ["@suelo"],
}
SUELO = [c for c in ["TEXTURA", "GRUPO1_agrupado"] if c in tr.columns]
suelo_oh = pd.get_dummies(tr[SUELO].astype(str)).astype(float) if SUELO else pd.DataFrame(index=tr.index)
mk = lambda: make_pipeline(SimpleImputer(strategy="median"), ExtraTreesRegressor(n_estimators=500, max_depth=8, min_samples_leaf=2, random_state=42, n_jobs=-1))
def m(y, p):
    e = p - y; return np.sqrt((e**2).mean()), np.abs(e).mean(), 1 - (e**2).sum()/((y-y.mean())**2).sum()
rows = []
for name, cols in G.items():
    if not cols: continue
    num = [c for c in cols if c != "@suelo"]
    X = (pd.concat([tr[num], suelo_oh], axis=1) if "@suelo" in cols else tr[num]).values; ps = []
    for rep in range(3):
        from sklearn.model_selection import KFold
        ps.append(cross_val_predict(mk(), X, y, cv=KFold(5, shuffle=True, random_state=42+rep)))
    r = np.mean([m(y, p) for p in ps], axis=0)
    pl = cross_val_predict(mk(), X, y, cv=LeaveOneGroupOut(), groups=grp)
    rl = m(y, pl)
    fold_rmse = np.mean([np.sqrt(((pl[grp == g] - y[grp == g])**2).mean()) for g in np.unique(grp)])
    rows.append(dict(grupo=name, n_variables=len(cols), rmse_logo_promedio_folds=fold_rmse, rmse_kfold=r[0], mae_kfold=r[1], r2_kfold=r[2], rmse_logo=rl[0], mae_logo=rl[1], r2_logo=rl[2]))
    print(f"{name:45s} n={len(cols):3d} KFold {r[0]:.3f} | LOGO(agrupado) {rl[0]:.3f} | LOGO(prom. folds) {fold_rmse:.3f}")
res = pd.DataFrame(rows).sort_values("rmse_kfold"); res.to_csv(OUT/"ablacion_grupos.csv", index=False)
print("\nGuardado:", OUT/"ablacion_grupos.csv")
