"""
Paso 8 (opcional) — Variables de suelo (INEGI, edafología) por parcela.

POR QUÉ: el modelo actual no sabe nada del suelo (textura, materia orgánica,
capacidad de retención de agua) -- variables con efecto directo y bien
documentado sobre rendimiento agrícola, y que ahora mismo faltan por
completo del feature set.

DE DÓNDE SACAR EL DATO (tienes que hacer esto tú, es manual, una sola vez):
  1. Ve a https://www.inegi.org.mx/app/biblioteca/ficha.html?upc=794551131916
     (catálogo INEGI: "Conjunto de datos vectorial edafológico, escala
     1:250 000, Serie II Continuo Nacional", edición 2024).
  2. Descarga el zip nacional único (~175 MB):
     https://www.inegi.org.mx/contenidos/productos/prod_serv/contenidos/espanol/bvinegi/productos/geografia/tematicas/Edafologia_hist/1_250_000/serie%20II/794551131916_s.zip
     OJO: a diferencia de otras cartas de INEGI, esta Serie II ya NO se
     distribuye por estado -- es un solo shapefile con cobertura de todo
     México (Entidad federativa: Estados Unidos Mexicanos). El spatial
     join de este script solo hará match con las 197 parcelas de
     Hidalgo/Puebla/Tlaxcala, así que no necesitas recortarlo tú mismo,
     pero si notas que tarda mucho en cargar (es un archivo grande),
     avísame y te agrego un recorte por bounding box antes del join.
  3. Descomprime el zip y anota la ruta al .shp en SOIL_SHAPEFILES abajo
     (una sola ruta, ya no tres).
  4. Ojo con la proyección: este shapefile viene en Cónica Conforme de
     Lambert, Datum ITRF92 (distinto a tus parcelas en EPSG:4326 y a la
     topografía en EPSG:6372) -- el script ya reproyecta automáticamente
     (`soil.to_crs(parcelas.crs)`), no tienes que hacer nada manual.

COLUMNAS REALES (ya confirmadas contra el shapefile del usuario, edición 2024):
  ['CLAVE_WRB', 'GRUPO1', 'CALIFS_G1', 'CALIFP_G1', 'GRUPO2', 'CALIFS_G2',
   'CALIFP_G2', 'GRUPO3', 'CALIFS_G3', 'CALIFP_G3', 'CLASE_TEX', 'FRUDICA',
   'N_G1', 'N_CS_G1', 'N_CP_G1', 'N_G2', 'N_CS_G2', 'N_CP_G2', 'N_G3',
   'N_CS_G3', 'N_CP_G3', 'TEXTURA', 'F_SUPERF', 'TIP_INFO', 'CAL_POS']

  - CLAVE_WRB: clave de la unidad de suelo dominante según WRB (ej. "Phaeozem háplico").
  - GRUPO1/GRUPO2/GRUPO3: hasta 3 grupos de suelo presentes en el polígono
    (suelos compuestos); GRUPO1 es el dominante -- la variable principal a usar.
  - CALIFS_G1/CALIFP_G1: calificadores secundario/principal del grupo 1
    (matices dentro del grupo, ej. "húmico", "cálcico").
  - CLASE_TEX / TEXTURA: clase textural (gruesa/media/fina).
  - FRUDICA: fase física (pedregosidad/rocosidad, si aplica).
  - F_SUPERF, TIP_INFO, CAL_POS: metadatos de fuente/calidad, no son
    variables de suelo en sí -- no los uses como feature.

Se usan GRUPO1 y TEXTURA por defecto abajo (la señal más directa y fácil
de interpretar para el reporte). Si quieres más granularidad, puedes
agregar CLAVE_WRB o CALIFP_G1 a SOIL_ATTR_COLUMNS.

Salida: outputs/08_soil/suelo_por_parcela.csv (ID_POLIGONO + columnas de suelo)
"""

import sys
from pathlib import Path
from importlib import import_module

sys.path.insert(0, str(Path(__file__).resolve().parent))
cfg = import_module("00_config")

import pandas as pd
import geopandas as gpd

OUT_DIR = cfg.OUTPUT_DIR / "08_soil"
OUT_DIR.mkdir(parents=True, exist_ok=True)

# Proyección estándar que INEGI usa en (casi) todas sus capas temáticas
# nacionales -- Cónica Conforme de Lambert, datum ITRF (equivalente a
# GRS80 para fines prácticos de reproyección). La usamos como fallback
# SOLO si el shapefile no trae su .prj (geometrías "naive", sin CRS
# definido), que es justo lo que le pasó a este archivo.
INEGI_LCC_CRS = (
    "+proj=lcc +lat_1=17.5 +lat_2=29.5 +lat_0=12 +lon_0=-102 "
    "+x_0=2500000 +y_0=0 +ellps=GRS80 +units=m +no_defs"
)

# EDITA ESTO: ruta al .shp nacional de edafología de INEGI que descargaste
# (Serie II Continuo Nacional -- un solo archivo, ya no por estado)
SOIL_SHAPEFILES = [
    # r"C:\ruta\a\794551131916_s\conjunto_de_datos\edafologia_serie2.shp",
]

# Ya confirmado contra tu shapefile: GRUPO1 = grupo de suelo dominante
# (WRB), TEXTURA = clase textural. Descomenta CLAVE_WRB si quieres más
# granularidad (más categorías -> más riesgo de sobreajuste con solo 138
# parcelas de entrenamiento, así que empieza con estas dos).
SOIL_ATTR_COLUMNS = ["GRUPO1", "TEXTURA"]


def main():
    if not SOIL_SHAPEFILES:
        print(
            "[suelo] Aún no configuraste SOIL_SHAPEFILES en este script.\n"
            "1) Descarga los shapefiles de edafología de INEGI (ver docstring arriba).\n"
            "2) Pon sus rutas en SOIL_SHAPEFILES.\n"
            "3) Vuelve a correr este script UNA VEZ para ver las columnas reales que trae "
            "   cada shapefile (se imprimen abajo) y ajusta SOIL_ATTR_COLUMNS con los nombres correctos.\n"
            "4) Corre de nuevo para generar outputs/08_soil/suelo_por_parcela.csv."
        )
        return

    print("[suelo] cargando shapefiles de edafología ...")
    soil_parts = []
    for shp in SOIL_SHAPEFILES:
        gdf = gpd.read_file(shp)
        print(f"[suelo] {shp}: {len(gdf)} polígonos. Columnas disponibles: {gdf.columns.tolist()}")
        soil_parts.append(gdf)
    soil = pd.concat(soil_parts, ignore_index=True)
    soil = gpd.GeoDataFrame(soil, geometry="geometry", crs=soil_parts[0].crs)

    if soil.crs is None:
        print(
            "[suelo] AVISO: el shapefile no trae CRS definido (geometrías "
            "'naive', probablemente el .prj no vino en el zip o está vacío). "
            "Asignando manualmente la proyección estándar de INEGI "
            "(Cónica Conforme de Lambert, datum ITRF/GRS80) -- si tus "
            "coordenadas salen mal ubicadas más adelante, avísame para "
            "ajustar los parámetros exactos."
        )
        soil = soil.set_crs(INEGI_LCC_CRS, allow_override=True)

    faltantes = [c for c in SOIL_ATTR_COLUMNS if c not in soil.columns]
    if faltantes:
        print(f"[suelo] AVISO: estas columnas de SOIL_ATTR_COLUMNS no existen en el shapefile: {faltantes}")
        print(f"[suelo] Columnas reales disponibles: {soil.columns.tolist()}")
        print("[suelo] Ajusta SOIL_ATTR_COLUMNS arriba con los nombres correctos y vuelve a correr.")
        return

    parcelas = gpd.read_file(cfg.PARCELAS_SHP)
    id_col_shp = [c for c in parcelas.columns if c.upper().startswith("ID_POLIGON")][0]
    parcelas = parcelas.rename(columns={id_col_shp: cfg.ID_COL})

    soil = soil.to_crs(parcelas.crs)

    # Sanity check: si asumimos mal la proyección de origen (CRS faltante
    # en el shapefile), el resultado reproyectado caería fuera de México
    # por completo -- mejor detectarlo aquí que dejar que el join falle
    # en silencio (0 matches).
    minx, miny, maxx, maxy = soil.total_bounds
    if not (-120 <= minx <= -85 and -120 <= maxx <= -85 and 13 <= miny <= 34 and 13 <= maxy <= 34):
        print(
            f"[suelo] AVISO: tras reproyectar, el bounding box del shapefile "
            f"de suelo es ({minx:.2f}, {miny:.2f}, {maxx:.2f}, {maxy:.2f}), "
            f"que NO parece caer dentro de México (lon -120..-85, lat 13..34, "
            f"rango amplio para cubrir Baja California). Es probable que la "
            f"proyección INEGI_LCC_CRS asumida arriba no sea la correcta para "
            f"este archivo -- pégame este bounding box y el error para "
            f"ajustar los parámetros antes de seguir."
        )
    else:
        print(
            f"[suelo] bounding box tras reproyectar: ({minx:.2f}, {miny:.2f}, "
            f"{maxx:.2f}, {maxy:.2f}) -- cae dentro de México, la proyección "
            f"asumida fue correcta."
        )

    # Usamos el centroide de cada parcela (en vez de la geometría completa)
    # para el spatial join: más robusto cuando una parcela cae justo en el
    # borde entre dos unidades de suelo, y suficiente dado que las unidades
    # edafológicas de INEGI (escala 1:250,000) son mucho más grandes que
    # cualquier parcela agrícola individual.
    # El centroide se calcula en EPSG:6372 (proyección métrica de México,
    # la misma que usa 02_extract_geo_features.py) y luego se regresa a la
    # proyección de las parcelas para el join -- calcular centroides
    # directamente en grados (lon/lat) da una ligera distorsión y dispara
    # un warning de geopandas.
    CENTROID_CRS = "EPSG:6372"
    centroids = parcelas.copy()
    centroids["geometry"] = centroids.to_crs(CENTROID_CRS).geometry.centroid.to_crs(parcelas.crs)

    joined = gpd.sjoin(centroids, soil[SOIL_ATTR_COLUMNS + ["geometry"]], how="left", predicate="within")
    out = joined[[cfg.ID_COL] + SOIL_ATTR_COLUMNS].drop_duplicates(subset=cfg.ID_COL)

    sin_match = out[SOIL_ATTR_COLUMNS[0]].isna().sum()
    if sin_match:
        print(f"[suelo] AVISO: {sin_match} parcela(s) no cayeron dentro de ningún polígono de suelo "
              f"(posiblemente por bordes/errores de digitalización) -- revisa esos IDs a mano.")
    else:
        print(f"[suelo] las {len(out)} parcelas hicieron match correctamente.")
        for col in SOIL_ATTR_COLUMNS:
            print(f"[suelo] distribución de '{col}':")
            print(out[col].value_counts(dropna=False).to_string())

    # Con solo 138 parcelas de entrenamiento, una categoría con muy pocas
    # observaciones (ej. Andosol/Vertisol con 3-6 parcelas en total) aporta
    # más ruido que señal a un one-hot -- puede terminar con 1-2 filas en
    # train, o aparecer en el 30% de evaluación sin haber aparecido nunca
    # en entrenamiento. Agrupamos las categorías raras de GRUPO1 en "OTRO"
    # (umbral: menos de MIN_CATEGORIA_COUNT parcelas en el total de 197) y
    # guardamos ambas versiones -- la cruda para el reporte/EDA, la
    # agrupada para alimentar el modelo.
    MIN_CATEGORIA_COUNT = 10
    if "GRUPO1" in out.columns:
        conteos = out["GRUPO1"].value_counts()
        raras = conteos[conteos < MIN_CATEGORIA_COUNT].index.tolist()
        out["GRUPO1_agrupado"] = out["GRUPO1"].apply(lambda v: "OTRO" if v in raras else v)
        if raras:
            print(
                f"[suelo] GRUPO1_agrupado: se agruparon estas categorías "
                f"raras (<{MIN_CATEGORIA_COUNT} parcelas) en 'OTRO': {raras}"
            )
            print(out["GRUPO1_agrupado"].value_counts(dropna=False).to_string())

    out_path = OUT_DIR / "suelo_por_parcela.csv"
    out.to_csv(out_path, index=False)
    print(f"[suelo] guardado en {out_path} ({len(out)} parcelas)")
    print(
        "\nPara usar esto en el modelo: fusiona GRUPO1_agrupado y TEXTURA a "
        "outputs/03_features/features_dataset.csv por ID_POLIGONO, y agrégalas "
        "a la lista CATEGORICAL_COLS en 04_train_and_evaluate.py. Usa "
        "GRUPO1_agrupado (no GRUPO1) para el modelo -- GRUPO1 crudo sí sirve "
        "para el reporte/EDA y para responder con más detalle las preguntas guía."
    )


if __name__ == "__main__":
    main()
