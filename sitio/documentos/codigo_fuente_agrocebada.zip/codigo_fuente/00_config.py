"""
Configuración central del pipeline — Reto AgroCebada 2026.

EDITA SOLO ESTA PARTE con las rutas reales en tu computadora.
Todos los demás scripts importan las rutas desde aquí, así que solo tienes
que ajustarlas una vez.
"""

from pathlib import Path

# -----------------------------------------------------------------------
# 1) Carpeta raíz donde descomprimiste el dataset oficial del reto.
#    Debe ser la carpeta que contiene directamente:
#      Conjunto_datos_BASICO_AgroCebada2026.csv
#      Conjunto_datos_PRO_AgroCebada.csv
#      ID_area_rendimiento_70_30_Reto_AgroCebada.csv
#      Parcelas_Reto_AGC_CONJUNTO_70_30/  (carpeta con el shapefile)
#      Reto_AgroCebada_CHIRPS_Precipitacion_2022_2025.zip
#      Reto_AgroCebada_Temperatura_2022_2025_RECORTADA_CHIRPS.zip
#      Reto_AgroCebada_Topografia_INEGI_CEM4.zip
# -----------------------------------------------------------------------
DATASET_DIR = Path(r"C:\Users\japal\Downloads\agrodinero\DataSet\DATASET_RETO_AGRO_2026")

# Carpeta de trabajo para descomprimir los .zip de clima/topografía (se crea sola)
WORKDIR = Path(__file__).resolve().parent.parent / "data" / "raw_extracted"

# Carpeta de salidas (csvs intermedios, gráficas, modelo final, predicciones)
OUTPUT_DIR = Path(__file__).resolve().parent.parent / "outputs"

# -----------------------------------------------------------------------
# 2) Rutas derivadas (normalmente no necesitas tocar esto)
# -----------------------------------------------------------------------
BASICO_CSV = DATASET_DIR / "Conjunto_datos_BASICO_AgroCebada2026.csv"
PRO_CSV = DATASET_DIR / "Conjunto_datos_PRO_AgroCebada.csv"
ID_RENDIMIENTO_CSV = DATASET_DIR / "ID_area_rendimiento_70_30_Reto_AgroCebada.csv"
PARCELAS_SHP = DATASET_DIR / "Parcelas_Reto_AGC_CONJUNTO_70_30" / "Parcelas_Reto_AGC_CONJUNTO.shp"

CHIRPS_ZIP = DATASET_DIR / "Reto_AgroCebada_CHIRPS_Precipitacion_2022_2025.zip"
TEMP_ZIP = DATASET_DIR / "Reto_AgroCebada_Temperatura_2022_2025_RECORTADA_CHIRPS.zip"
TOPO_ZIP = DATASET_DIR / "Reto_AgroCebada_Topografia_INEGI_CEM4.zip"

# -----------------------------------------------------------------------
# 3) Parámetros del ciclo agrícola
#    El rendimiento entregado corresponde al ciclo abril-octubre 2025
#    (según Descripcion_general_variables_DataSet.docx). Todo el
#    feature engineering de la "temporada objetivo" debe enfocarse en
#    esta ventana; los años 2022-2024 sirven como referencia histórica
#    / features de anomalía, no como ciclo a predecir.
# -----------------------------------------------------------------------
CICLO_INICIO = "2025-04-01"
CICLO_FIN = "2025-10-31"

HIST_INICIO = "2022-01-01"
HIST_FIN = "2024-12-31"

# Nombre de columna identificador de parcela, estandarizado a través de
# todo el pipeline (en el shapefile viene truncado como "ID_POLIGON").
ID_COL = "ID_POLIGONO"

RANDOM_STATE = 42

for d in (WORKDIR, OUTPUT_DIR):
    d.mkdir(parents=True, exist_ok=True)
