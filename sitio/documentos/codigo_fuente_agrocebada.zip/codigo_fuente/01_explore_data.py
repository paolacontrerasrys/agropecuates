"""
Paso 1 — Exploración inicial del dataset.

Objetivo: entender qué tenemos, cuánta cobertura satelital real hay por
parcela y por fecha, cómo se ve la distribución del rendimiento, y dejar
constancia (csv + gráficas) de todo esto en outputs/01_eda/.

No requiere geopandas/rasterio todavía — solo pandas/matplotlib.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from importlib import import_module

cfg = import_module("00_config")

import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

EDA_DIR = cfg.OUTPUT_DIR / "01_eda"
EDA_DIR.mkdir(parents=True, exist_ok=True)


def load_target():
    df = pd.read_csv(cfg.ID_RENDIMIENTO_CSV)
    df = df.rename(columns={"RENDIMIENTO_T_HA": "rendimiento_t_ha", "AREA_HA": "area_ha"})
    df = df[[cfg.ID_COL, "area_ha", "rendimiento_t_ha", "CONJUNTO"]]
    print(f"[target] {len(df)} parcelas totales")
    print(df["CONJUNTO"].value_counts().to_string())
    return df


def eda_target(df):
    train = df[df["CONJUNTO"] == "ENTRENAMIENTO"]
    print("\n[target] estadísticos de rendimiento_t_ha (solo ENTRENAMIENTO):")
    print(train["rendimiento_t_ha"].describe().to_string())

    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    train["rendimiento_t_ha"].hist(bins=20, ax=axes[0])
    axes[0].set_title("Distribución de rendimiento (ton/ha)")
    axes[0].set_xlabel("ton/ha")

    axes[1].scatter(train["area_ha"], train["rendimiento_t_ha"], alpha=0.6)
    axes[1].set_xlabel("Área (ha)")
    axes[1].set_ylabel("Rendimiento (ton/ha)")
    axes[1].set_title("Área vs rendimiento")
    plt.tight_layout()
    plt.savefig(EDA_DIR / "target_distribution.png", dpi=150)
    plt.close()
    print(f"[target] gráfica guardada en {EDA_DIR / 'target_distribution.png'}")


def eda_satellite(csv_path, name, id_col=None):
    print(f"\n[{name}] cargando {csv_path.name} ...")
    df = pd.read_csv(csv_path)
    df["fecha_captura"] = pd.to_datetime(df["fecha_captura"], format="%d/%m/%Y", errors="coerce")

    print(f"[{name}] shape: {df.shape}")
    print(f"[{name}] parcelas únicas: {df['ID_POLIGONO'].nunique()}")
    print(f"[{name}] rango de fechas: {df['fecha_captura'].min()} -> {df['fecha_captura'].max()}")
    if "sensor" in df.columns:
        print(f"[{name}] observaciones por sensor:\n{df['sensor'].value_counts().to_string()}")

    # % de NaN por columna (para saber qué tan completo está cada índice)
    na_pct = (df.isna().mean() * 100).sort_values(ascending=False)
    na_pct.to_csv(EDA_DIR / f"{name}_na_percent.csv", header=["pct_nan"])
    print(f"[{name}] columnas con más de 50% NaN: {(na_pct > 50).sum()} de {len(na_pct)}")

    # cobertura de nubosidad
    if "porcentaje_nubosidad" in df.columns:
        fig, ax = plt.subplots(figsize=(6, 4))
        df["porcentaje_nubosidad"].hist(bins=30, ax=ax)
        ax.set_title(f"{name}: % nubosidad por observación")
        plt.tight_layout()
        plt.savefig(EDA_DIR / f"{name}_nubosidad.png", dpi=150)
        plt.close()

    # observaciones por parcela dentro del ciclo objetivo (abril-oct 2025)
    ciclo = df[(df["fecha_captura"] >= cfg.CICLO_INICIO) & (df["fecha_captura"] <= cfg.CICLO_FIN)]
    obs_por_parcela = ciclo.groupby("ID_POLIGONO").size()
    print(
        f"[{name}] observaciones dentro del ciclo abril-oct 2025 por parcela: "
        f"media={obs_por_parcela.mean():.1f}, min={obs_por_parcela.min()}, max={obs_por_parcela.max()}"
    )
    faltantes = set(pd.read_csv(cfg.ID_RENDIMIENTO_CSV)[cfg.ID_COL]) - set(obs_por_parcela.index)
    if faltantes:
        print(f"[{name}] ATENCIÓN: {len(faltantes)} parcelas SIN ninguna observación en el ciclo: {sorted(faltantes)}")

    return df


def main():
    target = load_target()
    eda_target(target)

    eda_satellite(cfg.BASICO_CSV, "basico")
    eda_satellite(cfg.PRO_CSV, "pro")

    print(f"\nListo. Revisa los csv/png en: {EDA_DIR}")


if __name__ == "__main__":
    main()
