"""
Paso 9 (opcional) — Sentinel-1 (radar SAR) por parcela, vía Google Earth Engine.

POR QUÉ: Sentinel-2/Landsat/Planet (lo que ya usas) son ópticos -- se pierden
por completo cuando hay nubes (viste el campo `porcentaje_nubosidad`, y
muchas fechas quedan sin dato utilizable). Sentinel-1 es radar: atraviesa
nubes, así que te da señal de humedad de suelo/estructura del cultivo
incluso en los meses más nublados del ciclo -- justo donde el resto de tus
datos tiene más huecos que interpolar.

SETUP QUE TIENES QUE HACER (una sola vez, gratis para estudiantes):
  1. Crea una cuenta en https://earthengine.google.com/ (Google Earth Engine)
     -- es gratuita para uso no comercial/académico, se aprueba en minutos u horas.
  2. pip install earthengine-api geemap
  3. En una terminal: earthengine authenticate
     (abre el navegador, inicia sesión con la cuenta de Google que registraste en GEE)
  4. Edita GEE_PROJECT abajo con el ID de tu proyecto de Google Cloud asociado
     a Earth Engine (Earth Engine te lo pide/crea al registrarte).

Este script no se pudo probar en este sandbox (Earth Engine necesita
autenticación interactiva con tu cuenta), pero la lógica de extracción sigue
el mismo patrón que ya usaste y funcionó en 02_extract_geo_features.py
(agregación mensual, un valor por parcela y mes), solo que aquí la
computación pesada la hace el servidor de Google, no tu máquina.

Salida: outputs/09_sentinel1/sentinel1_mensual_por_parcela.csv
  (ID_POLIGONO, anio, mes, vv_mean, vh_mean, vv_vh_ratio)
"""

import sys
from pathlib import Path
from importlib import import_module

sys.path.insert(0, str(Path(__file__).resolve().parent))
cfg = import_module("00_config")

import pandas as pd
import geopandas as gpd

try:
    import ee
except ImportError:
    raise SystemExit(
        "Falta la librería de Earth Engine. Instálala con:\n"
        "    pip install earthengine-api\n"
        "y autentícate una vez con:\n"
        "    earthengine authenticate"
    )

OUT_DIR = cfg.OUTPUT_DIR / "09_sentinel1"
OUT_DIR.mkdir(parents=True, exist_ok=True)

# EDITA ESTO con tu ID de proyecto de Google Cloud / Earth Engine
GEE_PROJECT = "tu-proyecto-de-earth-engine"


def parcelas_to_ee_featurecollection():
    gdf = gpd.read_file(cfg.PARCELAS_SHP)
    id_col_shp = [c for c in gdf.columns if c.upper().startswith("ID_POLIGON")][0]
    gdf = gdf.rename(columns={id_col_shp: cfg.ID_COL})
    gdf = gdf.to_crs("EPSG:4326")  # Earth Engine espera lon/lat WGS84

    features = []
    for _, row in gdf.iterrows():
        geom = ee.Geometry(row.geometry.__geo_interface__)
        features.append(ee.Feature(geom, {cfg.ID_COL: row[cfg.ID_COL]}))
    return ee.FeatureCollection(features)


def monthly_s1_composite(year, month, aoi):
    start = ee.Date.fromYMD(year, month, 1)
    end = start.advance(1, "month")
    coll = (
        ee.ImageCollection("COPERNICUS/S1_GRD")
        .filterBounds(aoi)
        .filterDate(start, end)
        .filter(ee.Filter.eq("instrumentMode", "IW"))
        .filter(ee.Filter.listContains("transmitterReceiverPolarisation", "VV"))
        .filter(ee.Filter.listContains("transmitterReceiverPolarisation", "VH"))
        .select(["VV", "VH"])
    )
    return coll.mean()


def main():
    ee.Initialize(project=GEE_PROJECT)
    print("[s1] Earth Engine inicializado.")

    fc = parcelas_to_ee_featurecollection()
    print(f"[s1] {fc.size().getInfo()} parcelas cargadas a Earth Engine.")

    rows = []
    for year in range(2022, 2026):
        for month in range(1, 13):
            print(f"[s1] procesando {year}-{month:02d} ...")
            image = monthly_s1_composite(year, month, fc)

            stats = image.reduceRegions(
                collection=fc,
                reducer=ee.Reducer.mean(),
                scale=10,  # resolución nativa de Sentinel-1 GRD
            ).getInfo()

            for feat in stats["features"]:
                props = feat["properties"]
                vv = props.get("VV")
                vh = props.get("VH")
                rows.append({
                    cfg.ID_COL: props.get(cfg.ID_COL),
                    "anio": year,
                    "mes": month,
                    "vv_mean": vv,
                    "vh_mean": vh,
                    "vv_vh_ratio": (vv / vh) if (vv is not None and vh not in (None, 0)) else None,
                })

    df = pd.DataFrame(rows)
    out_path = OUT_DIR / "sentinel1_mensual_por_parcela.csv"
    df.to_csv(out_path, index=False)
    print(f"[s1] guardado en {out_path} ({len(df)} filas)")
    print(
        "\nPara usarlo: agrega estas columnas a 03_build_feature_table.py "
        "igual que se hizo con precipitación/temperatura (agregando por el "
        "ciclo abril-octubre y calculando anomalías vs. 2022-2024)."
    )


if __name__ == "__main__":
    main()
