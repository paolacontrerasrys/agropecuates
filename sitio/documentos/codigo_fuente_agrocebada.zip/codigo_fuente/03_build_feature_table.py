"""
Paso 3 — Construcción de la tabla de features lista para modelar.

Combina:
  - Series de tiempo satelitales (Básico: Sentinel-2 + Landsat/VI6T; PRO: Planet)
    resumidas dentro del ciclo objetivo (abril-octubre 2025) en estadísticos +
    features de fenología (fecha del pico, tasa de crecimiento, área bajo la curva).
  - Anomalías respecto al promedio histórico 2022-2024 de la misma parcela
    (mismo rango de meses, para no comparar cebada contra otro cultivo/época).
  - Clima mensual (precipitación, Tmin, Tmax) agregado al ciclo + grados-día
    de crecimiento (GDD) + anomalía climática histórica.
  - Topografía estática (elevación, pendiente).
  - Área de la parcela, Municipio y Estado (categóricas).

Salida: outputs/03_features/features_dataset.csv
  - Incluye TODAS las 197 parcelas, columna CONJUNTO para separar
    ENTRENAMIENTO (con rendimiento_t_ha) de PREDICCION (sin rendimiento_t_ha).
  - Si ya corriste 08_soil_features.py, este script también fusiona
    GRUPO1, GRUPO1_agrupado y TEXTURA (suelo INEGI) por ID_POLIGONO.
  - Si ya corriste 10_nasa_power_features.py, fusiona las columnas
    nasapower_{srad,rh,wind,vpd}_{ciclo,hist,anomalia} por ID_POLIGONO.
  - Si ya corriste 11_siap_historical_yield.py, fusiona
    rendimiento_historico_municipio_t_ha por Municipio.
  Los tres son opcionales: si el archivo correspondiente no existe todavía,
  simplemente se omite y el resto del pipeline sigue igual (mismo patrón
  de degradación controlada para los tres).
"""

import sys
from pathlib import Path
from importlib import import_module

sys.path.insert(0, str(Path(__file__).resolve().parent))
cfg = import_module("00_config")

import numpy as np
import pandas as pd
import geopandas as gpd

FEAT_DIR = cfg.OUTPUT_DIR / "03_features"
FEAT_DIR.mkdir(parents=True, exist_ok=True)

# Índices espectrales del dataset Básico (Sentinel-2) que sí conviene resumir.
# (excluye VI6T, que viene de Landsat y se trata aparte)
BASICO_INDICES = [
    "ndvi", "evi", "crc", "mcrc", "ndsvi", "srndi", "mra", "lai", "fapar",
    "savi", "ndti", "sti", "ndwi", "endwi", "msi", "emsi",
    "dswi2", "dswi3", "dswi4", "dswi5", "nddi", "enddi",
]
PRO_INDICES = ["ndvi", "evi", "lai", "msavi"]


def phenology_features(df: pd.DataFrame, value_col: str, prefix: str) -> pd.DataFrame:
    """
    A partir de una serie temporal (fecha, valor) por parcela, calcula:
      - mean/std/max/min (nivel general)
      - doy_max: día del año donde ocurrió el valor máximo (pico fenológico)
      - green_up_rate: pendiente lineal simple del valor en función del tiempo
        (proxy de qué tan rápido crece el cultivo)
      - auc: área bajo la curva (trapecio) normalizada por duración -> proxy
        de biomasa acumulada durante el ciclo
    """
    out = []
    for pid, g in df.dropna(subset=[value_col]).groupby(cfg.ID_COL):
        g = g.sort_values("fecha_captura")
        if len(g) == 0:
            continue
        vals = g[value_col].to_numpy(dtype=float)
        days = (g["fecha_captura"] - g["fecha_captura"].min()).dt.days.to_numpy(dtype=float)

        row = {cfg.ID_COL: pid}
        row[f"{prefix}_mean"] = np.mean(vals)
        row[f"{prefix}_std"] = np.std(vals)
        row[f"{prefix}_max"] = np.max(vals)
        row[f"{prefix}_min"] = np.min(vals)
        row[f"{prefix}_doy_max"] = int(g.loc[g[value_col].idxmax(), "fecha_captura"].dayofyear)

        if len(vals) >= 2 and days.max() > 0:
            slope = np.polyfit(days, vals, 1)[0]
            _trapz = getattr(np, "trapezoid", None) or np.trapz
            auc = _trapz(vals, days) / days.max()
        else:
            slope, auc = np.nan, vals[0]
        row[f"{prefix}_green_up_rate"] = slope
        row[f"{prefix}_auc"] = auc
        out.append(row)
    return pd.DataFrame(out)


def build_basico_features(cycle_start, cycle_end, tag, month_range=None):
    """
    month_range: si se especifica (mes_ini, mes_fin), en vez de filtrar por un
    rango de fechas absoluto se filtra por MES DEL AÑO dentro de
    [cycle_start, cycle_end] (por año). Esto es lo que usamos para el
    histórico 2022-2024: queremos abril-octubre de cada uno de esos años,
    no el año completo (si no, la comparación de anomalía queda contaminada
    por el resto de las estaciones del año).
    """
    df = pd.read_csv(cfg.BASICO_CSV)
    df["fecha_captura"] = pd.to_datetime(df["fecha_captura"], format="%d/%m/%Y", errors="coerce")
    df = df[(df["fecha_captura"] >= cycle_start) & (df["fecha_captura"] <= cycle_end)]
    if month_range is not None:
        m_ini, m_fin = month_range
        df = df[df["fecha_captura"].dt.month.between(m_ini, m_fin)]

    s2 = df[df["sensor"] == "Sentinel-2"]
    ls = df[df["sensor"] == "Landsat"]

    feats = None
    for idx in BASICO_INDICES:
        col = f"{idx}_promedio"
        if col not in s2.columns:
            continue
        f = phenology_features(s2, col, f"{tag}_{idx}")
        feats = f if feats is None else feats.merge(f, on=cfg.ID_COL, how="outer")

    if "vi6t_promedio" in ls.columns:
        f_vi6t = phenology_features(ls, "vi6t_promedio", f"{tag}_vi6t")
        feats = f_vi6t if feats is None else feats.merge(f_vi6t, on=cfg.ID_COL, how="outer")

    # nubosidad media del periodo, como variable de calidad de la serie
    nub = df.groupby(cfg.ID_COL)["porcentaje_nubosidad"].mean().rename(f"{tag}_nubosidad_media")
    feats = feats.merge(nub, on=cfg.ID_COL, how="outer") if feats is not None else nub.reset_index()

    return feats


def build_pro_features(cycle_start, cycle_end, tag="ciclo_pro"):
    df = pd.read_csv(cfg.PRO_CSV)
    df["fecha_captura"] = pd.to_datetime(df["fecha_captura"], format="%d/%m/%Y", errors="coerce")
    df = df[(df["fecha_captura"] >= cycle_start) & (df["fecha_captura"] <= cycle_end)]

    feats = None
    for idx in PRO_INDICES:
        col = f"{idx}_promedio"
        if col not in df.columns:
            continue
        f = phenology_features(df, col, f"{tag}_{idx}")
        feats = f if feats is None else feats.merge(f, on=cfg.ID_COL, how="outer")

    nub = df.groupby(cfg.ID_COL)["porcentaje_nubosidad"].mean().rename(f"{tag}_nubosidad_media")
    feats = feats.merge(nub, on=cfg.ID_COL, how="outer") if feats is not None else nub.reset_index()
    return feats


def build_climate_cycle_features(clima_path: Path, base_temp_c: float = 5.0):
    clima = pd.read_csv(clima_path)
    clima["fecha"] = pd.to_datetime(dict(year=clima["anio"], month=clima["mes"], day=1))

    ciclo = clima[(clima["fecha"] >= cfg.CICLO_INICIO) & (clima["fecha"] <= cfg.CICLO_FIN)]
    hist = clima[(clima["fecha"] >= cfg.HIST_INICIO) & (clima["fecha"] <= cfg.HIST_FIN)]
    # mismos meses (abril-octubre) pero años 2022-2024, para comparar anomalías
    meses_ciclo = pd.to_datetime(cfg.CICLO_INICIO).month, pd.to_datetime(cfg.CICLO_FIN).month
    hist_mismos_meses = hist[hist["mes"].between(meses_ciclo[0], meses_ciclo[1])]

    def gdd(row):
        tmean = (row["tmax_c"] + row["tmin_c"]) / 2
        return max(0.0, tmean - base_temp_c)

    ciclo = ciclo.copy()
    ciclo["gdd_mensual"] = ciclo.apply(gdd, axis=1) * 30  # aprox días del mes

    agg_ciclo = ciclo.groupby(cfg.ID_COL).agg(
        precip_total_ciclo=("precip_mm", "sum"),
        precip_media_ciclo=("precip_mm", "mean"),
        tmax_media_ciclo=("tmax_c", "mean"),
        tmin_media_ciclo=("tmin_c", "mean"),
        gdd_total_ciclo=("gdd_mensual", "sum"),
    ).reset_index()

    agg_hist = hist_mismos_meses.groupby(cfg.ID_COL).agg(
        precip_media_hist=("precip_mm", "mean"),
        tmax_media_hist=("tmax_c", "mean"),
        tmin_media_hist=("tmin_c", "mean"),
    ).reset_index()

    out = agg_ciclo.merge(agg_hist, on=cfg.ID_COL, how="left")
    out["precip_anomalia"] = out["precip_media_ciclo"] - out["precip_media_hist"]
    out["tmax_anomalia"] = out["tmax_media_ciclo"] - out["tmax_media_hist"]
    return out


def main():
    print("[1/9] Features fenológicos del ciclo 2025 (Básico: Sentinel-2 + Landsat) ...")
    basico_ciclo = build_basico_features(cfg.CICLO_INICIO, cfg.CICLO_FIN, tag="ciclo")

    # Nota: para "hist" los datos abarcan 3 ciclos abril-octubre distintos
    # (2022, 2023, 2024) concatenados. mean/std/max/min siguen siendo válidos
    # como nivel histórico de referencia, pero green_up_rate/auc/doy_max de
    # "hist" mezclan los 3 años y son menos interpretables -- úsalos con
    # cautela o descártalos si vas a hacer feature selection.
    print("[2/9] Features históricos 2022-2024 (mismos meses, Básico) para anomalías ...")
    meses_ciclo = (pd.to_datetime(cfg.CICLO_INICIO).month, pd.to_datetime(cfg.CICLO_FIN).month)
    basico_hist = build_basico_features(cfg.HIST_INICIO, cfg.HIST_FIN, tag="hist", month_range=meses_ciclo)

    print("[3/9] Features fenológicos del ciclo 2025 (PRO: Planet, mayor frecuencia) ...")
    pro_ciclo = build_pro_features(cfg.CICLO_INICIO, cfg.CICLO_FIN)

    print("[4/9] Features de clima del ciclo + anomalía histórica ...")
    clima_path = cfg.OUTPUT_DIR / "02_geo" / "clima_mensual_por_parcela.csv"
    if clima_path.exists():
        clima_feats = build_climate_cycle_features(clima_path)
    else:
        print(f"  AVISO: no encontré {clima_path}. Corre primero 02_extract_geo_features.py. Se omite clima.")
        clima_feats = pd.DataFrame(columns=[cfg.ID_COL])

    print("[5/9] Topografía + área + municipio/estado ...")
    topo_path = cfg.OUTPUT_DIR / "02_geo" / "topografia_por_parcela.csv"
    if topo_path.exists():
        topo_feats = pd.read_csv(topo_path)
    else:
        print(f"  AVISO: no encontré {topo_path}. Corre primero 02_extract_geo_features.py. Se omite topografía.")
        topo_feats = pd.DataFrame(columns=[cfg.ID_COL])

    target = pd.read_csv(cfg.ID_RENDIMIENTO_CSV).rename(
        columns={"RENDIMIENTO_T_HA": "rendimiento_t_ha", "AREA_HA": "area_ha"}
    )[[cfg.ID_COL, "area_ha", "rendimiento_t_ha", "CONJUNTO"]]

    gdf = gpd.read_file(cfg.PARCELAS_SHP)
    id_col_shp = [c for c in gdf.columns if c.upper().startswith("ID_POLIGON")][0]
    gdf = gdf.rename(columns={id_col_shp: cfg.ID_COL})
    municip = gdf[[cfg.ID_COL, "Municipio", "Estado"]] if "Municipio" in gdf.columns else pd.DataFrame(columns=[cfg.ID_COL])

    soil_path = cfg.OUTPUT_DIR / "08_soil" / "suelo_por_parcela.csv"
    if soil_path.exists():
        print(f"[6/9] Suelo INEGI (opcional, encontrado en {soil_path}) ...")
        soil_feats = pd.read_csv(soil_path)
    else:
        print(f"[6/9] Suelo INEGI: no encontré {soil_path} -- se omite (opcional, corre 08_soil_features.py si lo quieres incluir).")
        soil_feats = pd.DataFrame(columns=[cfg.ID_COL])

    nasa_path = cfg.OUTPUT_DIR / "10_nasa_power" / "nasa_power_por_parcela.csv"
    if nasa_path.exists():
        print(f"[7/9] NASA POWER (opcional, encontrado en {nasa_path}) ...")
        nasa_feats = pd.read_csv(nasa_path)
    else:
        print(f"[7/9] NASA POWER: no encontré {nasa_path} -- se omite (opcional, corre 10_nasa_power_features.py si lo quieres incluir).")
        nasa_feats = pd.DataFrame(columns=[cfg.ID_COL])

    # El rendimiento histórico municipal de SIAP se fusiona por 'Municipio'
    # (no por ID_POLIGONO, es una covariable a nivel municipio) -- requiere
    # que 'municip' (con la columna Municipio) ya se haya cargado arriba.
    siap_path = cfg.OUTPUT_DIR / "11_siap" / "rendimiento_historico_municipio.csv"
    if siap_path.exists() and "Municipio" in municip.columns:
        print(f"[8/9] SIAP rendimiento histórico municipal (opcional, encontrado en {siap_path}) ...")
        siap_hist = pd.read_csv(siap_path)
        siap_feats = municip[[cfg.ID_COL, "Municipio"]].merge(siap_hist, on="Municipio", how="left").drop(columns=["Municipio"])
    else:
        if siap_path.exists():
            print(f"[8/9] SIAP: encontré {siap_path} pero no hay columna 'Municipio' disponible -- se omite.")
        else:
            print(f"[8/9] SIAP: no encontré {siap_path} -- se omite (opcional, corre 11_siap_historical_yield.py si lo quieres incluir).")
        siap_feats = pd.DataFrame(columns=[cfg.ID_COL])

    print("[9/9] Uniendo todo ...")
    df = target
    for part in (basico_ciclo, basico_hist, pro_ciclo, clima_feats, topo_feats, municip, soil_feats, nasa_feats, siap_feats):
        if part is not None and len(part) > 0:
            df = df.merge(part, on=cfg.ID_COL, how="left")

    # GRUPO1_agrupado: 04 y 06 esperan esta columna, pero si 08 se corrió con
    # una versión que no la guardaba, el modelo la descartaba EN SILENCIO y
    # nunca usaba el grupo de suelo. Si falta, se deriva aquí de GRUPO1 con la
    # misma regla que 08 (categorías con < 10 parcelas -> "OTRO"). Solo usa
    # conteos de la columna, nunca el rendimiento, así que no hay fuga.
    if "GRUPO1" in df.columns and "GRUPO1_agrupado" not in df.columns:
        conteos = df["GRUPO1"].value_counts()
        raras = conteos[conteos < 10].index.tolist()
        df["GRUPO1_agrupado"] = df["GRUPO1"].where(~df["GRUPO1"].isin(raras), "OTRO")
        print(f"[suelo] GRUPO1_agrupado derivada de GRUPO1 (agrupadas en 'OTRO': {raras})")

    # anomalías NDVI ciclo vs histórico (mismo periodo del año, años previos)
    if "ciclo_ndvi_mean" in df.columns and "hist_ndvi_mean" in df.columns:
        df["ndvi_anomalia"] = df["ciclo_ndvi_mean"] - df["hist_ndvi_mean"]

    out_path = FEAT_DIR / "features_dataset.csv"
    df.to_csv(out_path, index=False)
    print(f"\nTabla final: {df.shape[0]} parcelas x {df.shape[1]} columnas -> {out_path}")
    print(f"  ENTRENAMIENTO: {(df['CONJUNTO'] == 'ENTRENAMIENTO').sum()}  |  PREDICCION: {(df['CONJUNTO'] == 'PREDICCION').sum()}")

    na_cols = df.isna().mean().sort_values(ascending=False)
    print("\nColumnas con más NaN (revisar antes de modelar):")
    print(na_cols[na_cols > 0].head(15).to_string())


if __name__ == "__main__":
    main()
