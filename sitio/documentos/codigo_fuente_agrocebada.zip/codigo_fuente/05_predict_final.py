"""
Paso 5 — Predicción final sobre el 30% oculto (parcelas CONJUNTO == PREDICCION).

Genera exactamente la tabla que piden como entregable obligatorio en los
Anexos del reporte técnico: ID_parcela + rendimiento predicho en ton/ha.

Salida: outputs/05_prediccion/prediccion_final_ton_ha.csv
"""

import sys
from pathlib import Path
from importlib import import_module

sys.path.insert(0, str(Path(__file__).resolve().parent))
cfg = import_module("00_config")

import json
import pandas as pd
import joblib

PRED_DIR = cfg.OUTPUT_DIR / "05_prediccion"
PRED_DIR.mkdir(parents=True, exist_ok=True)

TARGET = "rendimiento_t_ha"


def main():
    df = pd.read_csv(cfg.OUTPUT_DIR / "03_features" / "features_dataset.csv")
    to_predict = df[df["CONJUNTO"] == "PREDICCION"].copy()
    print(f"[predict] {len(to_predict)} parcelas a estimar")

    model_dir = cfg.OUTPUT_DIR / "04_modelo"
    pipeline = joblib.load(model_dir / "modelo_final.joblib")
    with open(model_dir / "features_seleccionadas.json") as f:
        feat_info = json.load(f)

    feature_cols = feat_info["numeric"] + feat_info["categorical"]
    faltantes = [c for c in feature_cols if c not in to_predict.columns]
    if faltantes:
        raise ValueError(f"Faltan columnas que el modelo necesita: {faltantes}")

    X = to_predict[feature_cols]
    preds = pipeline.predict(X)

    out = pd.DataFrame({
        "ID_parcela": to_predict[cfg.ID_COL].values,
        "rendimiento_predicho_ton_ha": preds.round(3),
    }).sort_values("ID_parcela")

    out_path = PRED_DIR / "prediccion_final_ton_ha.csv"
    out.to_csv(out_path, index=False)

    print(f"\n[predict] guardado en {out_path}")
    print(out.describe().to_string())
    print(
        "\nEsta es la tabla que va OBLIGATORIAMENTE en el apartado de Anexos "
        "del reporte técnico (ID_parcela + rendimiento en ton/ha)."
    )


if __name__ == "__main__":
    main()
