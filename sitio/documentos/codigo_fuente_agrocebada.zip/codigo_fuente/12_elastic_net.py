"""
Paso 12 (opcional) — Elastic Net interpretable + prueba de si aporta al ensemble.

POR QUÉ EXISTE: un compañero de equipo entrenó un Elastic Net con buenas
métricas. Antes de meterlo al ensemble hay que medir DOS cosas con el mismo
rigor que el resto del pipeline:
  (a) qué tan bien generaliza solo (KFold repetido Y LeaveOneGroupOut por
      Municipio), y
  (b) si de verdad le AGREGA algo al ensemble ExtraTrees + LSTM+GP, usando
      las mismas particiones que 07_ensemble.py. Un modelo con buen RMSE
      propio no mejora necesariamente al ensemble: si falla en las mismas
      parcelas que los demás (errores muy correlacionados), promediarlo no
      baja el error.

IMPLEMENTACIÓN ELEGIDA (resultado de probar 9 variantes con tus 138 parcelas):
  imputación por mediana -> StandardScaler -> SelectKBest(f_regression, k=60)
  -> ElasticNetCV (l1_ratio en 7 valores, alpha por CV interno).
  Resultados medidos (RMSE): KFold 0.535, LOGO 0.838, vs ExtraTrees 0.506 /
  0.594. Lo que NO ayudó, medido:
    - Regla de 1 desviación estándar para alpha: peor (0.564-0.575).
    - Municipio/Estado como one-hot: mejora el KFold (0.527) pero LOGO se
      dispara a 1.25 -> memoriza ubicación, mismo problema que con los
      árboles (ver diagnostico_ubicacion.csv de 04).
    - Suelo (GRUPO1/TEXTURA): sin efecto (el L1 los deja en cero).
  Por eso la ubicación queda desactivada (USAR_UBICACION = False).
  La preselección con SelectKBest va DENTRO del pipeline: se recalcula en
  cada fold con solo los datos de entrenamiento, sin fuga de información.

APORTE AL ENSEMBLE (medido con los mismos folds que 07): el peso óptimo del
Elastic Net fue 0 en todas las variantes; sus errores correlacionan 0.93-0.95
con los del ensemble. Este script repite esa prueba cada vez que lo corres
(con bootstrap) y solo recomienda incluirlo si la mejora es estable.

MODELO DEL COMPAÑERO: sus features (etapas fenológicas, precip/temperatura
mensual, lat/lon, forma de la parcela, Municipio/Estado) no son las nuestras,
así que no se puede reentrenar aquí. Para medir su aporte real, pídele sus
predicciones FUERA DE MUESTRA sobre las 138 parcelas de entrenamiento y pon
la ruta en EXTERNAL_OOF_CSV. Debe usar los mismos folds que 07:
    KFold(n_splits=5, shuffle=True, random_state=42) sobre los IDs de
    ENTRENAMIENTO ordenados alfabéticamente.
El CSV lleva dos columnas: ID_POLIGONO y la predicción en ton/ha. Predecir
las 138 filas con el modelo ya entrenado NO sirve (están en la muestra).

Salidas en outputs/12_elastic_net/:
  - cv_resultados.csv                  (KFold repetido, LOGO, OOF con folds de 07)
  - oof_elastic_net.csv                (predicción fuera de muestra por parcela)
  - prediccion_elastic_net_ton_ha.csv  (59 parcelas ocultas)
  - coeficientes.csv                   (variables seleccionadas, para las preguntas guía)
  - modelo_elastic_net.joblib
  - aporte_al_ensemble.csv             (si existe outputs/07_ensemble/oof_predicciones.csv)
  - prediccion_ensemble_con_en_ton_ha.csv (solo si la mejora es estable)
"""

import sys
import warnings
from pathlib import Path
from importlib import import_module

sys.path.insert(0, str(Path(__file__).resolve().parent))
cfg = import_module("00_config")

import numpy as np
import pandas as pd
import joblib
import sklearn
from joblib import Parallel, delayed
from sklearn.base import clone
from sklearn.compose import ColumnTransformer
from sklearn.feature_selection import SelectKBest, f_regression
from sklearn.impute import SimpleImputer
from sklearn.linear_model import ElasticNetCV
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import KFold, LeaveOneGroupOut, RepeatedKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

OUT_DIR = cfg.OUTPUT_DIR / "12_elastic_net"
OUT_DIR.mkdir(parents=True, exist_ok=True)

TARGET = "rendimiento_t_ha"
K_BEST = 60
L1_RATIOS = [0.1, 0.3, 0.5, 0.7, 0.9, 0.97, 1.0]
USAR_UBICACION = False   # ver docstring: con Municipio/Estado el LOGO se dispara a ~1.25
N_REPEATS = 3
EXTERNAL_OOF_CSV = None  # ej. r"C:\ruta\oof_companero.csv" (ver docstring)
EXTERNAL_NAME = "Elastic Net del compañero"


def make_encv():
    """ElasticNetCV compatible con sklearn < 1.7 (n_alphas) y >= 1.7 (alphas=int)."""
    ver = tuple(int(p) for p in sklearn.__version__.split(".")[:2])
    kw = dict(l1_ratio=L1_RATIOS, cv=KFold(5, shuffle=True, random_state=0), max_iter=50000, tol=1e-3)
    if ver >= (1, 7):
        return ElasticNetCV(alphas=60, **kw)
    return ElasticNetCV(n_alphas=60, **kw)


def build_pipeline(num_cols):
    transformers = [("num", Pipeline([
        ("imp", SimpleImputer(strategy="median")),
        ("sc", StandardScaler()),
    ]), num_cols)]
    if USAR_UBICACION:
        try:
            oh = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        except TypeError:
            oh = OneHotEncoder(handle_unknown="ignore", sparse=False)
        # Se escalan los dummies: sin escalar, el L1 los deja en cero.
        transformers.append(("loc", Pipeline([
            ("imp", SimpleImputer(strategy="most_frequent")), ("oh", oh), ("sc", StandardScaler()),
        ]), ["Municipio", "Estado"]))
    return Pipeline([
        ("pre", ColumnTransformer(transformers)),
        ("sel", SelectKBest(f_regression, k=K_BEST)),
        ("m", make_encv()),
    ])


def _fit_predict(pipe, X, y, tr_idx, te_idx):
    warnings.filterwarnings("ignore")
    model = clone(pipe).fit(X.iloc[tr_idx], y[tr_idx])
    return te_idx, model.predict(X.iloc[te_idx])


def _metrics(y, pred):
    return mean_squared_error(y, pred) ** 0.5, mean_absolute_error(y, pred), r2_score(y, pred)


def rmse(y, p):
    return float(np.sqrt(np.mean((y - p) ** 2)))


def evaluar_aporte(y, ml, lstm, extra, nombre, n_boot=2000, seed=0):
    """
    ¿Mejora `extra` al ensemble 50/50 de ExtraTrees (ml) y LSTM+GP (lstm)?
    Compara contra el ensemble de 2 con las mismas filas y hace bootstrap sobre
    parcelas para ver si la diferencia es estable o ruido (n=138 es chico).
    """
    base = (ml + lstm) / 2
    tres = (ml + lstm + extra) / 3
    mejor_w, mejor_r = min(((w, rmse(y, (1 - w) * base + w * extra)) for w in np.arange(0, 0.55, 0.05)),
                           key=lambda t: t[1])
    corr = float(np.corrcoef(y - extra, y - base)[0, 1])
    rng = np.random.default_rng(seed)
    n = len(y)
    d = []
    for _ in range(n_boot):
        i = rng.integers(0, n, n)
        d.append(rmse(y[i], base[i]) - rmse(y[i], tres[i]))
    d = np.array(d)
    p_mejora = float(np.mean(d > 0))
    row = dict(modelo=nombre, rmse_solo=rmse(y, extra), rmse_ensemble_2=rmse(y, base), rmse_ensemble_3=rmse(y, tres),
               mejor_peso=round(float(mejor_w), 2), rmse_mejor_peso=mejor_r, corr_errores_vs_ensemble=corr,
               mejora_media_boot=float(d.mean()), ic95_inf=float(np.percentile(d, 2.5)),
               ic95_sup=float(np.percentile(d, 97.5)), prob_mejora=p_mejora)
    print(f"\n[aporte] {nombre}")
    print(f"  RMSE solo={row['rmse_solo']:.4f} | ensemble 2 modelos={row['rmse_ensemble_2']:.4f} | "
          f"ensemble 3 modelos (iguales)={row['rmse_ensemble_3']:.4f} | mejor peso={mejor_w:.2f} -> {mejor_r:.4f}")
    print(f"  correlación de errores contra el ensemble = {corr:.3f} (cerca de 1 = falla en las mismas parcelas)")
    print(f"  bootstrap: mejora media={d.mean():+.4f}  IC95=[{np.percentile(d, 2.5):+.4f}, {np.percentile(d, 97.5):+.4f}]  "
          f"P(mejora>0)={p_mejora:.2f}")
    row["recomendado"] = bool(p_mejora >= 0.90 and np.percentile(d, 2.5) > -0.002)
    print("  -> " + ("INCLUIR en el ensemble (mejora estable)." if row["recomendado"]
                     else "NO incluir: la mejora no es estable (o no existe) con 138 parcelas."))
    return row


def main():
    df = pd.read_csv(cfg.OUTPUT_DIR / "03_features" / "features_dataset.csv")
    tr = df[df["CONJUNTO"] == "ENTRENAMIENTO"].sort_values(cfg.ID_COL).reset_index(drop=True)  # mismo orden que 07
    hidden = df[df["CONJUNTO"] != "ENTRENAMIENTO"].sort_values(cfg.ID_COL).reset_index(drop=True)

    excl = {cfg.ID_COL, "CONJUNTO", TARGET, "Municipio", "Estado", "GRUPO1", "GRUPO1_agrupado", "TEXTURA"}
    num = [c for c in df.columns if c not in excl and pd.api.types.is_numeric_dtype(df[c])]
    num = [c for c in num if tr[c].isna().mean() <= 0.4 and tr[c].std() > 0]
    extra_cols = ["Municipio", "Estado"] if USAR_UBICACION else []
    cols = num + extra_cols
    X, y = tr[cols], tr[TARGET].to_numpy()
    groups = tr["Municipio"].to_numpy() if "Municipio" in tr.columns else None
    print(f"[en] {len(tr)} parcelas de entrenamiento, {len(num)} variables numéricas, "
          f"ubicación={'SÍ' if USAR_UBICACION else 'no'}, SelectKBest k={K_BEST}")

    pipe = build_pipeline(num)

    # 1) KFold repetido
    splits = list(RepeatedKFold(n_splits=5, n_repeats=N_REPEATS, random_state=cfg.RANDOM_STATE).split(X))
    res = Parallel(n_jobs=-1)(delayed(_fit_predict)(pipe, X, y, a, b) for a, b in splits)
    ms = np.array([_metrics(y[b], p) for b, p in res])
    rmse_k, mae_k, r2_k = ms.mean(axis=0)
    print(f"[en] KFold 5x{N_REPEATS}: RMSE={rmse_k:.3f}  MAE={mae_k:.3f}  R2={r2_k:.3f}")

    # 2) LeaveOneGroupOut por Municipio
    rmse_l = np.nan
    if groups is not None:
        sp = list(LeaveOneGroupOut().split(X, y, groups))
        res = Parallel(n_jobs=-1)(delayed(_fit_predict)(pipe, X, y, a, b) for a, b in sp)
        lp = np.full(len(y), np.nan)
        for b, p in res:
            lp[b] = p
        rmse_l = rmse(y, lp)
        print(f"[en] LeaveOneGroupOut por Municipio: RMSE={rmse_l:.3f}  (ExtraTrees sin ubicación: 0.594)")

    # 3) OOF con los MISMOS folds que 07_ensemble.py
    sp = list(KFold(5, shuffle=True, random_state=cfg.RANDOM_STATE).split(X))
    res = Parallel(n_jobs=-1)(delayed(_fit_predict)(pipe, X, y, a, b) for a, b in sp)
    oof = np.full(len(y), np.nan)
    for b, p in res:
        oof[b] = p
    rmse_o, mae_o, r2_o = _metrics(y, oof)
    print(f"[en] OOF con folds de 07: RMSE={rmse_o:.3f}  MAE={mae_o:.3f}  R2={r2_o:.3f}")

    pd.DataFrame([dict(modelo="ElasticNet", rmse_kfold=rmse_k, mae_kfold=mae_k, r2_kfold=r2_k,
                       rmse_logo=rmse_l, rmse_oof07=rmse_o)]).to_csv(OUT_DIR / "cv_resultados.csv", index=False)
    pd.DataFrame({cfg.ID_COL: tr[cfg.ID_COL], "rendimiento_real": y, "pred_en": oof}).to_csv(
        OUT_DIR / "oof_elastic_net.csv", index=False)

    # 4) Modelo final + predicción de las 59 ocultas + coeficientes
    warnings.filterwarnings("ignore")
    final = clone(pipe).fit(X, y)
    joblib.dump(final, OUT_DIR / "modelo_elastic_net.joblib")
    pred_h = final.predict(hidden[cols])
    pd.DataFrame({"ID_parcela": hidden[cfg.ID_COL], "rendimiento_predicho_ton_ha": pred_h.round(3)}).to_csv(
        OUT_DIR / "prediccion_elastic_net_ton_ha.csv", index=False)

    names = np.array(final.named_steps["pre"].get_feature_names_out()) if hasattr(
        final.named_steps["pre"], "get_feature_names_out") else np.array(cols)
    names = np.array([n.split("__", 1)[-1] for n in names])
    keep = final.named_steps["sel"].get_support()
    enm = final.named_steps["m"]
    coef = pd.DataFrame({"variable": names[keep], "coef_estandarizado": enm.coef_})
    coef = coef[coef["coef_estandarizado"] != 0].sort_values("coef_estandarizado", key=np.abs, ascending=False)
    coef.to_csv(OUT_DIR / "coeficientes.csv", index=False)
    print(f"\n[en] alpha={enm.alpha_:.4f}  l1_ratio={enm.l1_ratio_}  variables con coeficiente != 0: {len(coef)}")
    print("Top 12 variables (coeficiente sobre variables estandarizadas; úsalo para las preguntas guía):")
    print(coef.head(12).to_string(index=False))

    # 5) ¿Aporta al ensemble de 07?
    oof07 = cfg.OUTPUT_DIR / "07_ensemble" / "oof_predicciones.csv"
    if not oof07.exists():
        print(f"\n[aporte] No encontré {oof07}. Corre 04, 05, 06 y 07 y vuelve a correr este script.")
        return
    o = pd.read_csv(oof07)
    if list(o[cfg.ID_COL]) != list(tr[cfg.ID_COL]):
        print("\n[aporte] AVISO: el orden de IDs de 07 no coincide con el de este script; no se puede comparar.")
        return
    yy, ml, ls = o["rendimiento_real"].to_numpy(), o["pred_ml"].to_numpy(), o["pred_lstm_gp"].to_numpy()
    rows = [evaluar_aporte(yy, ml, ls, oof, "Elastic Net (este script)")]

    ext_ok = None
    if EXTERNAL_OOF_CSV:
        e = pd.read_csv(EXTERNAL_OOF_CSV)
        pred_col = [c for c in e.columns if c != cfg.ID_COL][0]
        e = e.set_index(cfg.ID_COL).reindex(tr[cfg.ID_COL])
        if e[pred_col].isna().any():
            print(f"\n[aporte] AVISO: el CSV externo no cubre las {len(tr)} parcelas de entrenamiento; se omite.")
        else:
            ext = e[pred_col].to_numpy(dtype=float)
            rows.append(evaluar_aporte(yy, ml, ls, ext, EXTERNAL_NAME))
            ext_ok = ext
    pd.DataFrame(rows).to_csv(OUT_DIR / "aporte_al_ensemble.csv", index=False)

    # 6) Si algún modelo extra ayuda de forma estable, deja la predicción final de 3
    p_ens = cfg.OUTPUT_DIR / "07_ensemble" / "prediccion_ensemble_final_ton_ha.csv"
    p_ml = cfg.OUTPUT_DIR / "05_prediccion" / "prediccion_final_ton_ha.csv"
    p_ls = cfg.OUTPUT_DIR / "06_paper_lstm_gp" / "prediccion_paper_ton_ha.csv"
    if rows[0]["recomendado"] and all(p.exists() for p in (p_ml, p_ls)):
        a = pd.read_csv(p_ml).set_index("ID_parcela")["rendimiento_predicho_ton_ha"]
        b = pd.read_csv(p_ls).set_index("ID_parcela")["rendimiento_predicho_ton_ha"]
        c = pd.Series(pred_h, index=hidden[cfg.ID_COL].values)
        out = ((a + b.reindex(a.index) + c.reindex(a.index)) / 3).round(3).rename("rendimiento_predicho_ton_ha")
        out.reset_index().sort_values("ID_parcela").to_csv(OUT_DIR / "prediccion_ensemble_con_en_ton_ha.csv", index=False)
        print(f"\n[aporte] guardado {OUT_DIR / 'prediccion_ensemble_con_en_ton_ha.csv'}")
    else:
        print("\n[aporte] Se mantiene el ensemble de 07 (ExtraTrees + LSTM+GP) como predicción final.")


if __name__ == "__main__":
    main()
