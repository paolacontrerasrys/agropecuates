"""
Paso 4 — Entrenamiento y validación de modelos.

Contexto importante: solo tenemos 138 parcelas etiquetadas y el paso 3
genera ~370 columnas de features (muchos índices espectrales x muchos
estadísticos). Esto es un escenario clásico de "p >> n" (más variables
que observaciones) -> el riesgo real es overfitting, no falta de poder
predictivo. Por eso este script:

  1. Elimina columnas con varianza casi nula o con demasiados NaN.
  2. Reduce colinealidad extrema (muchos índices espectrales miden
     esencialmente lo mismo que NDVI/EVI) quitando features muy
     correlacionadas entre sí (|r| > 0.97), quedándonos con una por grupo.
  3. Compara modelos simples/regularizados (Ridge, Lasso) contra modelos
     de árboles (RandomForest, GradientBoosting, y XGBoost/LightGBM si
     están instalados), todos con validación cruzada repetida (no un solo
     train/test split, dado lo pequeño de la muestra).
  4. Se queda con el mejor modelo por RMSE promedio de CV, lo reentrena
     con TODOS los datos de ENTRENAMIENTO, y calcula feature importance /
     permutation importance para responder las 3 preguntas guía de la
     convocatoria.

Salidas en outputs/04_modelo/:
  - cv_resultados.csv           (comparación de modelos)
  - feature_importance.csv      (para responder las preguntas guía)
  - modelo_final.joblib         (pipeline entrenado, listo para el paso 5)
  - features_seleccionadas.json (lista de columnas usadas, para reproducibilidad)
"""

import sys
import json
from pathlib import Path
from importlib import import_module

sys.path.insert(0, str(Path(__file__).resolve().parent))
cfg = import_module("00_config")

import numpy as np
import pandas as pd
import joblib
from sklearn.linear_model import Ridge, Lasso
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, ExtraTreesRegressor, StackingRegressor
from sklearn.model_selection import RepeatedKFold, GroupKFold, LeaveOneGroupOut
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.inspection import permutation_importance
from sklearn.base import BaseEstimator, TransformerMixin, clone

MODEL_DIR = cfg.OUTPUT_DIR / "04_modelo"
MODEL_DIR.mkdir(parents=True, exist_ok=True)

TARGET = "rendimiento_t_ha"
ID_LIKE_COLS = [cfg.ID_COL, "CONJUNTO"]

# Municipio/Estado se probaron y se quitaron a propósito -- evidencia real
# (corrida del usuario, outputs/04_modelo/diagnostico_ubicacion.csv):
#   - CON Municipio/Estado: KFold normal RMSE=0.508, pero GroupKFold por
#     Municipio (holdout de un municipio completo) RMSE=1.230 (R2=-5.33) --
#     el modelo esencialmente memorizaba el promedio de cada municipio.
#   - SIN Municipio/Estado: RMSE=0.500 -- MEJOR, no peor. No hay trade-off:
#     quitar la ubicación mejora el RMSE de CV estándar Y elimina el riesgo
#     de que el modelo dependa de memorizar ubicación en vez de aprender de
#     percepción remota/clima/suelo (que es literalmente el tema del reto y
#     lo que evalúa el jurado). Con solo 9 municipios y 138 filas, el
#     one-hot de Municipio le mete puro ruido/overfitting al modelo.
# Si quieres volver a probar CON ubicación para comparar, descomenta la
# línea de abajo y vuelve a correr -- pero la evidencia dice que no conviene.
CATEGORICAL_COLS = ["GRUPO1_agrupado", "TEXTURA"]
# CATEGORICAL_COLS = ["Municipio", "Estado", "GRUPO1_agrupado", "TEXTURA"]  # versión descartada, ver nota arriba


class ShrunkenTargetEncoder(BaseEstimator, TransformerMixin):
    """
    Codificación de Municipio por "encogimiento" (shrinkage) hacia la media
    global -- una aproximación frecuentista ligera de un modelo jerárquico /
    de efectos mixtos (Municipio como efecto aleatorio). En vez de un
    one-hot (que le da a cada municipio su propio parámetro libre y es lo
    que causaba la memorización de ubicación diagnosticada en
    diagnostico_ubicacion.csv), cada municipio se codifica con su media de
    rendimiento observada, pero "encogida" hacia la media global en
    proporción a cuántas parcelas tiene ese municipio en el fold de
    entrenamiento:

        valor(municipio) = (n_m * media_m + k * media_global) / (n_m + k)

    Con pocas parcelas en un municipio (n_m chico frente a k), el valor se
    acerca a la media global -- el modelo no puede "memorizar" un promedio
    poco confiable calculado con 2-3 filas. Con muchas parcelas (n_m >> k),
    el valor se acerca a la media real de ese municipio. k=10 (default) es
    un encogimiento moderado dado que hay ~9 municipios y ~138 filas
    (in promedio ~15 parcelas/municipio).

    Crucial: fit() se llama SOLO con datos de entrenamiento de cada fold de
    CV (así lo maneja sklearn.Pipeline dentro de cross-validation), así que
    no hay fuga de información del fold de prueba hacia el encoding --a
    diferencia de calcular esto una sola vez sobre todo el dataset.
    """

    def __init__(self, k=10):
        self.k = k

    def fit(self, X, y):
        s = pd.Series(np.asarray(X).ravel())
        y = pd.Series(np.asarray(y).ravel())
        self.global_mean_ = float(y.mean())
        grp = y.groupby(s.values)
        means = grp.mean()
        counts = grp.count()
        shrunk = (counts * means + self.k * self.global_mean_) / (counts + self.k)
        self.mapping_ = shrunk.to_dict()
        return self

    def transform(self, X):
        s = pd.Series(np.asarray(X).ravel())
        return s.map(self.mapping_).fillna(self.global_mean_).to_numpy().reshape(-1, 1)


def load_dataset():
    path = cfg.OUTPUT_DIR / "03_features" / "features_dataset.csv"
    df = pd.read_csv(path)
    return df


def select_features(df_train: pd.DataFrame, numeric_cols: list, corr_threshold=0.97):
    # 1) quitar columnas con >40% NaN o varianza ~0
    keep = []
    for c in numeric_cols:
        s = df_train[c]
        if s.isna().mean() > 0.4:
            continue
        if s.std(skipna=True) in (0, np.nan) or pd.isna(s.std(skipna=True)):
            continue
        keep.append(c)

    # 2) quitar redundancia extrema (colinealidad) de forma greedy
    corr = df_train[keep].corr().abs()
    dropped = set()
    cols_sorted = list(corr.columns)
    for i, c1 in enumerate(cols_sorted):
        if c1 in dropped:
            continue
        for c2 in cols_sorted[i + 1:]:
            if c2 in dropped:
                continue
            if corr.loc[c1, c2] > corr_threshold:
                dropped.add(c2)
    final = [c for c in keep if c not in dropped]
    print(f"[features] {len(numeric_cols)} numéricas -> {len(keep)} tras filtrar NaN/varianza -> {len(final)} tras quitar colinealidad")
    return final


def _make_onehot():
    """
    Fuerza salida DENSA (no sparse) del OneHotEncoder. Cuando el
    ColumnTransformer combina columnas numéricas densas con un encoder que
    devuelve sparse, el resultado es una matriz sparse mixta que LightGBM
    en Windows a veces no maneja bien -- puede tronar con
    "OSError: exception: access violation reading 0x0..." en vez de un
    error normal de Python (bug reportado varias veces en Windows). Forzar
    denso evita ese camino por completo; con ~300 columnas y 138 filas el
    costo de memoria de ir denso es trivial.
    """
    try:
        return OneHotEncoder(handle_unknown="ignore", sparse_output=False)
    except TypeError:
        # sklearn < 1.2 usa el nombre de parámetro "sparse" en vez de "sparse_output"
        return OneHotEncoder(handle_unknown="ignore", sparse=False)


def build_pipeline(model, numeric_cols, categorical_cols, municipio_col=None, municipio_shrinkage_k=10):
    """
    municipio_col: si se pasa (ej. "Municipio"), agrega una rama separada
    del ColumnTransformer que codifica esa columna con ShrunkenTargetEncoder
    en vez de one-hot -- ver la clase de arriba para la justificación. Se
    mantiene aparte de `categorical_cols` (que sigue usando one-hot normal
    para suelo/textura, donde no hay riesgo de memorización de ubicación).
    """
    transformers = [
        ("num", Pipeline([
            ("impute", SimpleImputer(strategy="median")),
            ("scale", StandardScaler()),
        ]), numeric_cols),
        ("cat", Pipeline([
            ("impute", SimpleImputer(strategy="most_frequent")),
            ("onehot", _make_onehot()),
        ]), categorical_cols),
    ]
    if municipio_col is not None:
        transformers.append((
            "municipio_te",
            Pipeline([
                ("impute", SimpleImputer(strategy="most_frequent")),
                ("encode", ShrunkenTargetEncoder(k=municipio_shrinkage_k)),
                ("scale", StandardScaler()),
            ]),
            [municipio_col],
        ))
    pre = ColumnTransformer(transformers=transformers)
    return Pipeline([("pre", pre), ("model", model)])


def evaluate_cv(pipeline, X, y, n_splits=5, n_repeats=10, model_name=""):
    """
    RepeatedKFold visita cada fila varias veces (una por repetición), así que
    no es una partición única y sklearn.cross_val_predict no aplica aquí
    directamente. En su lugar, calculamos RMSE/MAE/R2 fold por fold (para
    cada una de las n_repeats repeticiones de 5-fold) y promediamos -- esto
    da una estimación mucho más estable del error real que un solo split,
    que es justo lo que necesitamos con apenas 138 observaciones.

    Cada fold se entrena dentro de un try/except: si un modelo específico
    falla en un fold (visto en Windows con LightGBM: "OSError: access
    violation" en vez de un error normal), se descarta SOLO ese fold en vez
    de tumbar la corrida completa de todos los modelos. Si un modelo falla
    en TODOS los folds, se devuelve (None, None, None, None) y el modelo se
    omite del comparativo (ver main()).
    """
    from sklearn.base import clone

    cv = RepeatedKFold(n_splits=n_splits, n_repeats=n_repeats, random_state=cfg.RANDOM_STATE)
    rmses, maes, r2s = [], [], []
    fallos = 0
    X_arr = X.reset_index(drop=True)
    y_arr = y.reset_index(drop=True)
    for train_idx, test_idx in cv.split(X_arr):
        model = clone(pipeline)
        try:
            model.fit(X_arr.iloc[train_idx], y_arr.iloc[train_idx])
            pred = model.predict(X_arr.iloc[test_idx])
        except Exception as e:
            fallos += 1
            if fallos <= 3:
                print(f"[cv] AVISO: {model_name} falló en un fold ({type(e).__name__}: {e}) -- se omite ese fold.")
            continue
        rmses.append(mean_squared_error(y_arr.iloc[test_idx], pred) ** 0.5)
        maes.append(mean_absolute_error(y_arr.iloc[test_idx], pred))
        r2s.append(r2_score(y_arr.iloc[test_idx], pred))

    if fallos:
        total = n_splits * n_repeats
        print(f"[cv] {model_name}: {fallos}/{total} folds fallaron.")
    if not rmses:
        print(f"[cv] {model_name}: falló en TODOS los folds -- se omite del comparativo.")
        return None, None, None, None
    return float(np.mean(rmses)), float(np.mean(maes)), float(np.mean(r2s)), None


LAST_LOGO_POOLED_RMSE = None


def evaluate_groupkfold(pipeline, X, y, groups, model_name=""):
    """
    Igual que evaluate_cv, pero con LeaveOneGroupOut (LOGO): en cada fold se
    deja FUERA un único municipio completo (no una mezcla de varios, como
    hacía el GroupKFold(n_splits=5) anterior, que a veces agrupaba 4
    municipios chicos en un solo fold y diluía el diagnóstico). Con ~9
    municipios esto da ~9 folds, uno por municipio -- mide, municipio por
    municipio, qué tan bien predice el modelo en una ubicación que NUNCA vio
    durante el entrenamiento de ese fold. Es una prueba más granular e
    interpretable (el print por fold dice exactamente qué municipio quedó
    fuera) de lo que puede pasar con el 30% oculto si incluye zonas poco
    representadas en el 70% de entrenamiento.
    """
    logo = LeaveOneGroupOut()
    global LAST_LOGO_POOLED_RMSE
    rmses, maes, r2s = [], [], []
    all_true, all_pred = [], []
    X_arr = X.reset_index(drop=True)
    y_arr = y.reset_index(drop=True)
    groups_arr = pd.Series(groups).reset_index(drop=True)
    for fold, (train_idx, test_idx) in enumerate(logo.split(X_arr, y_arr, groups=groups_arr)):
        municipios_test = sorted(set(groups_arr.iloc[test_idx]))
        yte_diag = y_arr.iloc[test_idx]
        print(f"    [fold-grupo {fold + 1}] municipio(s) fuera: {municipios_test} "
              f"({len(test_idx)} parcelas, rendimiento real min={yte_diag.min():.2f} "
              f"max={yte_diag.max():.2f} mean={yte_diag.mean():.2f})")
        model = clone(pipeline)
        try:
            model.fit(X_arr.iloc[train_idx], y_arr.iloc[train_idx])
            pred = model.predict(X_arr.iloc[test_idx])
        except Exception as e:
            print(f"[cv-grupo] AVISO: {model_name} falló en un fold agrupado ({type(e).__name__}: {e}) -- se omite ese fold.")
            continue
        rmses.append(mean_squared_error(y_arr.iloc[test_idx], pred) ** 0.5)
        maes.append(mean_absolute_error(y_arr.iloc[test_idx], pred))
        r2s.append(r2_score(y_arr.iloc[test_idx], pred))
        all_true.extend(y_arr.iloc[test_idx].tolist()); all_pred.extend(list(pred))
    if not rmses:
        return None, None, None
    # NOTA: el valor devuelto es el PROMEDIO de los RMSE por municipio (cada municipio pesa igual,
    # aunque tenga 1 parcela). El RMSE AGRUPADO (todas las predicciones juntas) es más estricto y es
    # el comparable con el RMSE de K-fold; se guarda en LAST_LOGO_POOLED_RMSE y en diagnostico_ubicacion.csv.
    LAST_LOGO_POOLED_RMSE = float(np.sqrt(np.mean((np.array(all_true) - np.array(all_pred)) ** 2)))
    print(f"    [LOGO] RMSE agrupado (todas las predicciones) = {LAST_LOGO_POOLED_RMSE:.3f}  |  promedio de RMSE por municipio = {float(np.mean(rmses)):.3f}")
    return float(np.mean(rmses)), float(np.mean(maes)), float(np.mean(r2s))


def get_candidates():
    """
    Modelos candidatos + hiperparámetros, en una función aparte para que
    otros scripts (07_ensemble.py) puedan reconstruir EXACTAMENTE los mismos
    modelos sin duplicar hiperparámetros a mano.
    """
    candidates = {
        "Ridge": Ridge(alpha=5.0, random_state=cfg.RANDOM_STATE),
        "Lasso": Lasso(alpha=0.05, random_state=cfg.RANDOM_STATE, max_iter=10000),
        "RandomForest": RandomForestRegressor(n_estimators=400, max_depth=6, min_samples_leaf=3, random_state=cfg.RANDOM_STATE),
        "GradientBoosting": GradientBoostingRegressor(n_estimators=300, max_depth=3, learning_rate=0.03, random_state=cfg.RANDOM_STATE),
        # ExtraTrees (árboles extremadamente aleatorizados): con datasets
        # chicos y ruidosos como este (138 filas), la aleatoriedad extra en
        # el punto de corte suele reducir varianza/overfitting frente a
        # RandomForest normal -- no requiere instalar nada nuevo.
        "ExtraTrees": ExtraTreesRegressor(n_estimators=500, max_depth=8, min_samples_leaf=2, random_state=cfg.RANDOM_STATE),
    }
    try:
        from xgboost import XGBRegressor
        candidates["XGBoost"] = XGBRegressor(
            n_estimators=400, max_depth=3, learning_rate=0.03,
            subsample=0.8, colsample_bytree=0.8, reg_lambda=2.0,
            random_state=cfg.RANDOM_STATE, verbosity=0,
        )
    except ImportError:
        print("[aviso] xgboost no está instalado, se omite (pip install xgboost)")
    try:
        from lightgbm import LGBMRegressor
        candidates["LightGBM"] = LGBMRegressor(
            n_estimators=400, max_depth=4, learning_rate=0.03,
            subsample=0.8, colsample_bytree=0.8, random_state=cfg.RANDOM_STATE, verbosity=-1,
        )
    except ImportError:
        print("[aviso] lightgbm no está instalado, se omite (pip install lightgbm)")
    try:
        from catboost import CatBoostRegressor
        # CatBoost suele rendir muy bien en datasets tabulares chicos (su
        # boosting "ordenado" es más resistente a overfitting con pocas
        # filas que XGBoost/LightGBM clásicos) y es más estable en Windows
        # que LightGBM. Vale la pena instalarlo: pip install catboost
        candidates["CatBoost"] = CatBoostRegressor(
            iterations=500, depth=4, learning_rate=0.03, l2_leaf_reg=3.0,
            random_state=cfg.RANDOM_STATE, verbose=False, allow_writing_files=False,
        )
    except ImportError:
        print("[aviso] catboost no está instalado, se omite (pip install catboost) -- "
              "recomendado, suele ser de los mejores en datasets chicos como este")

    # Stacking: combina los modelos lineales (Ridge/Lasso, capturan la
    # relación global/promedio) con los de árboles (capturan no-linealidad
    # e interacciones) mediante un meta-modelo Ridge entrenado sobre las
    # predicciones out-of-fold de cada base learner (StackingRegressor hace
    # esto internamente con su propio cv=5, sin fuga de datos). Con datasets
    # chicos y modelos base razonablemente distintos entre sí, el stacking
    # normalmente iguala o supera al mejor modelo individual porque no tiene
    # que "elegir" un solo sesgo -- es el candidato a "mejor de los mejores".
    candidates["Stacking"] = StackingRegressor(
        estimators=[
            ("ridge", Ridge(alpha=5.0, random_state=cfg.RANDOM_STATE)),
            ("lasso", Lasso(alpha=0.05, random_state=cfg.RANDOM_STATE, max_iter=10000)),
            ("rf", RandomForestRegressor(n_estimators=400, max_depth=6, min_samples_leaf=3, random_state=cfg.RANDOM_STATE)),
            ("gb", GradientBoostingRegressor(n_estimators=300, max_depth=3, learning_rate=0.03, random_state=cfg.RANDOM_STATE)),
            ("et", ExtraTreesRegressor(n_estimators=500, max_depth=8, min_samples_leaf=2, random_state=cfg.RANDOM_STATE)),
        ],
        final_estimator=Ridge(alpha=1.0, random_state=cfg.RANDOM_STATE),
        cv=5,
    )
    return candidates


def main():
    df = load_dataset()
    train = df[df["CONJUNTO"] == "ENTRENAMIENTO"].copy()
    print(f"[data] {len(train)} parcelas de entrenamiento, {df.shape[1]} columnas totales")

    exclude = set(ID_LIKE_COLS + [TARGET] + CATEGORICAL_COLS)
    numeric_cols_all = [c for c in df.columns if c not in exclude and pd.api.types.is_numeric_dtype(df[c])]
    numeric_cols = select_features(train, numeric_cols_all)
    categorical_cols = [c for c in CATEGORICAL_COLS if c in df.columns]
    faltan = [c for c in CATEGORICAL_COLS if c not in df.columns]
    if faltan:
        print(f"[data] AVISO: estas categóricas no están en features_dataset.csv y NO se usan: {faltan}. "
              f"Corre 08_soil_features.py y luego 03_build_feature_table.py.")
    print(f"[data] categóricas usadas: {categorical_cols}")

    X = train[numeric_cols + categorical_cols]
    y = train[TARGET]

    candidates = get_candidates()

    print(f"\n[cv] evaluando {len(candidates)} modelos con 5-fold x 10 repeticiones "
          f"({len(X)} filas, {len(numeric_cols)} features) -- puede tardar varios minutos "
          f"(Stacking tarda más porque entrena 5 modelos por fold), baja n_repeats en "
          f"evaluate_cv() si necesitas iterar más rápido.")
    results = []
    best_name, best_rmse, best_pipeline = None, np.inf, None
    for name, model in candidates.items():
        pipe = build_pipeline(model, numeric_cols, categorical_cols)
        rmse, mae, r2, _ = evaluate_cv(pipe, X, y, model_name=name)
        if rmse is None:
            continue
        results.append({"modelo": name, "rmse_cv": rmse, "mae_cv": mae, "r2_cv": r2})
        print(f"[cv] {name:16s} RMSE={rmse:.3f}  MAE={mae:.3f}  R2={r2:.3f}")
        if rmse < best_rmse:
            best_name, best_rmse, best_pipeline = name, rmse, pipe

    results_df = pd.DataFrame(results).sort_values("rmse_cv")
    results_df.to_csv(MODEL_DIR / "cv_resultados.csv", index=False)
    print(f"\n[ganador] {best_name} con RMSE_cv={best_rmse:.3f}")
    print("Guarda este archivo para tu reporte técnico (sección Resultados y discusión):")
    print(f"  {MODEL_DIR / 'cv_resultados.csv'}")

    # --- Diagnóstico: ¿el modelo depende de memorizar Municipio/Estado? -----
    # Si Municipio/Estado dominan la importancia de variables (revisa
    # feature_importance.csv más abajo), es una señal de alerta: con un
    # KFold normal, parcelas del MISMO municipio pueden caer a la vez en
    # train y test de un mismo fold, así que el modelo puede estar
    # aprendiendo el promedio de rendimiento por municipio en vez de señal
    # transferible de percepción remota/clima/suelo. Eso infla el RMSE de CV
    # de forma optimista y es difícil de defender como "modelo basado en
    # percepción remota" ante el jurado. Corremos dos chequeos:
    diag_rows = []

    # Chequeo 1: LeaveOneGroupOut por Municipio (cada fold deja fuera un
    # único municipio completo) -- mide generalización real a ubicaciones no
    # vistas, más parecido a lo que puede pasar con el 30% oculto si incluye
    # zonas poco representadas en el 70% de entrenamiento.
    if "Municipio" in train.columns:
        n_grupos = train["Municipio"].nunique()
        if n_grupos >= 2:
            print(f"\n[cv-grupo] validación LeaveOneGroupOut por Municipio ({n_grupos} municipios, "
                  f"{n_grupos} folds) para el modelo ganador ({best_name}) ...")
            rmse_g, mae_g, r2_g = evaluate_groupkfold(
                build_pipeline(candidates[best_name], numeric_cols, categorical_cols),
                X, y, groups=train["Municipio"], model_name=best_name,
            )
            if rmse_g is not None:
                print(f"[cv-grupo] {best_name} (LOGO por Municipio): RMSE={rmse_g:.3f}  MAE={mae_g:.3f}  R2={r2_g:.3f}")
                print(f"[cv-grupo] comparación: KFold normal RMSE={best_rmse:.3f} vs LOGO RMSE={rmse_g:.3f} "
                      f"-- si LOGO es notablemente peor, confirma que el modelo depende de memorizar "
                      f"ubicaciones ya vistas, no de señal transferible.")
                diag_rows.append({"chequeo": "kfold_normal", "rmse": best_rmse})
                diag_rows.append({"chequeo": "logo_municipio", "rmse": rmse_g})
                diag_rows.append({"chequeo": "logo_municipio_agrupado", "rmse": LAST_LOGO_POOLED_RMSE})

            # Chequeo 1b: el mismo modelo ganador, pero con Municipio metido
            # como covariable de encogimiento (ShrunkenTargetEncoder) en vez
            # de completamente ausente -- prueba si una aproximación
            # jerárquica/de efectos mixtos (Municipio "suavizado" hacia la
            # media global) aporta señal real sin caer en la memorización
            # que sí ocurría con el one-hot completo. Se evalúa con AMBOS
            # esquemas de CV para que la comparación sea justa.
            print(f"\n[cv-jerarquico] evaluando {best_name} + Municipio con ShrunkenTargetEncoder "
                  f"(encogimiento jerárquico, k=10) ...")
            pipe_muni_te = build_pipeline(
                candidates[best_name], numeric_cols, categorical_cols,
                municipio_col="Municipio", municipio_shrinkage_k=10,
            )
            X_muni = train[numeric_cols + categorical_cols + ["Municipio"]]
            rmse_te, mae_te, r2_te, _ = evaluate_cv(pipe_muni_te, X_muni, y, model_name=f"{best_name}_municipio_TE")
            if rmse_te is not None:
                print(f"[cv-jerarquico] {best_name}+Municipio_TE (KFold normal): RMSE={rmse_te:.3f}  MAE={mae_te:.3f}  R2={r2_te:.3f}")
                diag_rows.append({"chequeo": "kfold_municipio_shrinkage", "rmse": rmse_te})
                rmse_te_g, mae_te_g, r2_te_g = evaluate_groupkfold(
                    pipe_muni_te, X_muni, y, groups=train["Municipio"], model_name=f"{best_name}_municipio_TE",
                )
                if rmse_te_g is not None:
                    print(f"[cv-jerarquico] {best_name}+Municipio_TE (LOGO por Municipio): RMSE={rmse_te_g:.3f}  MAE={mae_te_g:.3f}  R2={r2_te_g:.3f}")
                    print(f"[cv-jerarquico] resumen comparativo (RMSE): sin_ubicacion_kfold={best_rmse:.3f} | "
                          f"sin_ubicacion_logo={rmse_g:.3f} | municipio_TE_kfold={rmse_te:.3f} | "
                          f"municipio_TE_logo={rmse_te_g:.3f} -- si municipio_TE_logo es parecido o mejor que "
                          f"sin_ubicacion_logo (y no mucho peor que municipio_TE_kfold), el encogimiento jerárquico "
                          f"sí generaliza y vale la pena incluirlo en el reporte técnico como variante adicional.")
                    diag_rows.append({"chequeo": "logo_municipio_shrinkage", "rmse": rmse_te_g})
        else:
            print(f"\n[cv-grupo] AVISO: solo hay {n_grupos} municipios distintos, insuficiente para LeaveOneGroupOut -- se omite.")
    else:
        print("\n[cv-grupo] AVISO: no hay columna Municipio en el dataset -- se omite este chequeo.")

    # Chequeo 2: mismo modelo ganador, pero SIN Municipio/Estado (solo señal
    # de percepción remota + clima + suelo) -- cuantifica cuánto del
    # desempeño depende realmente de las variables del reto vs. de
    # memorizar ubicación. También responde de forma más honesta la
    # pregunta guía "qué combinación de variables funciona mejor".
    categorical_sin_ubicacion = [c for c in categorical_cols if c not in ("Municipio", "Estado")]
    if categorical_sin_ubicacion != categorical_cols:
        print(f"\n[cv-sin-ubicacion] evaluando {best_name} SIN Municipio/Estado "
              f"(categóricas restantes: {categorical_sin_ubicacion or 'ninguna'}) ...")
        pipe_sin_ubi = build_pipeline(candidates[best_name], numeric_cols, categorical_sin_ubicacion)
        rmse_su, mae_su, r2_su, _ = evaluate_cv(
            pipe_sin_ubi, train[numeric_cols + categorical_sin_ubicacion], y,
            model_name=f"{best_name}_sin_ubicacion",
        )
        if rmse_su is not None:
            print(f"[cv-sin-ubicacion] {best_name} sin Municipio/Estado: RMSE={rmse_su:.3f}  MAE={mae_su:.3f}  R2={r2_su:.3f}")
            print(f"[cv-sin-ubicacion] comparación: CON ubicación RMSE={best_rmse:.3f} vs SIN ubicación RMSE={rmse_su:.3f} "
                  f"-- la diferencia es aproximadamente cuánto le está aportando la ubicación por sí sola "
                  f"(entre más grande la diferencia, más depende el modelo de memorizar ubicación en vez de "
                  f"señal transferible de percepción remota/clima/suelo).")
            diag_rows.append({"chequeo": "con_municipio_estado", "rmse": best_rmse})
            diag_rows.append({"chequeo": "sin_municipio_estado", "rmse": rmse_su})

    if diag_rows:
        pd.DataFrame(diag_rows).to_csv(MODEL_DIR / "diagnostico_ubicacion.csv", index=False)
        print(f"\n[diagnóstico] guardado en {MODEL_DIR / 'diagnostico_ubicacion.csv'} -- "
              f"úsalo en la sección de metodología/resultados del reporte técnico para justificar "
              f"por qué el modelo final sí/no incluye Municipio/Estado.")

    # Reentrenar el mejor modelo con TODOS los datos de entrenamiento
    best_pipeline.fit(X, y)
    joblib.dump(best_pipeline, MODEL_DIR / "modelo_final.joblib")

    feature_cols = numeric_cols + categorical_cols
    with open(MODEL_DIR / "features_seleccionadas.json", "w") as f:
        json.dump({"numeric": numeric_cols, "categorical": categorical_cols, "modelo_ganador": best_name}, f, indent=2)

    # --- Feature importance / permutation importance para preguntas guía ---
    print("\n[importancia] calculando permutation importance (puede tardar un poco)...")
    perm = permutation_importance(best_pipeline, X, y, n_repeats=20, random_state=cfg.RANDOM_STATE, n_jobs=-1)
    imp_df = pd.DataFrame({
        "feature": feature_cols,
        "importancia_media": perm.importances_mean,
        "importancia_std": perm.importances_std,
    }).sort_values("importancia_media", ascending=False)
    imp_df.to_csv(MODEL_DIR / "feature_importance.csv", index=False)

    print("\nTop 15 variables más importantes (para responder las 3 preguntas guía):")
    print(imp_df.head(15).to_string(index=False))

    # Resumen rápido, categorizado, para orientar la redacción del reporte
    indices_top = [f for f in imp_df["feature"].head(15) if any(idx in f for idx in
                   ["ndvi", "evi", "lai", "savi", "msavi", "fapar", "ndwi", "msi"])]
    clima_top = [f for f in imp_df["feature"].head(15) if any(k in f for k in ["precip", "tmax", "tmin", "gdd"])]
    print(f"\n-> Índices de vegetación más influyentes: {indices_top}")
    print(f"-> Variables climáticas más influyentes: {clima_top}")


if __name__ == "__main__":
    main()
