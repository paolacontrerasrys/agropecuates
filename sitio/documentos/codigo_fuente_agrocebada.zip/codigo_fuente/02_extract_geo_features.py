"""
Paso 2 — Extracción geoespacial: clima (CHIRPS/CHIRTS-ERA5) y topografía
(INEGI CEM4) por parcela.

Puntos importantes que ya verifiqué en el dataset y que este script maneja:

1. Los rasters de clima (precipitación, Tmin, Tmax) tienen resolución de
   ~5 km (0.05°, EPSG:4326) — mucho más grande que cualquier parcela (que
   mide entre <1 y ~20 ha). Por lo tanto, para clima usamos el valor del
   pixel en el CENTROIDE de cada parcela (muestreo puntual), no un
   promedio zonal — con un pixel de 5 km, casi todas las parcelas caen
   completas dentro de un solo pixel, así que "zonal stats" no aporta
   nada extra y puede fallar si el polígono no alcanza a cubrir un
   centro de pixel completo.

2. Los rasters de topografía (elevación y pendiente) sí tienen una
   resolución razonable frente al tamaño de parcela (120 m), así que ahí
   sí calculamos estadísticos zonales (media/min/max/std) dentro del
   polígono real de cada parcela.

3. OJO CON LA PROYECCIÓN: el shapefile de parcelas y los rasters de
   clima están en EPSG:4326 (lon/lat), pero los rasters de topografía
   (INEGI CEM4) vienen en EPSG:6372 (Lambert Conformal Cónica de
   México). Este script reproyecta las parcelas a la proyección de cada
   raster antes de extraer valores — si no haces esto vas a obtener
   basura o NaN en topografía.

Salidas (en outputs/02_geo/):
  - clima_mensual_por_parcela.csv   (ID_POLIGONO, anio, mes, precip_mm, tmin_c, tmax_c)
  - topografia_por_parcela.csv      (ID_POLIGONO, elev_media, elev_std, elev_min, elev_max,
                                      pendiente_media, pendiente_std, pendiente_min, pendiente_max)
"""

import sys
import re
import zipfile
from pathlib import Path
from importlib import import_module

sys.path.insert(0, str(Path(__file__).resolve().parent))
cfg = import_module("00_config")

import numpy as np
import pandas as pd
import geopandas as gpd
import rasterio

GEO_DIR = cfg.OUTPUT_DIR / "02_geo"
GEO_DIR.mkdir(parents=True, exist_ok=True)


def extract_zip(zip_path: Path, dest_subdir: str) -> Path:
    dest = cfg.WORKDIR / dest_subdir
    if not dest.exists() or not any(dest.rglob("*.tif")):
        print(f"[extract] descomprimiendo {zip_path.name} -> {dest}")
        dest.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(zip_path) as zf:
            zf.extractall(dest)
    else:
        print(f"[extract] ya descomprimido: {dest}")
    return dest


def load_parcelas() -> gpd.GeoDataFrame:
    gdf = gpd.read_file(cfg.PARCELAS_SHP)
    # El campo viene truncado a 10 caracteres por el formato .dbf ("ID_POLIGON")
    rename_map = {}
    for c in gdf.columns:
        if c.upper().startswith("ID_POLIGON"):
            rename_map[c] = cfg.ID_COL
    gdf = gdf.rename(columns=rename_map)
    print(f"[parcelas] {len(gdf)} polígonos cargados, CRS={gdf.crs}")
    assert cfg.ID_COL in gdf.columns, f"No encontré la columna de ID en el shapefile: {gdf.columns.tolist()}"
    return gdf


CENTROID_CRS = "EPSG:6372"  # proyección métrica (Lambert Cónica Conforme de México, la misma que usa la topografía) — calcular el centroide en grados (lon/lat) da resultados ligeramente incorrectos para polígonos no puntuales


def _xy_to_rowcol(transform, x, y):
    """
    Convierte coordenadas (x, y) a (fila, columna) de pixel a partir de la
    matriz afín del raster, invirtiéndola "a mano" con álgebra lineal básica.

    NO usamos rasterio.transform.rowcol()/sample_gen() ni el operador `~`
    de Affine a propósito: hay versiones de la librería `affine` (3.0.x)
    con un bug real que rompe esa inversión
    ("No '__dict__' attribute on 'Affine' instance to cache 'is_degenerate'
    property"). Haciendo la inversión nosotros mismos evitamos por completo
    ese bug, sin importar qué versión de `affine` tengas instalada.

    La transformación afín estándar de un raster es:
        x = a*col + b*row + c
        y = d*col + e*row + f
    Para los GeoTIFF de este dataset (norte arriba, sin rotación) b=d=0,
    pero aquí resolvemos el caso general invirtiendo la matriz 2x2 [a b; d e].
    """
    a, b, c, d, e, f = transform.a, transform.b, transform.c, transform.d, transform.e, transform.f
    det = a * e - b * d
    if det == 0:
        raise ValueError("Transformación afín degenerada (determinante 0); revisa el raster.")
    col = (e * (x - c) - b * (y - f)) / det
    row = (-d * (x - c) + a * (y - f)) / det
    return int(np.floor(row)), int(np.floor(col))


def _zonal_stats_manual(gdf_proj: gpd.GeoDataFrame, src: "rasterio.DatasetReader"):
    """
    Reimplementación mínima de rasterstats.zonal_stats (mean/std/min/max por
    polígono) que NO usa rasterio.features.rasterize ni rasterio.mask, porque
    ambos invierten la matriz afín por debajo y pueden pisar el mismo bug de
    `affine` 3.0.x que rompe sample_gen/rowcol.

    Estrategia: para cada polígono, recorta la ventana rectangular del raster
    que cubre su bounding box (usando nuestra propia inversión manual de
    coordenadas), genera las coordenadas del CENTRO de cada pixel de esa
    ventana con la transformación afín hacia adelante (esa sí es segura, no
    requiere invertir nada), y usa `shapely.contains_xy` (vectorizado) para
    saber qué píxeles caen dentro del polígono real.
    """
    from shapely import contains_xy

    band = src.read(1).astype(float)
    nrows, ncols = band.shape
    nodata = src.nodata
    transform = src.transform

    results = []
    for geom in gdf_proj.geometry:
        minx, miny, maxx, maxy = geom.bounds
        r_top, c_left = _xy_to_rowcol(transform, minx, maxy)
        r_bot, c_right = _xy_to_rowcol(transform, maxx, miny)
        r0, r1 = sorted((max(r_top, 0), min(r_bot, nrows - 1)))
        c0, c1 = sorted((max(c_left, 0), min(c_right, ncols - 1)))

        if r0 > r1 or c0 > c1:
            results.append({"mean": None, "std": None, "min": None, "max": None})
            continue

        sub = band[r0:r1 + 1, c0:c1 + 1]
        rr, cc = np.meshgrid(np.arange(r0, r1 + 1), np.arange(c0, c1 + 1), indexing="ij")
        # transformación afín hacia adelante (pixel -> mundo), esta dirección no requiere invertir nada
        xs = transform.a * (cc + 0.5) + transform.b * (rr + 0.5) + transform.c
        ys = transform.d * (cc + 0.5) + transform.e * (rr + 0.5) + transform.f

        inside = contains_xy(geom, xs, ys)
        if nodata is not None:
            inside &= sub != nodata

        vals = sub[inside]
        if vals.size == 0:
            results.append({"mean": None, "std": None, "min": None, "max": None})
        else:
            results.append({
                "mean": float(vals.mean()),
                "std": float(vals.std()),
                "min": float(vals.min()),
                "max": float(vals.max()),
            })
    return results


def sample_points(gdf: gpd.GeoDataFrame, raster_path: Path):
    """Devuelve una Serie con el valor del raster en el centroide de cada parcela."""
    # Centroide en una proyección métrica (evita el warning/imprecisión de calcular
    # centroides sobre geometrías en grados) y luego se reproyecta al CRS del raster.
    centroids_proj = gdf.geometry.to_crs(CENTROID_CRS).centroid
    centroids = gpd.GeoSeries(centroids_proj, crs=CENTROID_CRS)

    with rasterio.open(raster_path) as src:
        pts = centroids.to_crs(src.crs) if src.crs is not None else centroids
        band = src.read(1)
        nrows, ncols = band.shape
        nodata = src.nodata

        vals = []
        for p in pts:
            row, col = _xy_to_rowcol(src.transform, p.x, p.y)
            if 0 <= row < nrows and 0 <= col < ncols:
                v = band[row, col]
                vals.append(None if (nodata is not None and v == nodata) else float(v))
            else:
                vals.append(None)  # centroide fuera de la extensión del raster
    return pd.Series(vals, index=gdf.index)


def build_climate_table(gdf: gpd.GeoDataFrame) -> pd.DataFrame:
    precip_dir = extract_zip(cfg.CHIRPS_ZIP, "chirps") / "Reto_AgroCebada_CHIRPS_Precipitacion_2022_2025"
    temp_dir = extract_zip(cfg.TEMP_ZIP, "temperatura") / "Reto_AgroCebada_Temperatura_2022_2025"

    precip_tifs = sorted(precip_dir.rglob("PREC_*.tif"))
    tmax_tifs = sorted(temp_dir.rglob("Tmax_*.tif"))
    tmin_tifs = sorted(temp_dir.rglob("Tmin_*.tif"))

    print(f"[clima] {len(precip_tifs)} rasters de precipitación, {len(tmax_tifs)} Tmax, {len(tmin_tifs)} Tmin")

    def parse_year_month(fname: str):
        m = re.search(r"(\d{4})_(\d{2})", fname)
        return int(m.group(1)), int(m.group(2))

    rows = []
    id_series = gdf[cfg.ID_COL]

    def index_by_ym(tifs):
        return {parse_year_month(t.name): t for t in tifs}

    precip_by_ym = index_by_ym(precip_tifs)
    tmax_by_ym = index_by_ym(tmax_tifs)
    tmin_by_ym = index_by_ym(tmin_tifs)

    all_ym = sorted(set(precip_by_ym) | set(tmax_by_ym) | set(tmin_by_ym))
    for (year, month) in all_ym:
        precip = sample_points(gdf, precip_by_ym[(year, month)]) if (year, month) in precip_by_ym else None
        tmax = sample_points(gdf, tmax_by_ym[(year, month)]) if (year, month) in tmax_by_ym else None
        tmin = sample_points(gdf, tmin_by_ym[(year, month)]) if (year, month) in tmin_by_ym else None
        for i in gdf.index:
            rows.append(
                {
                    cfg.ID_COL: id_series.loc[i],
                    "anio": year,
                    "mes": month,
                    "precip_mm": precip.loc[i] if precip is not None else None,
                    "tmax_c": tmax.loc[i] if tmax is not None else None,
                    "tmin_c": tmin.loc[i] if tmin is not None else None,
                }
            )
        print(f"[clima] procesado {year}-{month:02d}")

    df = pd.DataFrame(rows)
    return df


def build_topo_table(gdf: gpd.GeoDataFrame) -> pd.DataFrame:
    topo_dir = extract_zip(cfg.TOPO_ZIP, "topografia")
    elev_tif = next(topo_dir.rglob("Elevacion_*.tif"))
    pend_tif = next(topo_dir.rglob("Pendiente_*.tif"))

    print(f"[topo] elevación: {elev_tif.name}, pendiente: {pend_tif.name}")

    def zonal(tif_path, prefix):
        with rasterio.open(tif_path) as src:
            gdf_r = gdf.to_crs(src.crs) if gdf.crs != src.crs else gdf
            stats = _zonal_stats_manual(gdf_r, src)
        out = pd.DataFrame(stats)
        out.columns = [f"{prefix}_{c}" for c in out.columns]
        return out

    elev = zonal(elev_tif, "elev")
    pend = zonal(pend_tif, "pendiente")

    df = pd.concat([gdf[[cfg.ID_COL]].reset_index(drop=True), elev, pend], axis=1)
    return df


def main():
    gdf = load_parcelas()

    clima = build_climate_table(gdf)
    clima_path = GEO_DIR / "clima_mensual_por_parcela.csv"
    clima.to_csv(clima_path, index=False)
    print(f"[clima] guardado en {clima_path} ({len(clima)} filas)")

    topo = build_topo_table(gdf)
    topo_path = GEO_DIR / "topografia_por_parcela.csv"
    topo.to_csv(topo_path, index=False)
    print(f"[topo] guardado en {topo_path} ({len(topo)} filas)")
    print(topo.describe().to_string())


if __name__ == "__main__":
    main()
