"""
Paso 10 (opcional) — Variables climáticas adicionales de NASA POWER.

CHIRPS (precipitación) y CHIRTS-ERA5 (Tmax/Tmin), que ya vienen en el
dataset oficial y se procesan en 02/03, no incluyen radiación solar, humedad
relativa ni viento -- tres variables con peso agronómico real en el
rendimiento de un cultivo de temporal como la cebada (radiación solar limita
la fotosíntesis; humedad relativa y viento, junto con la temperatura,
determinan la demanda evaporativa del aire, que es lo que en la práctica
"seca" el cultivo entre lluvias). NASA POWER (power.larc.nasa.gov) es una
fuente pública de reanálisis climático mensual con esas variables, con
"community=AG" pensada específicamente para agricultura.

QUÉ HACE ESTE SCRIPT
  1. Calcula el centroide (lat/lon) de cada una de las 197 parcelas.
  2. Redondea esas coordenadas para deduplicar: NASA POWER viene a una
     resolución de rejilla de ~0.5° x 0.625° (~50-70 km), mucho más gruesa
     que la separación típica entre parcelas de este reto -- así que
     parcelas cercanas casi siempre caen en la misma celda, y no tiene
     sentido (ni es amable con la API pública) hacer una consulta HTTP por
     cada una de las 197 parcelas si muchas comparten la misma celda real.
  3. Consulta la API mensual de NASA POWER UNA vez por coordenada única
     (con caché en disco -- outputs/10_nasa_power/cache_api/ -- para que
     volver a correr el script no repita llamadas ya hechas).
  4. Calcula VPD (déficit de presión de vapor, estilo FAO-56) a partir de
     Tmax/Tmin/RH de la propia NASA POWER.
  5. Agrega todo al ciclo (abril-octubre 2025) y calcula anomalía respecto
     al promedio histórico 2022-2024 (mismos meses), exactamente el mismo
     patrón que build_climate_cycle_features() en 03_build_feature_table.py.

Salida: outputs/10_nasa_power/nasa_power_por_parcela.csv
  Columnas: ID_POLIGONO, nasapower_{srad,rh,wind,vpd}_ciclo,
  nasapower_{srad,rh,wind,vpd}_hist, nasapower_{srad,rh,wind,vpd}_anomalia

OPCIONAL Y CON DEGRADACIÓN CONTROLADA: si no tienes internet aquí (o la API
está caída), el script avisa y no rompe el resto del pipeline -- simplemente
no generes este archivo y 03_build_feature_table.py lo omite automáticamente
(igual que hace con el suelo de 08 si no corriste ese paso).

Requiere: pip install requests  (probablemente ya lo tengas si usaste geopandas)
"""

import sys
import json
import time
from pathlib import Path
from importlib import import_module

sys.path.insert(0, str(Path(__file__).resolve().parent))
cfg = import_module("00_config")

import numpy as np
import pandas as pd

OUT_DIR = cfg.OUTPUT_DIR / "10_nasa_power"
OUT_DIR.mkdir(parents=True, exist_ok=True)
CACHE_DIR = OUT_DIR / "cache_api"
CACHE_DIR.mkdir(parents=True, exist_ok=True)

POWER_URL = "https://power.larc.nasa.gov/api/temporal/monthly/point"
PARAMETERS = ["ALLSKY_SFC_SW_DWN", "RH2M", "WS2M", "T2M_MAX", "T2M_MIN"]

# Redondeo de coordenadas para deduplicar llamadas a la API -- ver punto 2
# del docstring del módulo. 1 decimal de grado (~11 km en esta latitud) es
# bastante más fino que la resolución real de NASA POWER (~50-70 km), así
# que no se está tirando resolución que la fuente sí tuviera.
COORD_ROUND = 1

START_YEAR = pd.to_datetime(cfg.HIST_INICIO).year
END_YEAR = pd.to_datetime(cfg.CICLO_FIN).year


def get_centroids():
    """
    Centroides (lat/lon en grados, EPSG:4326) por parcela -- mismo cálculo
    que 06_paper_lstm_gp.get_lat_lon(), pero reimplementado aquí para que
    este script no dependa de PyTorch (que 06 sí requiere).
    """
    import geopandas as gpd
    gdf = gpd.read_file(cfg.PARCELAS_SHP)
    id_col_shp = [c for c in gdf.columns if c.upper().startswith("ID_POLIGON")][0]
    gdf = gdf.rename(columns={id_col_shp: cfg.ID_COL})
    centroids = gdf.geometry.to_crs("EPSG:6372").centroid.to_crs("EPSG:4326")
    return pd.DataFrame({cfg.ID_COL: gdf[cfg.ID_COL], "lon": centroids.x, "lat": centroids.y})


def query_power(lat, lon):
    """
    Consulta NASA POWER (API mensual por punto) para un solo par lat/lon,
    cacheando la respuesta cruda en disco por coordenada redondeada -- así,
    correr el script varias veces no repite llamadas a coordenadas ya
    consultadas.
    """
    import requests

    key = f"{lat:.{COORD_ROUND}f}_{lon:.{COORD_ROUND}f}"
    cache_path = CACHE_DIR / f"{key}.json"
    if cache_path.exists():
        with open(cache_path) as f:
            return json.load(f)

    params = {
        "parameters": ",".join(PARAMETERS),
        "community": "AG",
        "longitude": lon,
        "latitude": lat,
        "start": str(START_YEAR),
        "end": str(END_YEAR),
        "format": "JSON",
    }
    resp = requests.get(POWER_URL, params=params, timeout=60)
    resp.raise_for_status()
    data = resp.json()
    with open(cache_path, "w") as f:
        json.dump(data, f)
    time.sleep(0.5)  # cortesía con la API pública -- no golpearla demasiado rápido
    return data


def parse_power_response(data):
    """
    Convierte la respuesta JSON de NASA POWER (un dict por parámetro, con
    llaves 'YYYYMM' -> valor, más una llave de resumen ANUAL 'YYYY13' que se
    descarta) en un DataFrame largo (anio, mes, parametro, valor). Los
    valores faltantes de POWER vienen codificados como -999.

    OJO: la llave de resumen anual 'YYYY13' tiene el MISMO LARGO (6
    caracteres) que una llave mensual normal 'YYYYMM' -- filtrar solo por
    longitud de string no la descarta (bug real que causaba un "mes 13"
    inválido y tumbaba pd.to_datetime más adelante). Hay que validar también
    que el mes esté en el rango 1-12.
    """
    rows = []
    params_dict = data["properties"]["parameter"]
    for param, series in params_dict.items():
        for yyyymm, value in series.items():
            if len(yyyymm) != 6:
                continue
            year, month = int(yyyymm[:4]), int(yyyymm[4:6])
            if month < 1 or month > 12:
                continue  # descarta el resumen ANUAL 'YYYY13' (mes=13 no es un mes real)
            if value in (-999, -999.0):
                continue
            rows.append({"anio": year, "mes": month, "parametro": param, "valor": float(value)})
    return pd.DataFrame(rows)


def compute_vpd(tmax_c, tmin_c, rh_pct):
    """
    Déficit de presión de vapor (VPD, kPa), estilo FAO-56: presión de vapor
    de saturación a la temperatura media del mes, menos la presión de vapor
    real (saturación x humedad relativa/100). VPD alto = aire "sediento"
    (alta demanda evaporativa) -- variable que ni CHIRPS/CHIRTS ni los
    índices espectrales capturan directamente.
    """
    tmean = (tmax_c + tmin_c) / 2
    es = 0.6108 * np.exp(17.27 * tmean / (tmean + 237.3))
    ea = es * rh_pct / 100.0
    return es - ea


def main():
    print("[nasa-power] calculando centroides de las 197 parcelas ...")
    centroids = get_centroids()
    centroids["lat_r"] = centroids["lat"].round(COORD_ROUND)
    centroids["lon_r"] = centroids["lon"].round(COORD_ROUND)

    coords_unicas = centroids[["lat_r", "lon_r"]].drop_duplicates()
    print(f"[nasa-power] {len(centroids)} parcelas -> {len(coords_unicas)} coordenadas únicas tras "
          f"redondear a {COORD_ROUND} decimal(es) (~11 km) -- eso es lo que se consulta a la API, "
          f"no una llamada por parcela.")

    try:
        import requests  # noqa: F401
    except ImportError:
        raise SystemExit("Falta 'requests' para consultar la API de NASA POWER. Instálalo con: pip install requests")

    all_monthly = []
    for i, row in enumerate(coords_unicas.itertuples(), start=1):
        print(f"  [{i}/{len(coords_unicas)}] consultando NASA POWER para lat={row.lat_r}, lon={row.lon_r} ...")
        try:
            data = query_power(row.lat_r, row.lon_r)
            monthly = parse_power_response(data)
        except Exception as e:
            print(f"    AVISO: falló la consulta para lat={row.lat_r}, lon={row.lon_r} "
                  f"({type(e).__name__}: {e}) -- se omite esta coordenada.")
            continue
        monthly["lat_r"] = row.lat_r
        monthly["lon_r"] = row.lon_r
        all_monthly.append(monthly)

    if not all_monthly:
        raise SystemExit("[nasa-power] no se pudo obtener NINGÚN dato de NASA POWER -- revisa tu conexión a internet.")

    monthly_df = pd.concat(all_monthly, ignore_index=True)
    wide = monthly_df.pivot_table(index=["lat_r", "lon_r", "anio", "mes"], columns="parametro", values="valor").reset_index()

    # VPD mensual a partir de Tmax/Tmin/RH de la propia NASA POWER (no de
    # CHIRTS) -- consistente en sí mismo, aunque Tmax/Tmin de POWER pueden
    # diferir ligeramente de los de CHIRTS-ERA5 ya usados en 02/03 (fuentes
    # distintas). Se deja como variable ADICIONAL, no reemplaza tmax_anomalia.
    if {"T2M_MAX", "T2M_MIN", "RH2M"}.issubset(wide.columns):
        wide["VPD"] = compute_vpd(wide["T2M_MAX"], wide["T2M_MIN"], wide["RH2M"])

    wide["fecha"] = pd.to_datetime(dict(year=wide["anio"], month=wide["mes"], day=1))
    ciclo = wide[(wide["fecha"] >= cfg.CICLO_INICIO) & (wide["fecha"] <= cfg.CICLO_FIN)]
    hist = wide[(wide["fecha"] >= cfg.HIST_INICIO) & (wide["fecha"] <= cfg.HIST_FIN)]
    meses_ciclo = pd.to_datetime(cfg.CICLO_INICIO).month, pd.to_datetime(cfg.CICLO_FIN).month
    hist_mismos_meses = hist[hist["mes"].between(meses_ciclo[0], meses_ciclo[1])]

    agg_cols = {"ALLSKY_SFC_SW_DWN": "srad", "RH2M": "rh", "WS2M": "wind", "VPD": "vpd"}

    agg_ciclo = ciclo.groupby(["lat_r", "lon_r"]).agg(
        **{f"nasapower_{short}_ciclo": (col, "mean") for col, short in agg_cols.items() if col in ciclo.columns}
    ).reset_index()
    agg_hist = hist_mismos_meses.groupby(["lat_r", "lon_r"]).agg(
        **{f"nasapower_{short}_hist": (col, "mean") for col, short in agg_cols.items() if col in hist_mismos_meses.columns}
    ).reset_index()

    agg = agg_ciclo.merge(agg_hist, on=["lat_r", "lon_r"], how="left")
    for col, short in agg_cols.items():
        c_ciclo, c_hist = f"nasapower_{short}_ciclo", f"nasapower_{short}_hist"
        if c_ciclo in agg.columns and c_hist in agg.columns:
            agg[f"nasapower_{short}_anomalia"] = agg[c_ciclo] - agg[c_hist]

    out = centroids.merge(agg, on=["lat_r", "lon_r"], how="left").drop(columns=["lat_r", "lon_r", "lat", "lon"])
    out_path = OUT_DIR / "nasa_power_por_parcela.csv"
    out.to_csv(out_path, index=False)
    print(f"\n[nasa-power] listo -- {out.shape[0]} parcelas x {out.shape[1] - 1} columnas nuevas -> {out_path}")
    print("Corre de nuevo 03_build_feature_table.py para que estas columnas se fusionen automáticamente "
          "al dataset de features (igual que hace con el suelo de 08_soil_features.py).")


if __name__ == "__main__":
    main()
