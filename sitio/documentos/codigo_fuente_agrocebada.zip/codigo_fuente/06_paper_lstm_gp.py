"""
Paso 6 — Implementación adaptada del paper:
You, Li, Low, Lobell, Ermon (2017), "Deep Gaussian Process for Crop Yield
Prediction Based on Remote Sensing Data", AAAI.
https://cs.stanford.edu/~ermon/papers/cropyield_AAAI17.pdf

QUÉ HACE EL PAPER ORIGINAL
Extraen, para cada condado y año, un histograma de reflectancia de bandas
MODIS a lo largo del tiempo (una "imagen" tiempo x bins-de-histograma), la
pasan por una CNN (o LSTM) para obtener un embedding, y usan ese embedding
como entrada de un Proceso Gaussiano (GP) en vez de una regresión lineal
simple. El GP modela la correlación espacial entre condados vecinos, lo cual
"comparte" información estadística entre observaciones cercanas y compensa
tener pocos años/condados etiquetados.

ADAPTACIÓN A NUESTRO DATASET (justificación para el reporte técnico)
Nuestro dataset NO trae píxeles crudos ni histogramas — trae, por parcela y
fecha, promedio/std/max/min de cada índice espectral. Esto es, en espíritu,
una versión ya comprimida de un histograma (los primeros momentos
estadísticos de la distribución de píxeles dentro de la parcela). Por lo
tanto:
  - En vez de "histograma de reflectancia -> CNN 2D", usamos
    "serie de tiempo de estadísticos por índice -> LSTM" (mismo rol: un
    encoder profundo que resume la dinámica temporal en un embedding fijo).
  - En vez de un GP con kernel espacial puro, usamos un GP cuya entrada es
    el embedding del LSTM concatenado con la posición (lat/lon) de la
    parcela -- así el GP captura tanto "parcelas con fenología parecida"
    como "parcelas geográficamente cercanas", que es el mismo principio del
    paper (compartir estadística entre observaciones similares/vecinas).

MEJORAS DE ESTRUCTURA respecto a la primera versión (motivadas por un
diagnóstico real en 04_train_and_evaluate.py -- ver ese script: con el
modelo de árboles, Municipio/Estado dominan la importancia de variables por
encima de cualquier índice satelital, lo cual es una señal de que ese
modelo puede estar "memorizando" el promedio de rendimiento por municipio
en vez de aprender señal transferible de percepción remota/clima/suelo):

  1. POOLING POR ATENCIÓN en vez de "último estado oculto": el LSTM original
     resumía toda la serie en el estado oculto del ÚLTIMO paso de tiempo.
     Ahora se usa un promedio ponderado (atención aprendida) sobre TODOS los
     pasos de tiempo del ciclo -- más fiel al espíritu del paper (resumir
     toda la temporada, no solo el final) y más robusto a ruido/outliers en
     las últimas semanas interpoladas.
  2. BAGGING (N_BAGS modelos por fold, ver arriba): reduce la varianza de
     una red tan chica entrenada con tan pocas filas.
  3. YA NO SE USA EL FOLD DE TEST PARA EARLY STOPPING: la versión anterior
     usaba el propio fold de validación cruzada como set de validación para
     decidir cuándo detener el entrenamiento del LSTM -- una fuga leve de
     información (el punto de corte del entrenamiento "veía" el fold de
     prueba). Ahora cada bag separa su propio split interno de validación
     DENTRO del conjunto de entrenamiento del fold, sin tocar el fold de
     prueba en ningún momento del entrenamiento.
  4. COVARIABLES ESTÁTICAS EN EL GP: además del embedding y lat/lon, el GP
     ahora recibe anomalías climáticas, GDD, topografía y suelo (si ya
     corriste 02/08) -- variables estáticas legítimas del reto, no
     temporales, que no tenía sentido meter como canal del LSTM pero sí
     como covariable directa del GP (exactamente el rol que cumple el GP en
     el paper: incorporar información adicional más allá del embedding).
     Deliberadamente NO se incluyen Municipio/Estado aquí -- ver el
     diagnóstico arriba. El GP ya captura estructura espacial de forma
     continua vía lat/lon, que es un mecanismo más defendible
     metodológicamente que memorizar categorías administrativas.
  5. VALIDACIÓN LeaveOneGroupOut POR MUNICIPIO (además del KFold normal):
     confirma que el desempeño no depende de que parcelas del mismo
     municipio caigan a la vez en train y test -- cada fold deja fuera un
     único municipio completo (antes se usaba GroupKFold con 5 folds, que a
     veces agrupaba varios municipios chicos en un mismo fold y diluía el
     diagnóstico; ver sección correspondiente en main()).
  6. PRE-ENTRENAMIENTO AUTO-SUPERVISADO (USE_PRETRAINING=True por defecto):
     antes de entrenar el LSTM supervisado, se entrena un LSTMAutoEncoder
     por reconstrucción sobre secuencias parcela-año SIN etiqueta de
     2022-2025 (~197 parcelas x hasta 4 años), y esos pesos del encoder se
     usan como punto de partida (transfer learning) en cada fold/bag en vez
     de inicialización aleatoria -- con solo 138 filas etiquetadas, esto le
     da al encoder mucha más información de la dinámica típica de la serie
     antes de ver una sola etiqueta.

Esta pieza requiere PyTorch (no viene en requirements.txt base porque es
pesado y opcional). Instálalo con:
    pip install torch --index-url https://download.pytorch.org/whl/cpu

Salidas en outputs/06_paper_lstm_gp/:
  - cv_resultado_paper.csv          (RMSE/MAE/R2 de este modelo, para comparar
                                      directamente contra outputs/04_modelo/cv_resultados.csv)
  - cv_resultado_paper_groupkfold.csv (mismo modelo, validado con GroupKFold por
                                      Municipio -- validación "honesta" de generalización
                                      a municipios no vistos, ver punto 5 arriba)
  - embeddings_lstm.csv             (embedding aprendido por parcela, útil también
                                      como feature adicional para el modelo de árboles)
  - prediccion_paper_ton_ha.csv     (predicción final para las 59 parcelas ocultas
                                      con este modelo, para comparar contra 05_predict_final.py)
"""

import sys
from pathlib import Path
from importlib import import_module

sys.path.insert(0, str(Path(__file__).resolve().parent))
cfg = import_module("00_config")

import numpy as np
import pandas as pd

try:
    import torch
    import torch.nn as nn
except ImportError as e:
    raise SystemExit(
        "Falta PyTorch para este script. Instálalo con:\n"
        "    pip install torch --index-url https://download.pytorch.org/whl/cpu\n"
        f"(error original: {e})"
    )

from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, WhiteKernel, ConstantKernel
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import KFold, GroupKFold, LeaveOneGroupOut
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

OUT_DIR = cfg.OUTPUT_DIR / "06_paper_lstm_gp"
OUT_DIR.mkdir(parents=True, exist_ok=True)

# Bagging: promedia N_BAGS modelos LSTM+GP independientes (misma
# arquitectura, distinta semilla e inicialización) por fold/entrenamiento
# final. Con ~110 filas de entrenamiento por fold, una sola red da
# resultados sensibles a la inicialización aleatoria -- promediar reduce
# esa varianza sin tocar la arquitectura. Sube esto a 5 si tienes tiempo/CPU
# de sobra; bájalo a 1 para desactivar el bagging y volver al comportamiento
# original (una sola red por fold).
N_BAGS = 3

# Pre-entrenamiento auto-supervisado (transfer learning): entrena primero un
# autoencoder LSTM por reconstrucción sobre secuencias parcela-año SIN
# etiqueta (2022-2025, ~197 parcelas x hasta 4 años) y usa esos pesos del
# encoder como punto de partida al entrenar el LSTMEncoder supervisado en
# cada fold/bag, en vez de inicialización aleatoria. Motivación: con solo
# 138 filas etiquetadas, el LSTM supervisado tiene poco con qué aprender una
# buena representación desde cero; el autoencoder ve ~5x más secuencias
# (aunque sin etiqueta) y puede aprender de entrada qué patrones de serie
# temporal son "normales" en esta zona. Pon esto en False para volver al
# comportamiento anterior (inicialización aleatoria) y comparar el RMSE.
USE_PRETRAINING = True
PRETRAIN_YEARS = [2022, 2023, 2024, 2025]


def make_gp_kernel():
    """
    Kernel ISOTRÓPICO (un solo length_scale compartido por todas las
    dimensiones) en vez de ARD (un length_scale por dimensión).

    Con ~110-138 filas de entrenamiento y ~14 dimensiones de entrada
    (embedding del LSTM + lat/lon), un kernel ARD tiene demasiados
    hiperparámetros libres para el tamaño de muestra: el optimizador no
    logra identificarlos bien y varias dimensiones terminan "rindiéndose"
    en el límite superior del rango de búsqueda (los ConvergenceWarning que
    ves al correr el script son ese síntoma exacto). Como todas las
    entradas ya están estandarizadas a la misma escala (media 0, std 1),
    un solo length_scale compartido es un supuesto razonable y reduce el
    kernel de ~14 hiperparámetros a 3 (amplitud, length_scale, ruido) --
    mucho más estable con este tamaño de muestra.
    """
    return (
        ConstantKernel(1.0, constant_value_bounds=(1e-2, 1e2))
        * RBF(length_scale=1.0, length_scale_bounds=(1e-2, 1e3))
        + WhiteKernel(noise_level=0.1, noise_level_bounds=(1e-3, 1.0))
    )

torch.manual_seed(cfg.RANDOM_STATE)
np.random.seed(cfg.RANDOM_STATE)

# Índices "core" que usamos como canales de la secuencia temporal (analogía a
# los bins del histograma del paper). Elegidos por relevancia agronómica
# directa (vigor/vegetación + estrés hídrico), no todos los ~22 disponibles,
# para mantener la red pequeña y evitar sobreajuste con solo 138 parcelas.
S2_CHANNELS = ["ndvi", "evi", "lai", "savi", "ndwi", "msi"]
PLANET_CHANNELS = ["ndvi", "evi", "lai", "msavi"]
N_WEEKS = 30  # abril-octubre 2025 son ~30 semanas

# --- Alineación fenológica (opcional) ---------------------------------------
# Por defecto, todas las parcelas se alinean por CALENDARIO (misma ventana
# abril-octubre para las 197). En la realidad, la fecha de siembra varía por
# elevación/municipio/decisión del productor, así que el pico de vigor de
# cada parcela no necesariamente cae en la misma semana del año -- eso mete
# ruido a la serie que el LSTM tiene que promediar/ignorar.
#
# Con ALIGN_BY_PHENOLOGY = True, cada parcela se alinea por su propio inicio
# de "green-up" (detectado del NDVI) en vez de por la fecha calendario.
# Actívalo, corre el pipeline (06 y 07) de nuevo, y compara el RMSE contra la
# versión calendario -- si mejora, es una mejora real y defendible para el
# reporte técnico; si no, te ahorraste el esfuerzo de más ingeniería sin
# beneficio, que también es información válida.
ALIGN_BY_PHENOLOGY = False
PHENOLOGY_SEARCH_START = "2025-01-01"   # ventana amplia para buscar el onset
PHENOLOGY_SEARCH_END = "2025-11-30"
PHENOLOGY_WEEKS_BEFORE_ONSET = 4        # cuántas semanas antes del onset se incluyen (línea base pre-siembra)
PHENOLOGY_WEEKS_AFTER_ONSET = 25        # cuántas semanas después (cubre floración/llenado/cosecha)


def detect_greenup_onset(df_s2, id_poligono, search_start=PHENOLOGY_SEARCH_START, search_end=PHENOLOGY_SEARCH_END):
    """
    Detecta la semana de inicio de "green-up" (arranque del ciclo vegetativo)
    de una parcela a partir de su serie de NDVI (Sentinel-2), buscando dentro
    de una ventana amplia del año. Heurística simple y explicable (fácil de
    justificar en el reporte): se toma la semana con el mayor incremento
    (mayor derivada positiva) del NDVI suavizado dentro de la ventana de
    búsqueda -- ese es el momento de arranque más marcado del cultivo.

    Si la parcela no tiene suficientes observaciones para estimar un onset
    confiable, regresa None y build_dataset_phenology_aligned() usa el
    promedio de onset del resto de las parcelas como respaldo.
    """
    sub = df_s2[df_s2[cfg.ID_COL] == id_poligono]
    s = sub.set_index("fecha_captura")["ndvi_promedio"].dropna()
    s = s[(s.index >= search_start) & (s.index <= search_end)]
    if len(s) < 6:
        return None

    weekly = s.resample("W").mean().interpolate(limit_direction="both")
    smoothed = weekly.rolling(3, center=True, min_periods=1).mean()
    derivative = smoothed.diff()
    if derivative.dropna().empty:
        return None
    onset_date = derivative.idxmax()
    return onset_date


def build_weekly_sequence_phenology_aligned(df_s2, df_planet, id_poligono, onset_date, n_weeks_before, n_weeks_after):
    """
    Igual que build_weekly_sequence_for_parcel(), pero la rejilla semanal se
    define en relación al `onset_date` de ESA parcela (onset - n_weeks_before
    hasta onset + n_weeks_after), no a un calendario fijo compartido por
    todas. El resultado sigue siendo una matriz (N_WEEKS, n_canales) de la
    misma forma que la versión calendario, así que es un reemplazo directo.
    """
    week_index = pd.date_range(
        onset_date - pd.Timedelta(weeks=n_weeks_before),
        periods=n_weeks_before + n_weeks_after + 1,
        freq="W",
    )
    return build_weekly_sequence_for_parcel(df_s2, df_planet, id_poligono, week_index)


def build_weekly_sequence_for_parcel(df_s2, df_planet, id_poligono, week_index):
    """
    Construye la matriz (N_WEEKS, n_canales) para una parcela, remuestreando
    cada índice a frecuencia semanal (promedio de las observaciones de esa
    semana) e interpolando linealmente las semanas sin observación (algo
    inevitable con Sentinel-2/Landsat por nubosidad). Si un canal completo
    queda vacío para la parcela, se rellena con 0 tras estandarizar (ver
    build_dataset) -- es preferible a descartar la parcela.
    """
    channels = []

    def resample_channel(df, col):
        s = df.set_index("fecha_captura")[col].dropna()
        if len(s) == 0:
            return pd.Series(np.nan, index=week_index)
        s = s.resample("W").mean()
        s = s.reindex(week_index)
        s = s.interpolate(limit_direction="both")
        return s

    sub_s2 = df_s2[df_s2[cfg.ID_COL] == id_poligono]
    for ch in S2_CHANNELS:
        channels.append(resample_channel(sub_s2, f"{ch}_promedio"))

    sub_pl = df_planet[df_planet[cfg.ID_COL] == id_poligono]
    for ch in PLANET_CHANNELS:
        channels.append(resample_channel(sub_pl, f"{ch}_promedio"))

    mat = np.stack([c.to_numpy(dtype=float) for c in channels], axis=1)  # (N_WEEKS, n_channels)
    return mat


def build_dataset():
    global N_WEEKS

    # Para alineación fenológica necesitamos leer una ventana MÁS AMPLIA que
    # el ciclo abril-octubre (para poder detectar el onset aunque caiga antes
    # de abril, y tener semanas "después" del onset aunque se salgan de
    # octubre). Para calendario, seguimos usando solo el ciclo oficial.
    read_start = PHENOLOGY_SEARCH_START if ALIGN_BY_PHENOLOGY else cfg.CICLO_INICIO
    read_end = PHENOLOGY_SEARCH_END if ALIGN_BY_PHENOLOGY else cfg.CICLO_FIN

    s2_all = pd.read_csv(cfg.BASICO_CSV)
    s2_all["fecha_captura"] = pd.to_datetime(s2_all["fecha_captura"], format="%d/%m/%Y", errors="coerce")
    s2_all = s2_all[s2_all["sensor"] == "Sentinel-2"]
    s2_all = s2_all[(s2_all["fecha_captura"] >= read_start) & (s2_all["fecha_captura"] <= read_end)]

    planet_all = pd.read_csv(cfg.PRO_CSV)
    planet_all["fecha_captura"] = pd.to_datetime(planet_all["fecha_captura"], format="%d/%m/%Y", errors="coerce")
    planet_all = planet_all[(planet_all["fecha_captura"] >= read_start) & (planet_all["fecha_captura"] <= read_end)]

    target = pd.read_csv(cfg.ID_RENDIMIENTO_CSV).rename(
        columns={"RENDIMIENTO_T_HA": "rendimiento_t_ha", "AREA_HA": "area_ha"}
    )

    sequences = {}

    if ALIGN_BY_PHENOLOGY:
        N_WEEKS = PHENOLOGY_WEEKS_BEFORE_ONSET + PHENOLOGY_WEEKS_AFTER_ONSET + 1
        print(f"[paper] modo FENOLÓGICO activado: detectando onset de green-up por parcela "
              f"y construyendo secuencias de {N_WEEKS} semanas relativas a ese onset ...")

        onsets = {}
        for pid in target[cfg.ID_COL]:
            onsets[pid] = detect_greenup_onset(s2_all, pid)

        detectados = [d for d in onsets.values() if d is not None]
        if not detectados:
            raise RuntimeError("No se pudo detectar el onset de green-up en NINGUNA parcela -- revisa las fechas/datos.")
        # Onset promedio (en día del año) como respaldo para parcelas sin suficiente señal
        mean_doy = int(np.mean([d.dayofyear for d in detectados]))
        fallback_onset = pd.Timestamp(f"{pd.to_datetime(cfg.CICLO_INICIO).year}-01-01") + pd.Timedelta(days=mean_doy - 1)
        n_fallback = sum(1 for d in onsets.values() if d is None)
        if n_fallback:
            print(f"[paper] AVISO: {n_fallback} parcela(s) sin señal suficiente para detectar onset -- "
                  f"se les asigna el onset promedio del resto ({fallback_onset.date()}).")

        for pid in target[cfg.ID_COL]:
            onset = onsets[pid] or fallback_onset
            sequences[pid] = build_weekly_sequence_phenology_aligned(
                s2_all, planet_all, pid, onset, PHENOLOGY_WEEKS_BEFORE_ONSET, PHENOLOGY_WEEKS_AFTER_ONSET
            )
        week_index = np.arange(-PHENOLOGY_WEEKS_BEFORE_ONSET, PHENOLOGY_WEEKS_AFTER_ONSET + 1)  # semanas relativas, no fechas
    else:
        week_index = pd.date_range(cfg.CICLO_INICIO, cfg.CICLO_FIN, freq="W")
        N_WEEKS = len(week_index)
        print(f"[paper] construyendo secuencias semanales por CALENDARIO ({N_WEEKS} semanas x "
              f"{len(S2_CHANNELS) + len(PLANET_CHANNELS)} canales) por parcela ...")
        for pid in target[cfg.ID_COL]:
            sequences[pid] = build_weekly_sequence_for_parcel(s2_all, planet_all, pid, week_index)

    return target, sequences, week_index


def build_pretrain_dataset():
    """
    Construye secuencias semanales SIN ETIQUETA (no requieren rendimiento)
    para las 197 parcelas x hasta 4 años (2022-2025), reutilizando
    build_weekly_sequence_for_parcel() con una ventana calendario
    abril-octubre de CADA año (independiente de si ALIGN_BY_PHENOLOGY está
    activo para el modelo supervisado -- el pre-entrenamiento no necesita
    alinear por fenología, solo aprender la dinámica típica de la serie).
    Sentinel-2/Landsat cubren 2022-2025; Planet solo cubre 2025, así que los
    canales de Planet en 2022-2024 quedan en NaN -> se interpolan/rellenan
    igual que en build_dataset(), dándole a la red menos señal en esos años
    pero sin romper la forma (N_WEEKS, n_channels).

    Esto le da al LSTM autoencoder hasta ~197 x 4 = ~788 secuencias
    parcela-año (menos las que no tengan ninguna observación ese año) para
    aprender una representación general ANTES de ver una sola etiqueta de
    rendimiento -- transferencia de una tarea no supervisada (reconstrucción)
    a la tarea supervisada final (regresión), útil precisamente porque hay
    muchas más parcela-años sin etiqueta que parcelas CON etiqueta (138).
    """
    s2_all = pd.read_csv(cfg.BASICO_CSV)
    s2_all["fecha_captura"] = pd.to_datetime(s2_all["fecha_captura"], format="%d/%m/%Y", errors="coerce")
    s2_all = s2_all[s2_all["sensor"] == "Sentinel-2"]

    planet_all = pd.read_csv(cfg.PRO_CSV)
    planet_all["fecha_captura"] = pd.to_datetime(planet_all["fecha_captura"], format="%d/%m/%Y", errors="coerce")

    target = pd.read_csv(cfg.ID_RENDIMIENTO_CSV).rename(
        columns={"RENDIMIENTO_T_HA": "rendimiento_t_ha", "AREA_HA": "area_ha"}
    )
    all_ids = target[cfg.ID_COL].tolist()

    sequences = []
    for year in PRETRAIN_YEARS:
        ciclo_inicio = pd.Timestamp(f"{year}-04-01")
        ciclo_fin = pd.Timestamp(f"{year}-10-31")
        week_index_y = pd.date_range(ciclo_inicio, ciclo_fin, freq="W")
        s2_y = s2_all[(s2_all["fecha_captura"] >= ciclo_inicio) & (s2_all["fecha_captura"] <= ciclo_fin)]
        planet_y = planet_all[(planet_all["fecha_captura"] >= ciclo_inicio) & (planet_all["fecha_captura"] <= ciclo_fin)]
        for pid in all_ids:
            mat = build_weekly_sequence_for_parcel(s2_y, planet_y, pid, week_index_y)
            if np.isnan(mat).all():
                continue  # sin NINGUNA observación ese año -- no aporta nada, se omite
            sequences.append(mat)

    if not sequences:
        return None

    # Recortar/rellenar todas al mismo N_WEEKS que usa el modelo supervisado
    # (algunas ventanas de date_range pueden diferir en 1 semana según en qué
    # día de la semana cae el 1 de abril de cada año).
    target_len = N_WEEKS
    fixed = []
    for mat in sequences:
        if len(mat) == target_len:
            fixed.append(mat)
        elif len(mat) > target_len:
            fixed.append(mat[:target_len])
        else:
            pad = np.full((target_len - len(mat), mat.shape[1]), np.nan)
            fixed.append(np.vstack([mat, pad]))

    X_pretrain = np.stack(fixed)
    print(f"[paper-pretrain] {len(X_pretrain)} secuencias parcela-año construidas para pre-entrenamiento "
          f"no supervisado (años {PRETRAIN_YEARS}).")
    return X_pretrain


def get_lat_lon():
    """
    Coordenadas del centroide de cada parcela (en grados) + Municipio/Estado,
    tomados del shapefile. Municipio/Estado NO se usan como entrada del GP
    (ver docstring del módulo) -- se traen solo para poder armar la
    validación GroupKFold por municipio más abajo. Si geopandas no está
    disponible en tu entorno, este script sigue funcionando pero sin el
    componente espacial del GP ni la validación agrupada -- avisa por
    consola.
    """
    try:
        import geopandas as gpd
        gdf = gpd.read_file(cfg.PARCELAS_SHP)
        id_col_shp = [c for c in gdf.columns if c.upper().startswith("ID_POLIGON")][0]
        gdf = gdf.rename(columns={id_col_shp: cfg.ID_COL})
        centroids = gdf.geometry.to_crs("EPSG:6372").centroid.to_crs("EPSG:4326")
        out = pd.DataFrame({
            cfg.ID_COL: gdf[cfg.ID_COL],
            "lon": centroids.x,
            "lat": centroids.y,
            "Municipio": gdf["Municipio"] if "Municipio" in gdf.columns else None,
        })
        return out
    except Exception as e:
        print(f"[paper] AVISO: no pude leer lat/lon del shapefile ({e}). El GP usará solo el embedding.")
        return None


def get_static_covariates():
    """
    Covariables ESTÁTICAS (no temporales) para enriquecer la entrada del GP,
    además del embedding del LSTM y lat/lon: anomalías climáticas, GDD,
    topografía y suelo -- se leen de outputs/03_features/features_dataset.csv
    (generado por 03_build_feature_table.py, que a su vez ya fusiona suelo
    automáticamente si corriste 08_soil_features.py). Si ese archivo no
    existe todavía, o le faltan columnas de suelo/topografía (porque no has
    corrido esos pasos opcionales), simplemente se usa lo que esté
    disponible -- nunca truena por columnas faltantes.

    Deliberadamente NO se incluyen aquí Municipio/Estado: ver el diagnóstico
    en el docstring del módulo y en 04_train_and_evaluate.py.
    """
    path = cfg.OUTPUT_DIR / "03_features" / "features_dataset.csv"
    if not path.exists():
        print(f"[paper] AVISO: no encontré {path} -- el GP usará solo embedding+lat/lon. "
              f"Corre 03_build_feature_table.py para incluir clima/topografía/suelo.")
        return None

    df = pd.read_csv(path)
    # Nombres de columna confirmados contra los scripts 02/03/08 reales de
    # este pipeline (no adivinados) -- si cambiaste algo ahí, ajusta esta lista.
    numeric_wanted = ["precip_anomalia", "tmax_anomalia", "gdd_total_ciclo", "elev_mean", "pendiente_mean"]
    numeric_present = [c for c in numeric_wanted if c in df.columns]
    cat_wanted = ["GRUPO1_agrupado", "TEXTURA"]
    cat_present = [c for c in cat_wanted if c in df.columns]

    if not numeric_present and not cat_present:
        print("[paper] AVISO: features_dataset.csv no tiene columnas de clima/topografía/suelo "
              "reconocidas -- el GP usará solo embedding+lat/lon.")
        return None

    out = df[[cfg.ID_COL] + numeric_present].copy()
    for c in cat_present:
        out = pd.concat([out, pd.get_dummies(df[c], prefix=c)], axis=1)

    print(f"[paper] covariables estáticas adicionales para el GP -- numéricas: {numeric_present}, "
          f"categóricas (one-hot): {cat_present}")
    return out.set_index(cfg.ID_COL)


class LSTMEncoder(nn.Module):
    """
    Encoder pequeño a propósito (n=138): LSTM de una capa + pooling por
    atención sobre TODOS los pasos de tiempo (no solo el último) + cabeza
    lineal de regresión, con dropout fuerte. El embedding que usamos para el
    GP es la representación agregada por atención (después de dropout), no
    la predicción en sí -- así el GP puede corregir/re-calibrar lo que el
    LSTM aprendió.

    Por qué atención y no solo el último estado oculto: el ciclo completo
    (abril-octubre, ~30 semanas) tiene información relevante distribuida en
    varias etapas (emergencia, floración, llenado de grano), no solo al
    final -- usar nada más el último paso descarta esa información y es
    más sensible a ruido/interpolación en las últimas semanas. La atención
    aprende QUÉ semanas pesan más para predecir el rendimiento, en vez de
    asumir que la última importa más que las demás.
    """

    def __init__(self, n_channels, hidden_size=24, embedding_size=12, dropout=0.4):
        super().__init__()
        self.lstm = nn.LSTM(input_size=n_channels, hidden_size=hidden_size, batch_first=True)
        self.attn = nn.Linear(hidden_size, 1)  # puntaje de atención por paso de tiempo
        self.dropout = nn.Dropout(dropout)
        self.embed = nn.Linear(hidden_size, embedding_size)
        self.head = nn.Linear(embedding_size, 1)

    def forward(self, x):
        outputs, _ = self.lstm(x)  # (batch, n_semanas, hidden_size) -- todos los pasos
        attn_scores = self.attn(outputs).squeeze(-1)  # (batch, n_semanas)
        attn_weights = torch.softmax(attn_scores, dim=1).unsqueeze(-1)  # (batch, n_semanas, 1)
        h = (outputs * attn_weights).sum(dim=1)  # promedio ponderado sobre todo el ciclo
        h = self.dropout(h)
        emb = torch.tanh(self.embed(h))
        pred = self.head(emb)
        return pred.squeeze(-1), emb


class LSTMAutoEncoder(nn.Module):
    """
    Autoencoder que reutiliza EXACTAMENTE la misma arquitectura de encoder
    (LSTM + atención + embedding) que LSTMEncoder, más un decoder LSTM que
    intenta reconstruir la secuencia original a partir del embedding. Se
    entrena de forma NO supervisada (nunca usa rendimiento) sobre secuencias
    parcela-año de 2022-2025 (build_pretrain_dataset()) -- la idea
    (pre-entrenamiento auto-supervisado / transfer learning) es que el
    encoder aprenda primero una representación general y razonable de "cómo
    lucen las series de vegetación de esta zona" con MUCHOS más datos (sin
    etiqueta) de los que hay disponibles para la tarea supervisada final
    (138 filas), y luego esos pesos se usan como punto de partida (en vez de
    inicialización aleatoria) al entrenar el LSTMEncoder supervisado -- ver
    init_from_pretrained().
    """

    def __init__(self, n_channels, hidden_size=24, embedding_size=12, dropout=0.2):
        super().__init__()
        self.lstm = nn.LSTM(input_size=n_channels, hidden_size=hidden_size, batch_first=True)
        self.attn = nn.Linear(hidden_size, 1)
        self.dropout = nn.Dropout(dropout)
        self.embed = nn.Linear(hidden_size, embedding_size)
        # Decoder: repite el embedding en cada paso de tiempo como entrada
        # constante (patrón estándar de autoencoder secuencia-a-secuencia
        # simple) y reconstruye los n_channels originales por paso.
        self.decoder_lstm = nn.LSTM(input_size=embedding_size, hidden_size=hidden_size, batch_first=True)
        self.output_layer = nn.Linear(hidden_size, n_channels)

    def encode(self, x):
        outputs, _ = self.lstm(x)
        attn_scores = self.attn(outputs).squeeze(-1)
        attn_weights = torch.softmax(attn_scores, dim=1).unsqueeze(-1)
        h = (outputs * attn_weights).sum(dim=1)
        h = self.dropout(h)
        emb = torch.tanh(self.embed(h))
        return emb

    def forward(self, x):
        n_weeks = x.shape[1]
        emb = self.encode(x)
        emb_repeated = emb.unsqueeze(1).repeat(1, n_weeks, 1)
        dec_out, _ = self.decoder_lstm(emb_repeated)
        recon = self.output_layer(dec_out)
        return recon, emb


def pretrain_autoencoder(X_unlabeled, n_channels, epochs=100, lr=1e-3, weight_decay=1e-4, seed=None):
    """
    Entrena el LSTMAutoEncoder por reconstrucción (MSE entre la secuencia
    original y la reconstruida) sobre X_unlabeled. No necesita early
    stopping con set de validación separado: al no ser supervisado (no hay
    riesgo de "memorizar" una etiqueta que no existe) y con varias veces más
    filas que el problema supervisado, se entrena un número fijo de épocas.
    """
    seed = cfg.RANDOM_STATE if seed is None else seed
    torch.manual_seed(seed)
    model = LSTMAutoEncoder(n_channels=n_channels)
    opt = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)
    loss_fn = nn.MSELoss()

    Xt = torch.tensor(X_unlabeled, dtype=torch.float32)
    model.train()
    for epoch in range(epochs):
        opt.zero_grad()
        recon, _ = model(Xt)
        loss = loss_fn(recon, Xt)
        loss.backward()
        opt.step()
    model.eval()
    return model


def init_from_pretrained(encoder_model, autoencoder):
    """
    Copia los pesos de lstm/attn/embed del autoencoder (ya pre-entrenado por
    reconstrucción) hacia un LSTMEncoder recién creado -- la cabeza de
    regresión (head) se deja con su inicialización aleatoria normal, ya que
    no existe un equivalente de esa capa en el autoencoder (nunca vio una
    etiqueta de rendimiento). Modifica encoder_model in-place y lo regresa.
    """
    encoder_model.lstm.load_state_dict(autoencoder.lstm.state_dict())
    encoder_model.attn.load_state_dict(autoencoder.attn.state_dict())
    encoder_model.embed.load_state_dict(autoencoder.embed.state_dict())
    return encoder_model


def train_lstm(X_train, y_train, X_val=None, y_val=None, n_channels=None, epochs=200, lr=1e-3,
               weight_decay=1e-3, pretrained_ae=None):
    model = LSTMEncoder(n_channels=n_channels)
    if pretrained_ae is not None:
        init_from_pretrained(model, pretrained_ae)
    opt = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)
    loss_fn = nn.MSELoss()

    Xt = torch.tensor(X_train, dtype=torch.float32)
    yt = torch.tensor(y_train, dtype=torch.float32)
    Xv = torch.tensor(X_val, dtype=torch.float32) if X_val is not None else None
    yv = torch.tensor(y_val, dtype=torch.float32) if y_val is not None else None

    best_val = np.inf
    best_state = None
    patience, bad_epochs = 25, 0

    for epoch in range(epochs):
        model.train()
        opt.zero_grad()
        pred, _ = model(Xt)
        loss = loss_fn(pred, yt)
        loss.backward()
        opt.step()

        if Xv is not None:
            model.eval()
            with torch.no_grad():
                pred_v, _ = model(Xv)
                val_loss = loss_fn(pred_v, yv).item()
            if val_loss < best_val:
                best_val, best_state, bad_epochs = val_loss, {k: v.clone() for k, v in model.state_dict().items()}, 0
            else:
                bad_epochs += 1
                if bad_epochs >= patience:
                    break

    if best_state is not None:
        model.load_state_dict(best_state)
    model.eval()
    return model


def train_and_predict_bagged(Xtr, ytr, Xte, n_channels, ll_tr=None, ll_te=None,
                              static_tr=None, static_te=None, n_bags=N_BAGS,
                              base_seed=None, val_frac=0.15, pretrained_ae=None):
    """
    Entrena n_bags LSTM+GP independientes sobre el MISMO (Xtr, ytr) -- cada
    bag usa una semilla distinta (inicialización de la red + su propio split
    interno de validación para early stopping) -- y promedia sus
    predicciones finales. Ver punto 2-3 del docstring del módulo.

    Importante: promediamos PREDICCIONES, no embeddings. Dos LSTM con
    inicializaciones distintas aprenden espacios de embedding "rotados"
    entre sí (misma arquitectura, pesos distintos), así que promediar sus
    embeddings coordenada a coordenada no tendría sentido; promediar
    predicciones sí, porque todas están en la misma escala (ton/ha).

    Cada bag separa su propio split fit/val DENTRO de (Xtr, ytr) solo para
    decidir cuándo detener el entrenamiento del LSTM -- el GP siempre se
    entrena con las embeddings de TODO Xtr/ytr de ese fold, no se pierden
    filas por el split de early stopping.

    Devuelve (pred_mean, pred_std): pred_std combina la incertidumbre PROPIA
    de cada GP (var_within) con el desacuerdo ENTRE bags (var_between) --
    ley de varianza total de un ensemble, así la incertidumbre reportada
    refleja también cuánto varía la predicción según la inicialización.
    """
    base_seed = cfg.RANDOM_STATE if base_seed is None else base_seed
    n = len(Xtr)
    preds_bags, stds_bags = [], []

    for b in range(n_bags):
        seed = base_seed + b
        torch.manual_seed(seed)
        rng = np.random.RandomState(seed)

        n_val = max(8, int(val_frac * n))
        perm = rng.permutation(n)
        val_idx, fit_idx = perm[:n_val], perm[n_val:]

        model = train_lstm(Xtr[fit_idx], ytr[fit_idx], Xtr[val_idx], ytr[val_idx], n_channels=n_channels,
                            pretrained_ae=pretrained_ae)
        with torch.no_grad():
            _, emb_tr = model(torch.tensor(Xtr, dtype=torch.float32))
            _, emb_te = model(torch.tensor(Xte, dtype=torch.float32))
        emb_tr, emb_te = emb_tr.numpy(), emb_te.numpy()

        gp_Xtr, gp_Xte = emb_tr, emb_te
        if ll_tr is not None:
            gp_Xtr = np.hstack([gp_Xtr, ll_tr])
            gp_Xte = np.hstack([gp_Xte, ll_te])
        if static_tr is not None:
            gp_Xtr = np.hstack([gp_Xtr, static_tr])
            gp_Xte = np.hstack([gp_Xte, static_te])

        gp = GaussianProcessRegressor(kernel=make_gp_kernel(), normalize_y=True, n_restarts_optimizer=5, random_state=seed)
        gp.fit(gp_Xtr, ytr)
        pred, std = gp.predict(gp_Xte, return_std=True)
        preds_bags.append(pred)
        stds_bags.append(std)

    preds_bags = np.stack(preds_bags)  # (n_bags, n_test)
    stds_bags = np.stack(stds_bags)
    pred_mean = preds_bags.mean(axis=0)
    var_between = preds_bags.var(axis=0)
    var_within = (stds_bags ** 2).mean(axis=0)
    pred_std = np.sqrt(var_between + var_within)
    return pred_mean, pred_std


def _build_static_arrays(static_cov, all_ids, train_mask):
    """
    Alinea las covariables estáticas (si existen) al orden de all_ids, e
    imputa NaN residual (ej. una parcela sin match de suelo) con la mediana
    de ENTRENAMIENTO -- nunca con la de todo el dataset, para no filtrar
    información del 30% oculto hacia el imputador.
    """
    if static_cov is None:
        return None, []
    static_full = static_cov.reindex(all_ids)
    cols = static_full.columns.tolist()
    arr = static_full.to_numpy(dtype=float)
    col_medians = np.nanmedian(arr[train_mask], axis=0)
    nan_rows, nan_cols = np.where(np.isnan(arr))
    if len(nan_rows):
        arr[nan_rows, nan_cols] = np.take(col_medians, nan_cols)
    return arr, cols


def main():
    target, sequences, week_index = build_dataset()
    n_channels = len(S2_CHANNELS) + len(PLANET_CHANNELS)

    all_ids = target[cfg.ID_COL].tolist()
    X_all = np.stack([sequences[pid] for pid in all_ids])  # (n_parcelas, N_WEEKS, n_channels)

    # Estandarizar cada canal usando SOLO estadísticos de entrenamiento (evita fuga de información)
    train_mask = (target["CONJUNTO"] == "ENTRENAMIENTO").to_numpy()
    means = np.nanmean(X_all[train_mask], axis=(0, 1))
    stds = np.nanstd(X_all[train_mask], axis=(0, 1))
    stds[stds == 0] = 1.0
    X_all = (X_all - means) / stds
    X_all = np.nan_to_num(X_all, nan=0.0)  # canal totalmente vacío en esa parcela -> 0 tras estandarizar

    y_all = target["rendimiento_t_ha"].to_numpy(dtype=float)

    idx_train = np.where(train_mask)[0]
    idx_pred = np.where(~train_mask)[0]

    X_train_full, y_train_full = X_all[idx_train], y_all[idx_train]

    lat_lon = get_lat_lon()
    static_cov = get_static_covariates()
    static_all, static_cols = _build_static_arrays(static_cov, all_ids, train_mask)
    if lat_lon is not None:
        ll_all = lat_lon.set_index(cfg.ID_COL).reindex(all_ids)
        municipio_all = ll_all["Municipio"].to_numpy()
        ll_all = ll_all[["lat", "lon"]].to_numpy(dtype=float)
    else:
        ll_all, municipio_all = None, None

    static_train_full = static_all[idx_train] if static_all is not None else None
    ll_train_full = ll_all[idx_train] if ll_all is not None else None
    municipio_train_full = municipio_all[idx_train] if municipio_all is not None else None

    print(f"[paper] bagging activado con N_BAGS={N_BAGS} (cada fold entrena {N_BAGS} LSTM+GP y promedia).")

    # --- Pre-entrenamiento auto-supervisado del encoder LSTM (opcional) ---
    pretrained_ae = None
    if USE_PRETRAINING:
        print("\n[paper-pretrain] construyendo dataset no supervisado 2022-2025 para pre-entrenar el encoder LSTM ...")
        X_pretrain_raw = build_pretrain_dataset()
        if X_pretrain_raw is not None:
            X_pretrain = (X_pretrain_raw - means) / stds
            X_pretrain = np.nan_to_num(X_pretrain, nan=0.0)
            print(f"[paper-pretrain] entrenando LSTMAutoEncoder sobre {len(X_pretrain)} secuencias "
                  f"parcela-año (reconstrucción, no supervisado) ...")
            pretrained_ae = pretrain_autoencoder(X_pretrain, n_channels=n_channels, seed=cfg.RANDOM_STATE)
            print("[paper-pretrain] listo -- los pesos del encoder (LSTM+atención+embedding) se usarán "
                  "como punto de partida en cada fold/bag en vez de inicialización aleatoria.")
        else:
            print("[paper-pretrain] AVISO: no se pudo construir el dataset de pre-entrenamiento -- "
                  "se sigue con inicialización aleatoria normal.")

    # --- Validación cruzada (5-fold) para reportar RMSE/MAE/R2 igual que en 04 ---
    print("[paper] validación cruzada 5-fold (LSTM + GP, atención + bagging) ...")
    kf = KFold(n_splits=5, shuffle=True, random_state=cfg.RANDOM_STATE)
    rmses, maes, r2s = [], [], []

    for fold, (tr_idx, te_idx) in enumerate(kf.split(X_train_full)):
        Xtr, Xte = X_train_full[tr_idx], X_train_full[te_idx]
        ytr, yte = y_train_full[tr_idx], y_train_full[te_idx]

        ll_tr = ll_te = static_tr = static_te = None
        if ll_train_full is not None:
            scaler_ll = StandardScaler().fit(ll_train_full[tr_idx])
            ll_tr = scaler_ll.transform(ll_train_full[tr_idx])
            ll_te = scaler_ll.transform(ll_train_full[te_idx])
        if static_train_full is not None:
            scaler_st = StandardScaler().fit(static_train_full[tr_idx])
            static_tr = scaler_st.transform(static_train_full[tr_idx])
            static_te = scaler_st.transform(static_train_full[te_idx])

        pred, _ = train_and_predict_bagged(
            Xtr, ytr, Xte, n_channels, ll_tr=ll_tr, ll_te=ll_te,
            static_tr=static_tr, static_te=static_te,
            base_seed=cfg.RANDOM_STATE + fold * 100, pretrained_ae=pretrained_ae,
        )

        rmses.append(mean_squared_error(yte, pred) ** 0.5)
        maes.append(mean_absolute_error(yte, pred))
        r2s.append(r2_score(yte, pred))
        print(f"  fold {fold + 1}/5: RMSE={rmses[-1]:.3f}  MAE={maes[-1]:.3f}  R2={r2s[-1]:.3f}")

    result = pd.DataFrame([{
        "modelo": "LSTM+GP (paper You et al. 2017, adaptado -- atención+bagging)",
        "rmse_cv": float(np.mean(rmses)),
        "mae_cv": float(np.mean(maes)),
        "r2_cv": float(np.mean(r2s)),
    }])
    result.to_csv(OUT_DIR / "cv_resultado_paper.csv", index=False)
    print("\n[paper] resultado de CV (KFold normal):")
    print(result.to_string(index=False))

    cv_04 = cfg.OUTPUT_DIR / "04_modelo" / "cv_resultados.csv"
    if cv_04.exists():
        base = pd.read_csv(cv_04)
        combined = pd.concat([base, result], ignore_index=True).sort_values("rmse_cv")
        combined.to_csv(OUT_DIR / "cv_resultados_combinado.csv", index=False)
        print("\n[paper] comparación contra los modelos de 04_train_and_evaluate.py:")
        print(combined.to_string(index=False))
    else:
        print(f"\n[paper] AVISO: no encontré {cv_04} -- corre primero 04_train_and_evaluate.py para comparar.")

    # --- Validación GroupKFold por Municipio: ¿el desempeño se sostiene si ---
    # --- ninguna parcela del mismo municipio aparece a la vez en train/test? ---
    # A diferencia del modelo de árboles (04), este modelo NO recibe
    # Municipio/Estado como variable, así que se espera que la caída (si la
    # hay) sea mucho menor -- eso es justo lo que hace a este modelo más
    # defendible como "basado en percepción remota" para el reporte.
    if municipio_train_full is not None and pd.notna(municipio_train_full).all():
        n_grupos = len(set(municipio_train_full))
        if n_grupos >= 2:
            print(f"\n[paper] validación LeaveOneGroupOut por Municipio ({n_grupos} municipios, "
                  f"{n_grupos} folds, uno por municipio) -- sin bagging (n_bags=1) para no alargar demasiado la corrida ...")
            logo = LeaveOneGroupOut()
            rmses_g, maes_g, r2s_g = [], [], []
            for fold, (tr_idx, te_idx) in enumerate(logo.split(X_train_full, y_train_full, groups=municipio_train_full)):
                Xtr, Xte = X_train_full[tr_idx], X_train_full[te_idx]
                ytr, yte = y_train_full[tr_idx], y_train_full[te_idx]

                # Cada fold deja fuera un ÚNICO municipio completo -- si un
                # fold sale muy mal (o muy bien), es clave saber CUÁL
                # municipio es para no sacar conclusiones equivocadas de un
                # resultado ruidoso calculado con pocas parcelas.
                municipios_test = sorted(set(municipio_train_full[te_idx]))
                print(f"    [fold-grupo {fold + 1}] municipio(s) fuera: {municipios_test} "
                      f"({len(te_idx)} parcelas, rendimiento real min={yte.min():.2f} max={yte.max():.2f} mean={yte.mean():.2f})")

                ll_tr = ll_te = static_tr = static_te = None
                if ll_train_full is not None:
                    scaler_ll = StandardScaler().fit(ll_train_full[tr_idx])
                    ll_tr = scaler_ll.transform(ll_train_full[tr_idx])
                    ll_te = scaler_ll.transform(ll_train_full[te_idx])
                if static_train_full is not None:
                    scaler_st = StandardScaler().fit(static_train_full[tr_idx])
                    static_tr = scaler_st.transform(static_train_full[tr_idx])
                    static_te = scaler_st.transform(static_train_full[te_idx])

                pred, _ = train_and_predict_bagged(
                    Xtr, ytr, Xte, n_channels, ll_tr=ll_tr, ll_te=ll_te,
                    static_tr=static_tr, static_te=static_te,
                    n_bags=1, base_seed=cfg.RANDOM_STATE + fold * 100, pretrained_ae=pretrained_ae,
                )
                rmses_g.append(mean_squared_error(yte, pred) ** 0.5)
                maes_g.append(mean_absolute_error(yte, pred))
                r2s_g.append(r2_score(yte, pred))
                print(f"  fold-grupo {fold + 1}/{n_grupos}: RMSE={rmses_g[-1]:.3f}  MAE={maes_g[-1]:.3f}  R2={r2s_g[-1]:.3f}")

            result_g = pd.DataFrame([{
                "modelo": "LSTM+GP (LeaveOneGroupOut por Municipio)",
                "rmse_cv": float(np.mean(rmses_g)),
                "mae_cv": float(np.mean(maes_g)),
                "r2_cv": float(np.mean(r2s_g)),
            }])
            result_g.to_csv(OUT_DIR / "cv_resultado_paper_groupkfold.csv", index=False)
            print("\n[paper] KFold normal vs LeaveOneGroupOut por Municipio (validación honesta de generalización):")
            print(f"  KFold normal:               RMSE={result['rmse_cv'].iloc[0]:.3f}")
            print(f"  LeaveOneGroupOut Municipio: RMSE={result_g['rmse_cv'].iloc[0]:.3f}")
            print("  Si la diferencia es chica (a diferencia de lo que probablemente le pasa al "
                  "modelo de árboles con Municipio como feature), es evidencia de que este modelo "
                  "generaliza a ubicaciones no vistas y no depende de memorizar el municipio.")
        else:
            print(f"\n[paper] AVISO: solo hay {n_grupos} municipios distintos, insuficiente para LeaveOneGroupOut -- se omite.")
    else:
        print("\n[paper] AVISO: no pude armar la validación LeaveOneGroupOut por Municipio (faltan datos de Municipio) -- se omite.")

    # --- Reentrenar con TODAS las 138 parcelas de entrenamiento y predecir las 59 ocultas ---
    print(f"\n[paper] reentrenando con las 138 parcelas de entrenamiento completas (bagging N_BAGS={N_BAGS}) ...")

    ll_train = ll_pred = static_train = static_pred = None
    if ll_all is not None:
        scaler_ll = StandardScaler().fit(ll_train_full)
        ll_train = scaler_ll.transform(ll_train_full)
        ll_pred = scaler_ll.transform(ll_all[idx_pred])
    if static_all is not None:
        scaler_st = StandardScaler().fit(static_train_full)
        static_train = scaler_st.transform(static_train_full)
        static_pred = scaler_st.transform(static_all[idx_pred])

    preds_final, preds_std = train_and_predict_bagged(
        X_train_full, y_train_full, X_all[idx_pred], n_channels,
        ll_tr=ll_train, ll_te=ll_pred, static_tr=static_train, static_te=static_pred,
        base_seed=cfg.RANDOM_STATE + 9000, pretrained_ae=pretrained_ae,
    )

    out = pd.DataFrame({
        "ID_parcela": [all_ids[i] for i in idx_pred],
        "rendimiento_predicho_ton_ha": preds_final.round(3),
        "incertidumbre_std": preds_std.round(3),  # ventaja extra del GP: da incertidumbre, no solo el punto
    }).sort_values("ID_parcela")
    out.to_csv(OUT_DIR / "prediccion_paper_ton_ha.csv", index=False)

    # Embeddings de referencia (para inspección / uso como feature adicional en 04):
    # se calculan con UNA sola red (semilla base) entrenada sobre todo el train,
    # ya que promediar embeddings de las N_BAGS redes del bagging no tiene
    # sentido (espacios de embedding no alineados entre sí -- ver docstring
    # de train_and_predict_bagged).
    torch.manual_seed(cfg.RANDOM_STATE)
    n_val = max(10, int(0.15 * len(X_train_full)))
    perm = np.random.RandomState(cfg.RANDOM_STATE).permutation(len(X_train_full))
    val_idx, fit_idx = perm[:n_val], perm[n_val:]
    emb_model = train_lstm(X_train_full[fit_idx], y_train_full[fit_idx], X_train_full[val_idx], y_train_full[val_idx],
                            n_channels=n_channels, pretrained_ae=pretrained_ae)
    with torch.no_grad():
        _, emb_train_all = emb_model(torch.tensor(X_train_full, dtype=torch.float32))
        _, emb_pred_all = emb_model(torch.tensor(X_all[idx_pred], dtype=torch.float32))
    emb_train_all, emb_pred_all = emb_train_all.numpy(), emb_pred_all.numpy()

    emb_df = pd.DataFrame(
        np.vstack([emb_train_all, emb_pred_all]),
        columns=[f"lstm_emb_{i}" for i in range(emb_train_all.shape[1])],
    )
    emb_df.insert(0, cfg.ID_COL, [all_ids[i] for i in idx_train] + [all_ids[i] for i in idx_pred])
    emb_df.to_csv(OUT_DIR / "embeddings_lstm.csv", index=False)

    print(f"\n[paper] listo. Salidas en {OUT_DIR}")
    print("Nota: el GP también da incertidumbre por parcela (columna incertidumbre_std, que ahora "
          "combina el desacuerdo entre bags con la incertidumbre propia del GP) -- algo que ningún "
          "otro modelo del pipeline ofrece, y es un punto fuerte para mencionar en el reporte "
          "técnico (comunica confianza, no solo el punto estimado).")


if __name__ == "__main__":
    main()
